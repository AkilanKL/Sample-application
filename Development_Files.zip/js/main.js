
var _model = DataManager.getInstance();

var appControllerObj, lessonId;
var audioManagerMain;
var mediaControls;

$(document).ready(function(){

    if(!(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent))) {
        $('[data-toggle="tooltip"]').tooltip();
        $('#volume-ctrl').tooltip({ position: { my: "left+15 top+35"} });
    }

    $(".ui-helper-hidden-accessible").attr("aria-live", "off")
  

    StaticLibrary.SHOW_PRE_LOADER();

     /* Making http request to App data json file and next blocks are executed in loadAppDataSuccessHandler call back function */
     
	var apiServiceLoadAppData = new APIService();
        apiServiceLoadAppData.loadAppConfigData(StaticLibrary.APP_DATA_URL, "true", StaticLibrary.DATA_TYPE, null, loadAppDataSuccessHandler);

    //setup the jPlayer plugin and only on the ready of the plugin the Framework will start the calls.
    
    var player = $("#jquery_jplayer_1");
    _model.setAudioReference(player);
    audioManagerMain = new AudioManager();
    mediaControls =  new MediaControls();
    mediaControls.init(audioManagerMain);

    $("#jquery_jplayer_1").jPlayer({
        ready: function () {
           
        },
        ended:function(){
           
            _model.setAudioStatus({
                status : "ended",
                volume : null
            });

            audioManagerMain.pauseAudio()
            if(_model.getAudioStatus().type == "landing-audio") {
                audioEndEventHandler();
            }else{
                appControllerObj.audioEndEventHandler();
            }
            
           

        },
        loadeddata: function(event){
            _model.setAudioDuration(event.jPlayer.status.duration);
        },
        timeupdate:function(event){

            if((event.jPlayer.status.currentTime >= 0.10) && (_model.getPreloaderFlag())){
                StaticLibrary.HIDE_PRE_LOADER();
            }
            _model.setCurrentTime(event.jPlayer.status.currentTime);
            mediaControls.progressHandler(event.jPlayer.status.currentTime)

        },
        error: function(e) {
            console.log(e)
        },
        autoPlay: true
    });


    _model.setAudioStatus({
        status : null,
		volume: "un-muted"
    });

    $(document).on("visibilitychange", function() {
        if (document.hidden) {
            if(_model.getAudioStatus().status == "playing"){
                audioManagerMain.pauseAudio()
            }
          } else  {
            if(_model.getAudioStatus().status == "playing"){
                audioManagerMain.playAudio()
            }
          }
    });
        
});

function loadAppDataSuccessHandler(data){

    var scormAPIObj = new scormAPI();
    _model.setScormReference(scormAPIObj);
    
    DataParser.parseAppData(data);
    
    /* Making http request to landing page and next blocks are executed in landingPageSuccessHandler call back function*/

    var landingPageUrl = _model.getAppDataObj().baseURL + "/pages/landingPage.html";
    var apiServiceLoadLP = new APIService();
    apiServiceLoadLP.loadFromExternalSource(landingPageUrl, "true", StaticLibrary.TEMPLATE_TYPE, null, landingPageSuccessHandler);

   
}

function landingPageSuccessHandler(data) {
    $("#landingPage").html(data).promise().done(function(){

        imageLoadListener = function(e){
            $(".landing-img").css("background-image", "url("+_model.getAppDataObj().baseURL+"/assets/images/"+_model.getAppDataObj().landingImage+ ")");
            StaticLibrary.HIDE_PRE_LOADER();
        }
        
        var image = new Image();
		image.src = _model.getAppDataObj().baseURL+"/assets/images/"+_model.getAppDataObj().landingImage;
		image.addEventListener('load',imageLoadListener);
        image.addEventListener('error',imageLoadListener);


        $(".transcript-body span").html($(".titlt-page-transcript").html());
        audioManagerMain.loadAudio(_model.getAppDataObj().baseURL + "/assets/media/audio/"+(_model.getAppDataObj().landingPageAudio));
		_model.setAudioStatus({
			status : "loaded",
            volume : null,
            type: "landing-audio"
        });
        
        /*  Start button triggers */

        $("#btnStart").off("click").on("click", function(){

            $(".landingscreen_bg").hide();
            $(".grandparent").show();	 
                
            /* Making http request to Course data json fileand next blocks are executed in loadCourseDataSuccessHandler call back function */

            var courseDataURL = _model.getAppDataObj().baseURL + "/assets/data/courseData.json?version=" + StaticLibrary.generateRandom();
            var apiServiceLoadCourseData = new APIService();
            apiServiceLoadCourseData.loadCourseData(courseDataURL, "true", StaticLibrary.DATA_TYPE, null, loadCourseDataSuccessHandler);	
                
        })
   });
}

function loadCourseDataSuccessHandler(data){

    DataParser.parseCourseData(data);	
	
    $(".projectTitle").html(_model.getCourseDataObj().projectTitle);

    $("#desktopHelpImage").attr("src", _model.getCourseDataObj().baseURL + "assets/images/" + _model.getCourseDataObj().desktopHelp);

    /* Initialize course controller */

   appControllerObj = new ApplicationController();
   appControllerObj.init(audioManagerMain); 
	
} 

function audioEndEventHandler() {
    var svg = $('.pause-play-flag svg');
	var svgClass;
	svgClass = svg.attr("class").replace("fa-pause", "fa-redo-alt");
    svg.attr("class", svgClass);
    $(".pause-play-flag").attr('name', 'play');
	$(".pause-play-flag").attr('title', 'play');
}

function trace(datastr){
	console.log(datastr);
}
