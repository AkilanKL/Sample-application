 var FormativeAssessmentTemplateController = function(currentRef){

	var _this = this;
	this.attemptedCount = 0;
	this.submitBtn;
	this.correctoptions;
	this.clearState = false;

    this.init = function(data){

		/* Initialized from loadExternalPageSuccessHandler with json file(data) of the page */

        _this.currentData = data;
        _this.loadUI(_this.currentData);
		
    }
	
    this.loadUI = function(data){
		
	  /* Painting all the html elements dynamically */

	if(data.pageContent.img_container.image != undefined &&
		 data.pageContent.img_container.image != "") {
			var bgUrl = _model.getAppDataObj().baseURL + "/assets/images/" + data.pageContent.img_container.image;
			 $("#img-wrapper").css({
				"background-image": "url('"+ bgUrl +"')",
				"background-size": data.pageContent.img_container.image_size,
				"background-position": data.pageContent.img_container.image_position_x+" "+
									   data.pageContent.img_container.image_position_y,
			})
	}
	if(data.pageContent.img_container.alt_text != undefined &&
			data.pageContent.img_container.alt_text != "") {
				$("#img-wrapper").attr("role","img");
				$("#img-wrapper").attr("aria-label",data.pageContent.img_container.alt_text);

	}
	  
	if(data.pageContent.question != undefined && data.pageContent.question != ""){
		$(".asmnt-question").html("").html(data.pageContent.question);
	}
	if(data.pageContent.instruction != undefined && data.pageContent.instruction != "") {
		$("#asmnt-instruction").html("").html(data.pageContent.instruction);
	}

	  var optionWrapper = $(".asmnt-options-wrapper");
	  _this.submitBtn = $(".submit-btn");

	  var inputType = "";
	  var inputClass = "";

		if(data.pageContent.type == "MC"){
			inputType = "checkbox";
			inputClass = "checkbox-dummy";
		}else if(data.pageContent.type == "SC") {
			inputType = "radio";
			inputClass = "radio-dummy";
		}
		else if(data.pageContent.type == "TF") {
			inputType = "radio";
			inputClass = "radio-dummy";
		}

		_this.correctoptions = [];
		  for(var i = 0; i < data.pageContent.choice.length; i++) {
			if(data.pageContent.type == "TF") {
				if(i > 1) {
					break;
				}
			}

			/* Creating options according to the value of page json data file  */

			var dummyInput = document.createElement("div"); 
			dummyInput.className = inputClass+ " input-dummy";

			var tempCheckBox = document.createElement("input");
			tempCheckBox.setAttribute("type",inputType);
			tempCheckBox.setAttribute("name","option");
			tempCheckBox.setAttribute("id","option-"+(i+1));
			tempCheckBox.dataset.value = (i+1);

			var tempLabel = document.createElement("label");
			tempLabel.setAttribute("for","option-"+(i+1));
			tempLabel.appendChild(dummyInput);
			var tempDiv = document.createElement("div");
			tempDiv.innerHTML = data.pageContent.choice[i].option;
			tempLabel.appendChild(tempDiv);

			var tempoption = document.createElement("div");
			tempoption.className = "asmnt-option";
			var tempDiv = document.createElement("div");
			
			tempDiv.appendChild(tempCheckBox);
			tempDiv.appendChild(tempLabel);
			tempoption.appendChild(tempDiv);

			optionWrapper.append(tempoption);

			if(data.pageContent.choice[i].correct == "true") {
				_this.correctoptions.push((i+1));
			}
			
		  } 

		  if( currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.completed == "false" ){
				currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.ac = 
				data.pageContent.maxAttempt || 0;
				_this.attemptedCount = currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.acTaken
		  }else{
			  _this.showAnswerHandler("loadUi");
		  }

		  $("input").change(_this.watchSubmitBtnState);
		  _this.submitBtn.click(_this.answerSubmitHandler);
		  $("input").focus(_this.clearHandler);
		  setTimeout(function() {
			currentRef.makeResponsiveWith("#assessment-wrapper");
		  }, 200);
		 
	}
	
	this.watchSubmitBtnState = function() {
		var checkedLength = $("input:checked").length;
		if(checkedLength){
			_this.submitBtn.addClass("activate-btn");
			_this.submitBtn.attr("tabindex", "0");
		}else{
			_this.submitBtn.removeClass("activate-btn");
			_this.submitBtn.attr("tabindex", "-1");
		}
	}
	
	/* Validating answer after click submit button  */

	this.answerSubmitHandler = function(e){

		_this.submitBtn.removeClass("activate-btn");
		_this.submitBtn.attr("tabindex", "-1");
		var wrFeedback = "";
		
		if( currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.completed == "false" ){
			_this.attemptedCount++;
			_this.clearState = true;
			var checkedOptions = [];
			var correctAnsCount = 0;
			var wrongtAnsCount = 0;
	
			$("input:checked").each(function(){
				checkedOptions.push($(this).data("value"));
			});
			if(_this.attemptedCount < currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.ac) {
				wrFeedback = "Try again."
			}
			checkedOptions.forEach(function(el, i) {
				if(_this.correctoptions.indexOf(el) > -1){
					$(".asmnt-option").eq(el-1).addClass("correct-ans");
					$(".asmnt-option").eq(el-1).append("<span id='ans_feedback'>"+ _this.currentData.pageContent.choice[el-1].feedback +"</span>");
					correctAnsCount++;
				}else{
					$(".asmnt-option").eq(el-1).addClass("wrong-ans");
					$(".asmnt-option").eq(el-1).append("<span id='ans_feedback'>"+ _this.currentData.pageContent.choice[el-1].feedback +" "+ wrFeedback+ "</span>");
					wrongtAnsCount++;
				}
			});

			$("#ans_feedback").focus();

			if(correctAnsCount == _this.correctoptions.length && wrongtAnsCount == 0) {
				var tempObj = {
					score: 1,
					attemptsTaken: _this.attemptedCount,
					completed: "true"
				}
				currentRef.updateMenuNdTrackingStatus("visited", tempObj);
				_this.showAnswerHandler("submit");
				if(_model.getLinearTOCDataArr()[currentRef.curChapterIndex].pages[currentRef.currentIndex].templateType == "Assessment") {
					setTimeout(function() {
						currentRef.nextClickHandler();
					}, 2000);
				}
				
			}else{
				if(_this.attemptedCount == currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.ac) {
					var tempObj = {
						score: 0,
						attemptsTaken: _this.attemptedCount,
						completed: "true"
					}
					currentRef.updateMenuNdTrackingStatus("visited", tempObj);
					_this.showAnswerHandler("submit");
					if(_model.getLinearTOCDataArr()[currentRef.curChapterIndex].pages[currentRef.currentIndex].templateType == "Assessment") {
						setTimeout(function() {
							currentRef.nextClickHandler();
						}, 2000);
					}
				}else{
					var tempObj = {
						score: 0,
						attemptsTaken: _this.attemptedCount,
						completed: "false"
					}
					currentRef.updateMenuNdTrackingStatus(null, tempObj);
				}
			}

		}
	}
	
	/* Displaying feedback when learner click submit button or learner completd the knowlwdge check  */

	this.showAnswerHandler = function(type) {

		if(type == "submit") {
			$("input").attr("disabled","disbled");
			$("label").css("pointer-events","none");
			$(".input-dummy").css("opacity","0.6");

		}else{
			$("input").attr("disabled","disbled");
			$("label").css("pointer-events","none");
			$(".input-dummy").css("opacity","0.6");
			_this.correctoptions.forEach(function(el, i) {
					$(".asmnt-option").eq(el-1).addClass("correct-ans");
					$(".asmnt-option").eq(el-1).append("<span>"+ _this.currentData.pageContent.choice[el-1].feedback +"</span>");
			});
		}	

	}
	
	/* Clearing selected options for the second attempt */
	
	this.clearHandler = function(){
		if(_this.clearState){
			_this.clearState = false;
			$(".asmnt-option").removeClass("correct-ans");
			$(".asmnt-option").removeClass("wrong-ans");
			$(".asmnt-option span").remove();
			$("input").each(function() {
				$(this).removeAttr("checked");
			})
		}
	}

	
}