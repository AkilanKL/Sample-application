
var ApplicationController = function () {

    var currentRef = this; //hack to get the reference of the current class
	var currentTemplate;
    var currentTemplateObj;
    this.currentIndex = 0;
    this.currentPageJSONData;
    this.currentPageToLoadObj;	
	this.totalPageCount = 0;
	this.totalKcQuestions = 0;
	this.score = 0;
	
    this.menuStatusArr = new Array();
	this.curChapterIndex = 0;
	this.curPageIndex = 0;
	this.imageLoadIndex = 0;
	this.totalImageCount = 0;
	this.menuItems = "";
	this.activeMenuIndex = 0;

	this.audioManager;

	var hoverVolActive = false;
	this.isMenuOpened = false;
	this.freezeMenu = false;
	
    this.init = function (audioManager) {

		/* this function is executed after loading course data json file */

		currentRef.audioManager = audioManager;

        $("#parentContainerParent").hide();
		
		 /* Making http request to TOC data json file and next blocks are executed in loadTOCSuccessHandler call back function */
		
		var tocURL = _model.getAppDataObj().baseURL + "/" + _model.getCourseDataObj().contentURL + "?version=" + StaticLibrary.generateRandom();

        var apiServiceLoadAppData = new APIService();
		apiServiceLoadAppData.loadTOCData(tocURL, "true", StaticLibrary.DATA_TYPE, null, this.loadTOCSuccessHandler);
		
    }
	
	/* Course Menu creation and status phase */

	this.createMenuList = function(){

		var menuListItems = "";
		var tempKc = false;
		var tempKcCount = 0;
		var tempPageIndex = "";
		var tempTitle = "";
		
		for(var i = 0; i < currentRef.menuStatusArr.length; i++){
			
			var liItems = "";

			for(var j = 0; j < currentRef.menuStatusArr[i].pages.length; j++) {

				if(currentRef.menuStatusArr[i].pages[j].kc != undefined) {

					if(!tempKc) {

						tempKc = true;
						tempTitle = _model.getLinearTOCDataArr()[i].pages[j].pageTitle;
						tempPageIndex = j;
						tempKcCount++;
						if(currentRef.menuStatusArr[i].pages[j].isVisited == "true") {
							tempKcVisitedCount++;
						}
			
					}else{

						tempKcCount++;
						if(currentRef.menuStatusArr[i].pages[j].isVisited == "true") {
							tempKcVisitedCount++;
						}

					}

					if(j+1 < currentRef.menuStatusArr[i].pages.length) {
						if(currentRef.menuStatusArr[i].pages[j+1].kc == undefined){
							if(tempKcCount == tempKcVisitedCount) {
								liItems += '<li role="none"><a role="menuitem" class="completed-page" href="javascript:;" data-page-index="page_'+ tempPageIndex +'" tabindex="0" role="button">'+ tempTitle +'<i class="fas fa-check-circle"></i></a></li>';
							}else if(tempKcVisitedCount > 0) {
								liItems += '<li role="none"><a role="menuitem" class="onprogress-page" href="javascript:;" data-page-index="page_'+ tempPageIndex +'" tabindex="0" role="button">'+ tempTitle +'<i class="fas fa-spinner"></i></a></li>';
							}else{
								liItems += '<li role="none"><a href="javascript:;" data-page-index="page_'+ tempPageIndex +'" tabindex="-1" role="button">'+ tempTitle +'</a></li>';
							}
						}
					}else{
						if(tempKcCount == tempKcVisitedCount) {
							liItems += '<li role="none"><a role="menuitem" class="completed-page" href="javascript:;" data-page-index="page_'+ tempPageIndex +'" tabindex="0" role="button">'+ tempTitle +'</a><i class="fas fa-check-circle"></i></li>';
						}else if(tempKcVisitedCount > 0) {
							liItems += '<li role="none"><a role="menuitem" class="onprogress-page" href="javascript:;" data-page-index="page_'+ tempPageIndex +'" tabindex="0" role="button">'+ tempTitle +'<i class="fas fa-spinner"></i></a></li>';
						}else{
							liItems += '<li role="none"><a role="menuitem" href="javascript:;" data-page-index="page_'+ tempPageIndex +'" tabindex="-1" role="button">'+ tempTitle +'</a></li>';
						}
					}

				}else{

					if(currentRef.menuStatusArr[i].pages[j].isVisited == "true"){
						liItems += '<li role="none"><a role="menuitem" class="completed-page" href="javascript:;" data-page-index="page_'+ j +'" tabindex="0" role="button">'+ _model.getLinearTOCDataArr()[i].pages[j].pageTitle +'<i class="fas fa-check-circle"></i></a></li>';
					}else{
						liItems += '<li role="none"><a role="menuitem" href="javascript:;" data-page-index="page_'+ j +'" tabindex="-1" role="button">'+ _model.getLinearTOCDataArr()[i].pages[j].pageTitle +'</a></li>';
					}

					tempKc = false;
					tempKcCount = 0;
					tempKcVisitedCount = 0;

				}
				
			}

			menuListItems += '<ul data-chapter-index="chapter_'+ i +'" role="menubar">'+ liItems +'</ul>';
		}

		$("#menu_lst_container").html(menuListItems);

		currentRef.menuItems = $("#menu_lst_container ul");

		$("#menu_lst_container").off("click").on("click", currentRef.menuItemClickHandler)
	} 
	
    this.loadTOCSuccessHandler = function (data) {

		/* Setting TOC json datas to _model.setLinearTOCDataArr() */

        DataParser.parseTOCData(data);
		
		$(".projectTitle").html('').html(_model.getCourseDataObj().projectTitle);
		$(".module_title").html('').html(_model.getCourseDataObj().title);

		for (var b = 0; b < _model.getLinearTOCDataArr().length; b++) {
			currentRef.totalPageCount += _model.getLinearTOCDataArr()[b].pages.length; // Getting total number of pages count
		}

		for (var i = 0; i < _model.getLinearTOCDataArr().length; i++) {

            currentRef.menuStatusArr.push({"status":"NOT_STARTED"});
			if (_model.getLinearTOCDataArr()[i].pages != undefined) {
				currentRef.menuStatusArr[i].pages = new Array();

				/* Creating tracking data of learner */

				for (var j = 0; j < _model.getLinearTOCDataArr()[i].pages.length; j++) {
					var tempObj = {isVisited:"false"};
					if(_model.getLinearTOCDataArr()[i].pages[j].templateType == "KC" ||
					   _model.getLinearTOCDataArr()[i].pages[j].templateType == "Assessment") {
						tempObj.kc = {
							"score" : 0,
							"ac": 0,
							"acTaken": 0,
							"completed": "false"
						}
						currentRef.totalKcQuestions++;
					}
					currentRef.menuStatusArr[i].pages.push(tempObj);
				}
			}
		}	

		/* Storing tracking data in local storage or LMS depending on the run environment of this application */
		if( _model.getAppDataObj().scorm ){
			var courseTrackingData = _model.getScormReference().retrieveTrackingData();
			if (courseTrackingData != "" && courseTrackingData != undefined &&
			 courseTrackingData != null && courseTrackingData != "undefined") {
				var curData = JSON.parse( courseTrackingData );
				currentRef.menuStatusArr = curData;
			}else{
				currentRef.updateTrackingData(currentRef.menuStatusArr, null, null); /*  suspend data, lesson, course completion and score Object, lesson location */
			}
			
		}else {
			var storedCourseObj = localStorage.getItem(_model.getAppDataObj().courseName+'_v2');
			if( storedCourseObj != null && storedCourseObj != ""){
				var storedData = JSON.parse( storedCourseObj );
				currentRef.menuStatusArr = storedData;
			}else{
				currentRef.updateTrackingData(currentRef.menuStatusArr, null, null); /*  suspend data, lesson, course completion and score Object, lesson location */
			}
		}

		currentRef.createMenuList();
		currentRef.startTheCourse();

    }
	 
    this.startTheCourse = function(){

		$("#parentContainerParent").show();

		/* Attaching events to the global elements */

        setTimeout(function(){

            $("#previousBtn").unbind("click").bind("click", currentRef.previousClickHandler); 
			$("#nextBtn").unbind("click").bind("click", currentRef.nextClickHandler);
			
			$("#hanmburger").unbind("click").bind("click", currentRef.menuClickHandler);
			$("#hanmburger").unbind("keyup").bind("keyup", currentRef.menuEnterHandler);
					
            currentRef.controlVisibility("parentContainerParent");
			currentRef.loadCurrentPage(currentRef.curChapterIndex, currentRef.currentIndex, 1, "initialLoad");
			
        }, 200);
	}

	this.menuEnterHandler = function (e) {
		if(e.keyCode == 13) {
				currentRef.menuClickHandler();
		}
	}

	this.menuClickHandler = function() {
		
		if(!currentRef.freezeMenu) {
			currentRef.freezeMenu = true;
			if(!currentRef.isMenuOpened) {
				$("#parent-body").addClass("menu-opened");
				currentRef.isMenuOpened = true;
				$(this).attr("aria-expanded", "true");
				$("#menu-label").html("Close Main Menu");
				$("#menu-section").css("visibility","visible");
			}else{
				$("#parent-body").removeClass("menu-opened");
				currentRef.isMenuOpened = false;
				$(this).attr("aria-expanded", "false");
				$("#menu-label").html("Open Main Menu");
				setTimeout(function() {
					$("#menu-section").css("visibility","hidden");
				}, 500);
			}
			setTimeout(function() {
				currentRef.freezeMenu = false;
			}, 500);
		}
		
	}

    this.menuItemClickHandler = function (event) {

		var clickedClass = event.target.className;
		if(clickedClass == "completed-page") {

			var pageIndex = event.target.dataset.pageIndex;
			pageIndex = pageIndex.split("_");
			pageIndex = Number(pageIndex[1]);

			var chapterIndex = $(event.target).parents("ul")[0];
			chapterIndex = chapterIndex.dataset.chapterIndex;
			chapterIndex = chapterIndex.split("_");
			chapterIndex = Number(chapterIndex[1]);
			
			currentRef.curChapterIndex = chapterIndex;
			currentRef.currentIndex = pageIndex;

			var currentPageNo = 0;

			for(var i = 0; i < currentRef.curChapterIndex; i++) {
				currentPageNo += _model.getLinearTOCDataArr()[i].pages.length;
			}

			currentPageNo += currentRef.currentIndex + 1;
		
			 currentRef.loadCurrentPage(currentRef.curChapterIndex, currentRef.currentIndex, currentPageNo, "menuClick");
			$("#MenuSection").modal('hide');
		}

    }
	
	
    //function to handle the previous button click to load previous pages in the shell
    this.previousClickHandler = function () {

		var currentPageNo = 0;
		var tempIndex = currentRef.currentIndex + 1;
		
		for(var i = 0; i < currentRef.curChapterIndex; i++) {
			currentPageNo += _model.getLinearTOCDataArr()[i].pages.length;
		}

		currentPageNo += tempIndex - 1;
		
		if(currentRef.curChapterIndex > 0 || currentRef.currentIndex >= 1){
			if((currentRef.currentIndex-1) % _model.getLinearTOCDataArr()[currentRef.curChapterIndex].pages.length > 0){
				currentRef.currentIndex--;
			}else{
				if(currentRef.curChapterIndex > 0) {
					currentRef.curChapterIndex--;
					currentRef.currentIndex = _model.getLinearTOCDataArr()[currentRef.curChapterIndex].pages.length - 1;
				}else{
					currentRef.currentIndex = 0;
				}
			}
			currentRef.loadCurrentPage(currentRef.curChapterIndex, currentRef.currentIndex, currentPageNo, "previousClick");
		}	
        
    }

    //function to handle the next button click to load next pages in the shell
    this.nextClickHandler = function () {

		var currentPageNo = 0;
		var tempIndex = currentRef.currentIndex + 1;
		var tempChapterIndex = currentRef.curChapterIndex;
		var tempPageIndex = currentRef.currentIndex;
		
		for(var i = 0; i < currentRef.curChapterIndex; i++) {
			currentPageNo += _model.getLinearTOCDataArr()[i].pages.length;
		}
		currentPageNo += tempIndex + 1;

		if(currentPageNo <= currentRef.totalPageCount){
			if((currentRef.currentIndex+1) % _model.getLinearTOCDataArr()[currentRef.curChapterIndex].pages.length != 0){
				tempPageIndex++
			}else{
				tempChapterIndex++;
				tempPageIndex = 0;
			}
			currentRef.loadCurrentPage(tempChapterIndex, tempPageIndex, currentPageNo, "nextClick");
		}	

	}    

	this.audioEndEventHandler = function() {
		var svg = $('.pause-play-flag svg');
		var svgClass;
		svgClass = svg.attr("class").replace("fa-pause", "fa-redo-alt");
		svg.attr("class", svgClass);

		$(".pause-play-flag").attr('name', 'play');
		$(".pause-play-flag").attr('title', 'play');

		if(_model.getAppDataObj().linear == "true") {
			if(currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc == undefined) {
				if(currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].isVisited != "true"){
					currentRef.updateMenuNdTrackingStatus("visited", null);
				}
			}	
		}

	}

	
	this.updateMenuNdTrackingStatus = function(status, scoreObj) {
	
			if(scoreObj != null) {
			if( currentRef.menuStatusArr[currentRef.curChapterIndex].pages != undefined ){
				currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.score = scoreObj.score;
				currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.completed = scoreObj.completed;
				currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.acTaken = scoreObj.attemptsTaken;
				if(scoreObj.completed == "true") {
					currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].isVisited = "true";

					if((currentRef.currentIndex+1) != currentRef.totalPageCount) {
						$("#nextBtn").css({"opacity": "1", "pointer-events": "auto"});
						$("#nextBtn").attr("tabindex", "0");
						$("#nextBtn").prop('disabled', false);
						$("#nextBtn svg").css("animation","");
						setTimeout(function() {
							$("#nextBtn svg").css("animation","moveHorizotal 1.3s linear");
						}, 100);
						
					}
					
				}

				currentRef.updateKCTrackingStatus();
			}
		}else{
			if(status == "visited") {
			
				if( currentRef.menuStatusArr[currentRef.curChapterIndex].pages != undefined ){
					
					if((currentRef.currentIndex+1) != currentRef.totalPageCount) {
						$("#nextBtn").css({"opacity": "1", "pointer-events": "auto"});
						$("#nextBtn").attr("tabindex", "0");
						$("#nextBtn").prop('disabled', false);
						$("#nextBtn svg").css("animation","");
						setTimeout(function() {
							$("#nextBtn svg").css("animation","moveHorizotal 1.3s linear");
						}, 100);
					}

					currentRef.menuItems.find("li").eq(currentRef.activeMenuIndex).
					find("a").addClass("completed-page").append('<i class="fas fa-check-circle"></i>');	
	
					currentRef.menuItems.find("li").eq(currentRef.activeMenuIndex).
					find("a").attr("tabindex", 0);
	
					currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].isVisited = "true";

				}
			}
		}

		var lessonCourseStatus = currentRef.getChapterCompletionStatus();
		
		currentRef.updateTrackingData(currentRef.menuStatusArr, lessonCourseStatus, null); /*  suspend data, lesson, course completion and score Object, lesson location */

	}

	this.updateKCTrackingStatus = function() {

		var tempFirstIndex = currentRef.currentIndex;
		var tempLastIndex;
		var tempCount = 0;
		var tempVisitedCount = 0;

		while((tempFirstIndex - 1) >= 0) {
			if(currentRef.menuStatusArr[currentRef.curChapterIndex].pages[tempFirstIndex - 1].kc){
				tempFirstIndex--;
			}else{
				break;
			}
		}

		tempLastIndex = tempFirstIndex;

		while((tempLastIndex+1) < currentRef.menuStatusArr[currentRef.curChapterIndex].pages.length) {
			if(currentRef.menuStatusArr[currentRef.curChapterIndex].pages[tempLastIndex+1].kc){
				tempLastIndex++;
			}else{
				break;
			}
		}

		for(var i = tempFirstIndex; i <= tempLastIndex; i++) {
			tempCount++;
			if(currentRef.menuStatusArr[currentRef.curChapterIndex].pages[i].isVisited == "true") {
				tempVisitedCount++;
			}
		}
		
		if(tempVisitedCount == tempCount) {

			currentRef.menuItems.find("li").eq(tempFirstIndex).
			find("a").removeClass("onprogress-page").find("svg").remove();

			currentRef.menuItems.find("li").eq(tempFirstIndex).
			find("a").addClass("completed-page").append('<i class="fas fa-check-circle"></i>');

			currentRef.menuItems.find("li").eq(tempFirstIndex).
			find("a").eq(tempFirstIndex).attr("tabindex", 0);

		}else if(tempVisitedCount > 0) {

			currentRef.menuItems.find("li").eq(tempFirstIndex).
			find("a").find("svg").remove();

			currentRef.menuItems.find("li").eq(tempFirstIndex).
			find("a").addClass("onprogress-page").append('<i class="fas fa-spinner"></i>');

			currentRef.menuItems.find("li").eq(tempFirstIndex).
			find("a").eq(tempFirstIndex).attr("tabindex", 0);
		}
	}

	/* loadCurrentPage initiates the loading of topic pages*/

    this.loadCurrentPage = function (currentChapter, currentIndex, currentPageNo, flag) {
		
		if(_model.getAppDataObj().linear == "true" && flag == "nextClick") {
			if(currentPageNo > 1) {

				var linearChapter = currentChapter;
				var linearIndex = currentIndex;
				if(currentChapter > 0 || currentIndex >= 1){
					if((currentIndex-1) % _model.getLinearTOCDataArr()[currentChapter].pages.length > 0){
						linearIndex = currentIndex - 1;
					}else{
						if(currentChapter > 0) {
							linearChapter = currentChapter-1;
							linearIndex = _model.getLinearTOCDataArr()[currentChapter].pages.length - 1;
						}else{
							linearIndex = 0;
						}
					}
				}

				if(currentRef.menuStatusArr[linearChapter].pages[linearIndex].isVisited == "false") {
					console.log("Invalid trigger");
					return false;
				}

			}
		}

		currentRef.curChapterIndex = currentChapter;
		currentRef.currentIndex = currentIndex;
		
		if(currentPageNo <= currentRef.totalPageCount) {
		
		StaticLibrary.SHOW_PRE_LOADER();
		currentRef.audioManager.stopAudio();
		$(".module_title").html(_model.getLinearTOCDataArr()[currentChapter].pages[currentIndex].pageTitle);
		
		$(".pageNum").html((currentPageNo) + " of "+ currentRef.totalPageCount);
		$(".pageNum").attr("aria-label","Page number "+ currentPageNo + " of "+ currentRef.totalPageCount);
		
		if(currentPageNo == 1){
			$("#previousBtn").css({"opacity": "0.3", "pointer-events": "none"});
			$("#previousBtn").attr("tabindex", "-1");
			$("#previousBtn").prop('disabled', true);
			if(_model.getAppDataObj().linear == "true") {
				if(currentRef.menuStatusArr[currentChapter].pages[currentIndex].isVisited == "true") {
					$("#nextBtn").css({"opacity": "1", "pointer-events": "auto"});
					$("#nextBtn").attr("tabindex", "0");
					$("#nextBtn").prop('disabled', false);
				}
			}else{
				$("#nextBtn").css({"opacity": "1", "pointer-events": "auto"});
				$("#nextBtn").attr("tabindex", "0");
				$("#nextBtn").prop('disabled', false);
			}
			
		}else if(currentPageNo == currentRef.totalPageCount){
			$("#nextBtn").css({"opacity": "0.3", "pointer-events": "none"});
			$("#nextBtn").attr("tabindex", "-1");
			$("#nextBtn").prop('disabled', true);
			$("#previousBtn").css({"opacity": "1", "pointer-events": "auto"});
			$("#previousBtn").attr("tabindex", "0");
			$("#previousBtn").prop('disabled', false);
		}else{
			
			if(_model.getLinearTOCDataArr()[currentChapter].pages[currentIndex].templateType == "Assessment" && 
			   currentRef.menuStatusArr[currentChapter].pages[currentIndex].isVisited == "false") {
				$("#previousBtn").css({"opacity": "0.3", "pointer-events": "none"});
				$("#previousBtn").attr("tabindex", "-1");
				$("#previousBtn").prop('disabled', true);
				$("#nextBtn").css({"opacity": "0.3", "pointer-events": "none"});
				$("#nextBtn").attr("tabindex", "-1");
				$("#nextBtn").prop('disabled', true);
			}else{
				if(_model.getAppDataObj().linear == "true") {
					if(currentRef.menuStatusArr[currentChapter].pages[currentIndex].isVisited == "true") {
						$("#nextBtn").css({"opacity": "1", "pointer-events": "auto"});
						$("#nextBtn").attr("tabindex", "0");
						$("#nextBtn").prop('disabled', false);
					}else{
						$("#nextBtn").css({"opacity": "0.3", "pointer-events": "none"});
						$("#nextBtn").attr("tabindex", "-1");
						$("#nextBtn").prop('disabled', true);
					}
				}else{
					$("#nextBtn").css({"opacity": "1", "pointer-events": "auto"});
					$("#nextBtn").attr("tabindex", "0");
					$("#nextBtn").prop('disabled', false);
				}
				$("#previousBtn").css({"opacity": "1", "pointer-events": "auto"});
				$("#previousBtn").attr("tabindex", "0");
				$("#previousBtn").prop('disabled', false);
			}
			
		}

		currentRef.setActiveMenuIndex(currentIndex)
		
        $("#parentContainer").html('');

		currentRef.currentPageToLoadObj = _model.getLinearTOCDataArr()[currentChapter].pages[currentIndex];

		if(currentRef.currentPageToLoadObj.pageAudio != undefined &&
			currentRef.currentPageToLoadObj.pageAudio != "") {

				currentRef.audioManager.loadAudio(_model.getAppDataObj().baseURL + "/assets/media/audio/" +currentRef.currentPageToLoadObj.pageAudio);
				_model.setAudioStatus({
					status : "loaded",
					volume : null,
					type: "page-audio"
				});
				

		}else{
			_model.setAudioStatus({
				status : "no-audio",
				volume : null
			});
		}
		
		/* Making http request to content data json file of pages and pre loading images are executed in preloadDataHandler call back function */

		currentRef.updateTrackingData(null, null, currentRef.currentIndex); /*  suspend data, lesson, course completion and score Object, lesson location */

        var jsonURL = _model.getAppDataObj().baseURL + "/assets/data/content/" + currentRef.currentPageToLoadObj.templateJSON + "." + StaticLibrary.DATA_TYPE + "?version=" + StaticLibrary.generateRandom();

        var apiServiceLoadAppData = new APIService();
		apiServiceLoadAppData.loadFromExternalSource(jsonURL, "true", StaticLibrary.DATA_TYPE, null, currentRef.preloadDataHandler);

			if(currentRef.isMenuOpened) {
				currentRef.menuClickHandler();
			}

		}
		
    }

    this.externalDataLoadHandler = function (data) {
			
		/* Making http request to page templates and next set of blocks executed in loadExternalPageSuccessHandler call back function */

        var htmlURL = _model.getAppDataObj().templateLocation + currentRef.currentPageToLoadObj.templateName + ".html?version=" + StaticLibrary.generateRandom();

        var apiServiceLoadAppData = new APIService();
        apiServiceLoadAppData.loadFromExternalSource(htmlURL, "true", "html", null, currentRef.loadExternalPageSuccessHandler);

    }
	
	this.preloadDataHandler = function(data){
		
		 _model.setCurrentPageDataObj(data);
		
		var baseURL = _model.getAppDataObj().baseURL;
		
		var imgArr = data.pageContent.imagePreloadArry;
		
		currentRef.imageLoadIndex = 0;
		currentRef.totalImageCount = imgArr.length;
		
		if(currentRef.totalImageCount > 0){
			for(var i=0;i<imgArr.length;i++){
				var image = new Image();
				image.src = baseURL + '/assets/images/' +imgArr[i];
				image.addEventListener('load',currentRef.imageLoadListener,false);
				image.addEventListener('error',currentRef.imageLoadListener,false);
			}
		}else{
			currentRef.externalDataLoadHandler();
		}
	}
	
	this.imageLoadListener = function(e){
		currentRef.imageLoadIndex++;
		
		if(currentRef.totalImageCount == currentRef.imageLoadIndex){	
			currentRef.externalDataLoadHandler();
		}
	}

    //Add all the template that needs to be involved in the Framework in the below Switch case.
    this.loadExternalPageSuccessHandler = function (pageHTMLStr) {

		if ((_model.getAppDataObj().linear == "false")) {
			if(!$(".menu_active i").hasClass("pull-right")){
				$(".menu_active").append('<i class="fa fa-check-circle text-default pull-right"></i>');
			}
		}

        $("#parentContainer").html('');
        $("#parentContainer").html(pageHTMLStr).promise().done(function () {
			
            currentTemplate = currentRef.currentPageToLoadObj.templateName;
            currentTemplateObj;

			/* Initialize the appropriate template scripts */

            switch (currentTemplate) {

				case "TextBackgroundImageTemplate":
					currentTemplateObj = new TextBackgroundImageTemplateController(currentRef);
				break;	
				
				case "FloatingTextBgImageTemplate":
					currentTemplateObj = new FloatingTextBgImageTemplateController(currentRef);
				break;

				case "AssessmentTemplate":
                    currentTemplateObj = new FormativeAssessmentTemplateController(currentRef);
				break;
				
				case "SelectAndRevealTemplate":
					currentTemplateObj = new SelectAndRevealTemplateController(currentRef);
				break;

				case "DragandDropCombinedTemplate":
                    currentTemplateObj = new DragandDropCombinedTemplateController(currentRef);
				break;

				case "DropDownListTemplate":
                    currentTemplateObj = new DropDownListTemplateController(currentRef);
				break;
				
				case "Fill_In_the_Blanks_Template":
                	currentTemplateObj = new Fill_In_the_Blanks_TemplateController(currentRef);
				break;	

				case "FlashcardTemplate":
                	currentTemplateObj = new FlashcardTemplateController(currentRef);
				break;

				case "Glossary":
                	currentTemplateObj = new GlossaryController();
                break;

				case "ResultPageTemplate":
					currentTemplateObj = new ResultPageTemplateController(currentRef);
				break;

				case "TabTemplate":
                	currentTemplateObj = new TabTemplateController(currentRef);
				break;
				
				case "TextAndImageTemplate":
                	currentTemplateObj = new TextSingleImageTemplateController(currentRef);
				break;
				
				case "VideoTemplate":
                	currentTemplateObj = new VideoTemplateController(currentRef);
				break;
				
                default:
                    trace(":: Template not found, please check with administrator ::");
                break;
            }

            currentTemplateObj.init(_model.getCurrentPageDataObj());

            $("#paginationTxt").html('');
            $("#paginationTxt").html("Page " + (currentRef.currentIndex + 1) + " of " + _model.getTOCDataArr().length);


            $("#audioTranscriptPopupContainer").html('');
            $("#audioTranscriptPopupContainer").html(_model.getTOCDataArr()[currentRef.currentIndex].transcript);
		   	   
			if(currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc == undefined){
				
				if(currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].isVisited == "false"){
					
					$("#main-content").focus();
				}
			}else{
				if(currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.completed == "false") {
					$("#main-content").focus();
				}
			}

			if(_model.getAppDataObj().linear == "false") {
				if(currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc == undefined) {
					if(currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].isVisited != "true"){
						currentRef.updateMenuNdTrackingStatus("visited", null);
					}
				}	
			}else{
				if(currentRef.currentPageToLoadObj.pageAudio == undefined ||
					currentRef.currentPageToLoadObj.pageAudio == "" ) {
						if(currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc == undefined) {
							if(currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].isVisited != "true"){
								currentRef.updateMenuNdTrackingStatus("visited", null);
							}
						}
					}
			}
			
		});
		
		if(_model.getAudioStatus().status == "no-audio") {
			StaticLibrary.HIDE_PRE_LOADER();
			var svg = $('.pause-play-flag svg');
			var svgClass;
			if(svg.attr("class").indexOf("fa-pause") > 0) {
                svgClass = svg.attr("class").replace("fa-pause", "fa-play");
             }else if(svg.attr("class").indexOf("fa-redo-alt") > 0) {
                svgClass = svg.attr("class").replace("fa-redo-alt", "fa-play");
			 }
			 svg.attr("class", svgClass);
		}else{
			currentRef.audioManager.playAudio();
			var svg = $('.pause-play-flag svg');
			var svgClass;
			if(svg.attr("class").indexOf("fa-play") > 0) {
                svgClass = svg.attr("class").replace("fa-play", "fa-pause");
             }else if(svg.attr("class").indexOf("fa-redo-alt") > 0) {
                svgClass = svg.attr("class").replace("fa-redo-alt", "fa-pause");
             }
			svg.attr("class", svgClass);
			_model.setAudioStatus({
                status : "playing",
                volume : null
			});
			$(".pause-play-flag").attr('name', 'pause');
			$(".pause-play-flag").attr('title', 'pause');
		}

		if(currentRef.currentPageToLoadObj.transcript != undefined) {
			$(".transcript-body > span").html(currentRef.currentPageToLoadObj.transcript);
		}else{
			$(".transcript-body > span").html("");
		}
		
	}
	
	this.setActiveMenuIndex = function(currentIndex) {
		var activeMenuIndex = 0;
		var kcDetected = false;
		for(var i = 0; i < (currentIndex+1); i++ ) {
			if(currentRef.menuStatusArr[currentRef.curChapterIndex].pages[i].kc != undefined) {
				if(kcDetected == false) {
					activeMenuIndex++;
					kcDetected = true;
				}
			}else{
				kcDetected = false;
				activeMenuIndex++;
			}
		}
		currentRef.activeMenuIndex = --activeMenuIndex;

		$(".active-page").each(function() {
			$(this).removeClass("active-page");
		});
		currentRef.menuItems.find("li").eq(currentRef.activeMenuIndex).
		find("a").addClass("active-page")

	}
	
    //function to control the visibility of the framework level page loading.
    this.controlVisibility = function (currentView) {

		$("#" + currentView).show();
		
    }
	
	//Check Chapter Completion Status
	this.getChapterCompletionStatus = function(){
		var pageCompletionCount = 0;
		var chapterCompletionCount  = 0;
		var totalKcQuestions = 0;
		var passedKcQuestions = 0;
		var totalScore;
		var lessonStatus;
		if( currentRef.menuStatusArr[currentRef.curChapterIndex].pages.length != undefined ){
			for(var j=0;j<currentRef.menuStatusArr[currentRef.curChapterIndex].pages.length;j++){
				if(currentRef.menuStatusArr[currentRef.curChapterIndex].pages[j].isVisited == "true"){
						pageCompletionCount++;
				}
				if(currentRef.menuStatusArr[currentRef.curChapterIndex].pages[j].kc != undefined) {
					totalKcQuestions++;
					if(currentRef.menuStatusArr[currentRef.curChapterIndex].pages[j].kc.score == 1) {
						passedKcQuestions++;
					}
				}
			}
			
			if(pageCompletionCount == currentRef.menuStatusArr[currentRef.curChapterIndex].pages.length){
				currentRef.menuStatusArr[currentRef.curChapterIndex].status = "COMPLETED";
			}
		}


        for(var i=0;i<currentRef.menuStatusArr.length;i++){
			if(currentRef.menuStatusArr[i].status == "COMPLETED"){
				chapterCompletionCount++;	
			}
		}

		totalScore = 	Math.round((passedKcQuestions / totalKcQuestions) * 100);

		if(chapterCompletionCount == currentRef.menuStatusArr.length){	
			if(totalKcQuestions > 0) {
				
				if(totalScore >= 50){
					lessonStatus = "passed";
				}else{
					lessonStatus = "failed";
				}
			}else{
				lessonStatus = "completed";
			}
			
			return {
				lessonStatus: lessonStatus,
				courseStatus: "completed",
				score: totalScore
			}
		}else{
			return {
				lessonStatus: "incomplete",
				courseStatus: "incomplete",
				score: totalScore
			}
		}
	

	}

	this.makeResponsiveWith = function(selector) {
		var selectorHeight = $(selector).outerHeight();
		if(selectorHeight > (window.innerHeight - 100)) {
			$(".assessment-template").outerHeight(selectorHeight+100)
		}
	}

	this.updateTrackingData = function (suspendData, courseStatusObj, lessonLocation) {
		if (_model.getAppDataObj().scorm) {
			if(suspendData != null) {
				_model.getScormReference().storeTrackingData( JSON.stringify(suspendData) ); 
			}
			if(courseStatusObj != null) {
				_model.getScormReference().storeCompletionStatus(courseStatusObj.lessonStatus);
				_model.getScormReference().storeAssessmentScore(courseStatusObj.score);
			}
			if(lessonLocation != null) {
				_model.getScormReference().storeVisitedScreenNo(lessonLocation);
			}
			
        }else {
			if(suspendData != null) {
				localStorage.setItem(_model.getAppDataObj().courseName+'_v2',JSON.stringify(currentRef.menuStatusArr) );	
			}
			if(courseStatusObj != null) {
				console.log("LESSON STATUS",courseStatusObj.lessonStatus);
				console.log("SCORE",courseStatusObj.score);
			}
			if(lessonLocation != null) {
				console.log("SCREEN NO",lessonLocation);
			}
			
		}
	}

}