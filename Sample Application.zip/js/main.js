
var getDataJSON = function(url, callback) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.responseType = 'json';
    xhr.onload = function() {
      var status = xhr.status;
      if (status === 200) {
        callback(xhr.response);
      } 
    };
    xhr.send();
};

getDataJSON("data/content.json", DataJsonSuccessHandler);

function DataJsonSuccessHandler(data) {
    ApplicationController(data);
}
