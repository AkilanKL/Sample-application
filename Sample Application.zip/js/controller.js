ApplicationController = function(jsonData) {
    var controller = this;

    controller.currentIndex = 1;
    controller.jsonData = jsonData;

    var nextButton = document.getElementById("nextpage-button");
    var previousButton = document.getElementById("previouspage-button");

    setTimeout(function () {
        nextButton.addEventListener("click", controller.nextButtonClickHandler);
        previousButton.addEventListener("click", controller.previousButtonClickHandler);
    }, 200)

    controller.courseTrackingObj;

    var storedCourseTrackingObj = localStorage.getItem("courseTrackingObj");

    if(storedCourseTrackingObj == null || storedCourseTrackingObj == ""){
        controller.courseTrackingObj = [];
        for(var i = 0; i < jsonData.length; i++) {
            controller.courseTrackingObj.push({isVisited: "false", score: 0, attemptCount: 0});
        }
    }else{
        controller.courseTrackingObj = JSON.parse(storedCourseTrackingObj);
    }

    this.nextButtonClickHandler = function () {
        controller.currentIndex++;
        controller.loadTemplate(controller.currentIndex);
        
    }

    this.previousButtonClickHandler = function () {
        controller.currentIndex--;
        controller.loadTemplate(controller.currentIndex);
       
    }

    this.getHtmlTemplate = function(url, callback) {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', url, true);
        xhr.onload = function() {
          var status = xhr.status;
          if (status === 200) {
            callback(xhr.response);
          } 
        };
        xhr.send();
    }

    this.loadTemplate = function (currentIndex) {

        if(controller.currentIndex == jsonData.length) {
            nextButton.style.opacity = "0.3";
            nextButton.style.pointerEvents = "none";
        }else{
            nextButton.style.opacity = "1";
            nextButton.style.pointerEvents = "auto";
           
        }

        if(controller.currentIndex == 1) {
            previousButton.style.opacity = "0.3";
            previousButton.style.pointerEvents = "none";
        }else{
            previousButton.style.opacity = "1";
            previousButton.style.pointerEvents = "auto";
        }

        controller.currentTemplate =  jsonData[currentIndex - 1].templateName;
        var htmlTemplateURL = "templates/html/" + controller.currentTemplate + ".html";
        controller.getHtmlTemplate(htmlTemplateURL, controller.htmlTemplateSuccessHandler);
    }

    this.htmlTemplateSuccessHandler = function (html) {
        $("#parent-container").html("").html(html).promise().done(function () {
            switch(controller.currentTemplate) {
                case "multipleChoiseTemplate":
                            var templateController = new MultipleChoiseController();
                            templateController.init(controller.jsonData[controller.currentIndex - 1], controller);
            }
        })

    }

    this.storeTrackingData = function (trackingDta) {
        console.log(trackingDta)
        localStorage.setItem("courseTrackingObj", JSON.stringify(trackingDta));
    }

    this.loadTemplate(controller.currentIndex);





}