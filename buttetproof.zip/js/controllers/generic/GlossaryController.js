/**
 * Created by Venkatesh on 8/16/2016.
 */

var GlossaryController = function(){

	var _this = this;	
	var glossaryData, innerCount, hasGlossary, className, tempSrc, glossaryMenuLoop;

    this.init = function(data){
		_this.glossaryData = data.glossary;
        _this.paintUI();
    }
	
	this.innerGlossary = function(data, glossaryData){
		
		$(".glossary_"+glossaryData).append("<span class='screenGlossaryCallout'><span class='glossaryTextScreen upper'></span></span>");
		
		for(var i = 0; i < data.glossary.length; i++){
			if(data.glossary[i].alphabetContent.length > 0){
				for(var j = 0; j < data.glossary[i].alphabetContent.length; j++){
					if(data.glossary[i].alphabetContent[j].menu == glossaryData){
						console.log(data.glossary[i].alphabetContent[j].content);
						$(".glossary_"+glossaryData).find(".glossaryTextScreen").html("").html(data.glossary[i].alphabetContent[j].content);
						$(".glossary_"+glossaryData).find(".screenGlossaryCallout").show();
						//$(".glossaryTextScreen").html("").html(data.glossary[i].alphabetContent[j].content)
					}
				}
			}
		}
	}
	
    this.paintUI = function(){

		$("#alphabetContainer, #glossaryMenu, #glossaryDescription").html('');
		tempSrc = "<button data-innerid='all' > All </button>";
		for(var i = 0; i < _this.glossaryData.length; i++){
			hasGlossary = _this.glossaryData[i].alphabetContent.length;
			if(hasGlossary){
				tempSrc += "<button data-innerid='" + i + "' >"+ _this.glossaryData[i].alphabet.toUpperCase() +"</button>";
			}else{
				tempSrc += "<button data-innerid='" + i + "' class='noGlossary' tabindex='-1'>"+ _this.glossaryData[i].alphabet.toUpperCase() +"</button>";
			}
			
		}	
		
		$("#alphabetContainer").html(tempSrc);
		$("#alphabetContainer button").unbind("click").bind("click", _this.alphabetMenuList);
		
		$("#alphabetContainer button:eq(0)").trigger('click'); // For displaying active to first
	}
	
	this.alphabetMenuList = function(event){
		$("#alphabetContainer button").removeClass("active");
		$("#glossaryDescription, #glossaryMenu button").empty();

		if(event.currentTarget.dataset.innerid != "all") {
			innerCount = (_this.glossaryData[event.currentTarget.dataset.innerid].alphabetContent).length;
			glossaryMenuLoop = "";
			for(var j = 0; j < innerCount; j++){
				glossaryMenuLoop += "<button data-innerid='" + event.currentTarget.dataset.innerid + "' data-outerid='" + j + "'>"+ _this.glossaryData[event.currentTarget.dataset.innerid].alphabetContent[j].menu +"</button>";
			} 
		}else{
			glossaryMenuLoop = "";
			innerCount = _this.glossaryData.length
			for(var j = 0; j < innerCount; j++){
				if(_this.glossaryData[j].alphabetContent.length) {
					for(var k = 0; k < _this.glossaryData[j].alphabetContent.length; k++) {

						glossaryMenuLoop += "<button data-innerid='" + j + "' data-outerid='" + k + "'>"+ _this.glossaryData[j].alphabetContent[k].menu +"</button>";

					}
				}

			} 
		}
		
		$("#glossaryMenu").html('').html(glossaryMenuLoop);
		$("#glossaryMenu button").unbind("click").bind("click", _this.alphabetDescriptionList);	
		
		$("#glossaryMenu button:eq(0)").trigger('click');	// For displaying active to first
		
		$(this).addClass("active");
	}
	
	this.alphabetDescriptionList = function(event){
		$("#glossaryDescription").empty();
		$("#glossaryMenu button").removeClass("active");
		$(this).addClass("active");
		$("#glossaryDescription").html('').html("<p>"+ _this.glossaryData[event.currentTarget.dataset.innerid].alphabetContent[event.currentTarget.dataset.outerid].content +"</p>");
	}
	
}