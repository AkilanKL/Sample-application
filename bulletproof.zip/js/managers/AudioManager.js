var AudioManager = function(){

    var audioReference = this;
    this._model = DataManager.getInstance();
    this.volume = 1;

    this.loadAudio = function(currentAudioURL){
        trace(":: Audio Manager - Load Audio :: "+ currentAudioURL);

        audioReference._model.getAudioReference().jPlayer(
            "setMedia", {
                mp3: currentAudioURL + ".mp3"
            });
        //audioReference.playAudio();
    }

    this.playAudio = function(){
        trace(":: Audio Manager - Play Audio ::");
        audioReference._model.getAudioReference().jPlayer("play");

    }

    this.pauseAudio = function(){
        console.trace()
        trace(":: Audio Manager - Pause Audio ::");
        audioReference._model.getAudioReference().jPlayer("pause");
    }

    this.stopAudio = function(){
        trace(":: Audio Manager - Stop Audio ::");
        audioReference._model.getAudioReference().jPlayer("stop");
    }
	
	this.muteAudio = function(){
        trace(":: Audio Manager - mute Audio ::");
        audioReference._model.getAudioReference().jPlayer("volume", 0);
        audioReference._model.getAudioReference().jPlayer("mute");
    }
	
	this.unMuteAudio = function(){
        trace(":: Audio Manager - unmute Audio ::");
        audioReference._model.getAudioReference().jPlayer("volume", audioReference.volume);
        audioReference._model.getAudioReference().jPlayer("unmute");
    }

    this.volumeControl = function(vol) {

        audioReference.volume = vol;
 
        audioReference._model.getAudioReference().jPlayer("volume", vol);
    }

    this.getCurrentTime = function(){
        trace(":: Audio Manager - getCurrentTime of Audio ::");
    }

    this.getTotalTime = function(){
        trace(":: Audio Manager - getTotalTime of Audio ::");
    }
}