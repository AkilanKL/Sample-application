var DragandDropCombinedTemplateController = function (currentRef) {
    _this = this;
    var jsonData;
    var zIndex = 1;
    var dragOverOutPosition,
    submitBtn,
    resetBtn,
    totalOptions,
    draggaleOptions,
    dropArea;
    var draggedOptions = 0;
    //var globalController, trackingObj, topicName, templateIndex;
    var attemptCount = 0;

    var tableHeading = document.querySelector(".drag-drop-heding");
    var tableBody = document.querySelector(".drag-drop-body");
    var tableBodyMob = document.querySelector(".mob-drag-drop-options");

    var correctOptSequence = [];
    
    this.attemptedCount = 0;
    this.focusedEleDrag;
    this.focusedEleDrop;
	
	this.init = function (jsonData) {
		_this.loadUI(jsonData);
		
	 }

    this.loadUI = function (data, controller) {

        jsonData = data;

        var oprtionArray = [];
        var oprtionArrayMobile = [];

        function shuffleOptionArray(arr, arrMob) {
            for(var i = arr.length-1; i >= 0 ;i--) {
                var j = Math.floor(Math.random() * (i + 1));
                //correct options sequence array
                correctOptSequence[(arr[j].index)-1] =  i+1;

                var temp = arr[i];
                var tempMob = arrMob[i];
                arr[i] = arr[j];
                arrMob[i] = arrMob[j];
                arr[j] = temp;
                arrMob[j] = tempMob;

                arr[i].option.querySelector(".drag-drop-option").dataset.dragposition = i+1;
                arrMob[i].dataset.dragposition = i+1;
                
                }
            }
            
                // load heading contents
                jsonData.pageContent.heading.forEach(element => {                
                    var tempth = document.createElement("th");
                    tempth.classList.add("drag-drop-heading");
                    tempth.innerHTML = element;
                    tableHeading.appendChild(tempth);
                });

                // load options for mobile devices
                jsonData.pageContent.content.forEach((content, i) => {
                    var tempdiv = document.createElement("div");
                    tempdiv.classList.add("drag-drop-option");
                    tempdiv.innerHTML = content.option;

                    oprtionArrayMobile.push(tempdiv);
                    
                });

                 // load options for non mobile devices
                 jsonData.pageContent.content.forEach((content, i) => {
                    var tempopt = document.createElement("td");
                    tempopt.classList.add("td-opt");
                    tempopt.innerHTML =  ` <div aria-grabbed="false" tabindex="0" role="listitem" class="drag-drop-option">${content.option}</div> `;
                    oprtionArray.push({index: (i+1), option: tempopt});
                });

                shuffleOptionArray(oprtionArray, oprtionArrayMobile);

                // load body contents
                jsonData.pageContent.content.forEach((content, i) => {
                    var temptr = document.createElement("tr");
                    temptr.classList.add("drag-drop-elements");
                    var temptds = `
                                <td class="drag-drop-ques-text">${content.question}</td>
                                <td><div class="drop-area"><span>Drop area</span></div></td>
                               `
                    temptr.innerHTML = temptds;
                    temptr.appendChild(oprtionArray[i].option)

                    tableBody.appendChild(temptr)
                    
                });
        
        var tempth = document.createElement("th");
        tableHeading.appendChild(tempth);

        oprtionArrayMobile.forEach(element => {
            tableBodyMob.appendChild(element)
        });

        if( currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.completed == "false" ){
            currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.ac = 
            data.pageContent.maxAttempt || 0;
            _this.attemptedCount = currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.acTaken

            submitBtn = document.getElementById("submit-btn");
            resetBtn = document.getElementById("reset-btn");
    
            submitBtn.addEventListener("click", _this.submitButtonHandler);
            resetBtn.addEventListener("click", _this.resetButtonHandler);
    
            _this.attachDragDropOptions();
            _this.initKeyboardAccessibility();
      }else{
        _this.showAnswer("ansOnly");
      }


   
    }

    this.attachDragDropOptions = function () {
        draggaleOptions =  $(".drag-drop-option");
        dropArea = $(".drop-area");
        totalOptions = draggaleOptions.length / 2;

        draggaleOptions.draggable({
            containment: "#drag-drop-container",
            zIndex: zIndex,
            scrollSpeed: 10,
            scroll: true,
            revert: true,
            start: function() {               
                zIndex++;
                $(".ui-draggable,.drag_options").css("z-index","9");
				$(this).css("z-index","10");
				
			}
        })

        dropArea.droppable({
            hoverClass: "drop-hover",
            drop: function (e, ui) {
                var that = $(this);
                _this.dropEvent(ui, that, "drag");
            },
            over: function () {
                dragOverOutPosition = "over";
            },
            out: function () {
                dragOverOutPosition = "out";
            }

            
        });

        
    }

    this.submitButtonHandler = function () {
    if( currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.completed == "false" ){
        _this.attemptedCount++;
        var submitedAnswers = $(".drop-area .drag-drop-option");

        var isAnwserValid;
        submitedAnswers.each(function (i) {
            currentAnsDataIndex = $(this).data("dragposition");

            if(currentAnsDataIndex != correctOptSequence[i]){
                isAnwserValid = false;
               return false;
            }
            if(i == (totalOptions-1)){
                isAnwserValid = true;
            }
        });

        if(isAnwserValid) {
            var tempObj = {
                score: 1,
                attemptsTaken: _this.attemptedCount,
                completed: "true"
            }
            currentRef.updateMenuNdTrackingStatus("visited", tempObj);
            _this.showAnswer("well done");
            if(_model.getLinearTOCDataArr()[currentRef.curChapterIndex].pages[currentRef.currentIndex].templateType == "Assessment") {
                setTimeout(function() {
                    currentRef.nextClickHandler();
                }, 2000);
            }   

        }else{
           
            if(_this.attemptedCount == currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.ac) {
                var tempObj = {
                    score: 0,
                    attemptsTaken: _this.attemptedCount,
                    completed: "true"
                }
                currentRef.updateMenuNdTrackingStatus("visited", tempObj);
                _this.showAnswer("incorrect submit");
                if(_model.getLinearTOCDataArr()[currentRef.curChapterIndex].pages[currentRef.currentIndex].templateType == "Assessment") {
                    setTimeout(function() {
                        currentRef.nextClickHandler();
                    }, 2000);
                }
            }else{
                var tempObj = {
                    score: 0,
                    attemptsTaken: _this.attemptedCount,
                    completed: "false"
                }
                $("#main-content").focus();
                currentRef.updateMenuNdTrackingStatus(null, tempObj);
            }
        }
    }
    }

    this.addDragEvent = function() {
        $(".drag-drop-option-new").draggable({
            containment: "#drag-drop-container",
            zIndex: zIndex,
            scroll: true,
            revert: function () {
                return dragOverOutPosition != "out";
            },
            drag : function(e, ui) {
                
            },
            start: function () {
                dragOverOutPosition = "over";
                $(this).parent().droppable({
                    disabled: false
                  });
                  zIndex++;
                  $(".ui-draggable").css("z-index","9");
            $(this).css("z-index","10");

            },
            stop: function(e, ui) {
                $(this).parent().html("<span>Drop area</span>");
                if(dragOverOutPosition == "out"){
                    var draggedElePos = $(this).data("dragposition");
                    $("[data-dragPosition= "+draggedElePos+"]").css({"visibility":"visible"});
                    draggedOptions--;
                }

                if(draggedOptions < totalOptions) {
                    submitBtn.classList.remove("activate-submit");
                }
                if(draggedOptions == 0) {
                    resetBtn.classList.remove("activate-reset");
                }
            }
        })
    }

    this.dropEvent = function(ui, that, type) {
        var droppedItem, ansIndex, uiDraggable;

        if(type == "drag"){
            uiDraggable = ui.draggable;
        }else{
            uiDraggable = ui;
            ui.removeClass("focused-drag-item");
        }
        uiDraggable.removeAttr("tabindex")
        droppedItem = $(uiDraggable).clone();
        ansIndex = $(uiDraggable).data("ans-index");
        droppedItem.data("ans-index", ansIndex);

        if(!droppedItem.hasClass("drag-drop-option-new")) {
            draggedOptions++;
            
        }
        resetBtn.classList.add("activate-reset");
        if(draggedOptions == totalOptions) {
            submitBtn.classList.add("activate-submit");
        }
       
        $("[data-dragposition="+uiDraggable.data("dragposition")+"]").css({"visibility":"hidden"});
        droppedItem.css({"position":"relative","left": 0, "top": 0});
        droppedItem.addClass("drag-drop-option-new");

        that.html(droppedItem);
        that.droppable({
            disabled: true
          });
        if(dragOverOutPosition == "over"){
            _this.addDragEvent();
        }
        
}


    this.resetButtonHandler = function () {
        submitBtn.classList.remove("activate-submit");
        resetBtn.classList.remove("activate-reset");
        draggedOptions = 0;
        draggaleOptions.each(function() {
            $(this).css("visibility","visible");
        });
        dropArea.each(function() {
            $(this).html("<span>Drop area</span>");
        });
        dropArea.droppable({
            disabled: false
        });
    }

    this.showAnswer = function(type) {
        
        if(type == "ansOnly") {
            $("#drag-drop-container").html(_this.displayCorrectAns());
        }else if(type == "well done") {
            submitBtn.classList.remove("activate-submit");
            resetBtn.classList.remove("activate-reset");
            $(".drag-drop-option").draggable({ disabled: true });
            $(".drag-drop-option").css({"pointer-events": "none"})
        }else if(type == "incorrect submit") {
            submitBtn.classList.remove("activate-submit");
            resetBtn.classList.remove("activate-reset");
            $(".drag-drop-option").draggable({ disabled: true });
            $(".drag-drop-option").css({"pointer-events": "none"})
           
        }
    }

    this.displayCorrectAns = function() {
        var table = document.createElement("table");
        var thead = document.createElement("thead");
        var tbody = document.createElement("tbody");

        var heading = "";
        var bodyContent = "";

         // load heading contents to display
         jsonData.pageContent.heading.forEach(element => {       
             heading += `<th class="drag-drop-heading">${element}</th>`;       
        });
         // load body contents to display
         jsonData.pageContent.content.forEach((content, i) => {
            bodyContent += '<tr class="drag-drop-elements"><td class="drag-drop-ques-text">'+content.question+'</td><td class="ans-td-opt">'+content.option+'</td></tr>';
        });
        var temptr = document.createElement("tr");
        temptr.innerHTML = heading;
        thead.appendChild(temptr);
        tbody.innerHTML = bodyContent;
        table.appendChild(thead);
        table.appendChild(tbody);
        return table;
    }

    this.dragClickHandler = function() {

        if($(this).css("visibility") == "visible"){

        }
    }

    this.dropClickHandler = function() {
        
    }

    this.initKeyboardAccessibility = function() {
        $(".drag-drop-body").off("keydown").on("keydown", function(event) {
            
            if(event.keyCode == 32) {

                _this.focusedEleDrag = $("*:focus");

                if(_this.focusedEleDrag != null &&
                _this.focusedEleDrag.css("visibility") == "visible" &&
                _this.focusedEleDrag.hasClass("drag-drop-option")) {
                    _this.focusedEleDrag.addClass("focused-drag-item");
      
                    $(".drag-drop-option").each(function() {
                        $(this).attr("tabindex","-1");
                        $("#main-content").focus();
                    });

                    $(".drop-area").each(function() {
                        if(!$(this).children().hasClass("drag-drop-option")){
                            $(this).attr("tabindex","0");
                        }
                    });
                }
            }

            if(event.keyCode == 13) {

                _this.focusedEleDrop = $("*:focus");
                if(_this.focusedEleDrop != null && _this.focusedEleDrop.hasClass("drop-area")) {
                    $(".drop-area").each(function() {
                        $(this).attr("tabindex","-1");
                    });
                    $(".drag-drop-option").each(function() {
                        if($(this).css("visibility") == "visible" && !$(this).parent().hasClass("drop-area")){
                            $(this).attr("tabindex","0");
                            $("#main-content").focus();
                        }
                    });
                    _this.dropEvent(_this.focusedEleDrag, _this.focusedEleDrop, "tab");
                }

            }

        });
    }


    
}

