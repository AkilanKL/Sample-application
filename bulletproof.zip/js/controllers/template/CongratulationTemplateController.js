/**
 * Created by Ravi Sharma on 8/11/2016.
 */

var CongratulationTemplateController = function(){

    var _this = this;
	var currentData;
    this.init = function(data){
        trace(":: Congratulation Template Controller Loaded ::");
		_this.currentData = data;
        _this.loadUI(data);
    }

    this.loadUI = function(data){
       
        $("#heading-thankyou").html("").html(data.pageContent.heading);
        $("#content").html("").html(data.pageContent.content);
        

		$("#innerHead").html(data.pageContent.formtext);
        $("#conInnerText").html(data.pageContent.coursetitle);
        
	
		
    }
	
	this.clear = function(){

	}
}