/**
 * Created by Rajendran on 22/03/2017.
 */

var DropDownListTemplateController = function(currentRef){

    var _this = this;
	var currentData;
	var attemptCount = 0;
	this.attemptedCount = 0;

    this.init = function(data){
        trace(":: Drop Down List Template Loaded ::");
 
        _this.currentData = data;
        _this.loadUI(_this.currentData);

		//$("#parentContainer").attr('tabindex','0').focus();
    }
	
	this.clear = function(){
		
	}
	
    this.loadUI = function(data){
        trace(":: Paint the Drop Down List Template UI ::");
        trace(data);
		
		$("#heading").html('').html(data.pageContent.heading);
		$("#content").html('').html(data.pageContent.content);
		
		
		if(isAndroid){
			$("#content,#heading").attr('tabindex','0');	
		}
		
		var divCnt = "";
		 
		for(var i=0; i< data.pageContent.textToLoad.length; i++){
			
			if (navigator.userAgent.indexOf('Mac OS X') != -1) {

				divCnt +=  '<div class="check_box_option" id="question_'+i+'" ><div class="dession_image"    ><img id="green_tick_'+i+'" src="assets/images/green_tick.png" alt="Right" style="display:none;"  /><img id="red_tick_'+i+'" src="assets/images/cross_tick.png" alt="Wrong" style="display:none;"/></div><div class="check_box_input checkbox checkbox-primary select_box"><label for="select_'+i+'">'+data.pageContent.textToLoad[i].Question+'</label><div class="select"><select role="list" aria-label="'+data.pageContent.textToLoad[i].Question+'dropdown button" class="select_box2" id="select_'+i+'"><option value="">Select</option>';
				
				for(var j=0;j<data.pageContent.textToLoad[i].Options.length ;j++){
					
				
					divCnt +='<option value="'+j+'">'+data.pageContent.textToLoad[i].Options[j].Values+'</option>';
				}
				
				divCnt += '</select></div></div><div id="suggest_answer'+i+'"></div></div>'; 

			} else {
				
				divCnt +=  '<div class="check_box_option" id="question_'+i+'" ><div class="dession_image"    ><img id="green_tick_'+i+'" src="assets/images/green_tick.png" alt="Right" style="display:none;"  /><img id="red_tick_'+i+'" src="assets/images/cross_tick.png" alt="Wrong" style="display:none;"/></div><div class="check_box_input checkbox checkbox-primary select_box"><label for="select_'+i+'">'+data.pageContent.textToLoad[i].Question+'</label><div class="select"><select class="select_box2" id="select_'+i+'"><option value="">Select</option>';
				
				for(var j=0;j<data.pageContent.textToLoad[i].Options.length ;j++){
					
					divCnt +='<option value="'+j+'">'+data.pageContent.textToLoad[i].Options[j].Values+'</option>';
				}
				
				divCnt += '</select></div></div><div id="suggest_answer'+i+'"></div></div>'; 
				
			}
			 
		} 
		//aria-live="assertive" aria-atomic="true"
		$("#Questions").html(divCnt); 
		//validation
		
		//$( ".select" ).bind( "click", _this.selectClickHandler); 
					
		$("#dropdown_show").addClass('chk_btn2').prop("disabled", true).css("pointer-events","none");
		
		$("#dropdown_smt").addClass('chk_btn2').prop("disabled", true);
		
		$("#dropdown_reset").addClass('chk_btn2').prop("disabled", true).removeClass("activate-reset");
		
			
		
		$(".select_box2").unbind("click").bind("click", function(){
			$(this).parent().addClass("focus");
		});
		
		if(isIPAD){
			$("select").removeAttr('role');	
		}
		
		if(isAndroid){
			$("label").attr('tabindex','0');
		} 
		
		
		$('.resetBtn , .checkBtn').on('focusin',function(){
				$(this).find('span').html('');
		});

		if( currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.completed == "false" ){
            currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.ac = 
            data.pageContent.maxAttempt || 0;
            _this.attemptedCount = currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.acTaken
			$( "select" ).bind( "change", _this.validateClickHandler); 
			$("#dropdown_smt").unbind("click").bind("click", _this.buttonClickHandler);
			$("#dropdown_reset").unbind("click").bind("click", _this.resetClickHandler);
			$("#dropdown_show").unbind("click").bind("click", _this.showClickHandler);		
           
      }else{
       _this.showClickHandler();
      }
					
    }
	
	this.buttonClickHandler = function(){
		_this.attemptedCount++;
		
			var feedbackStr = '';
			
			var t=0;
			for(var k=0;k<_this.currentData.pageContent.textToLoad.length;k++){
				
				trace('submit');
				
				var selectedNum = $("#select_"+k).val();
				
				$("#suggest_answer"+k).empty();
				$("#red_tick_"+k).hide();
				$("#green_tick_"+k).hide();
				
				console.log( $("#select_"+k).val() );
				
				if( $("#select_"+k).val() != ""){
					//if(_this.currentData.pageContent.textToLoad[k].Answer== $("#select_"+k).val()){		
					if(_this.currentData.pageContent.textToLoad[k].Options[selectedNum].correct == "true"){		
						feedbackStr = feedbackStr + 'Question  '+ (k+1) + ' Your answer is correct' + _this.currentData.pageContent.textToLoad[k].Question +_this.currentData.pageContent.textToLoad[k].Options[selectedNum].Answer;
						$("#green_tick_"+k).show();
						/* $("#suggest_answer"+k).append("<div class='right_msg' style='display:block;'><p>"+_this.currentData.pageContent.textToLoad[k].Ans_suggestion+"</p></div>"); */
						$("#suggest_answer"+k).append("<div class='right_msg' style='display:block;'><p>"+_this.currentData.pageContent.textToLoad[k].Options[selectedNum].Answer+"</p></div>");
						t++;
					}else{
						feedbackStr = feedbackStr + 'Question  '+ (k+1) + ' Your answer is not right' + _this.currentData.pageContent.textToLoad[k].Question +_this.currentData.pageContent.textToLoad[k].Options[selectedNum].Answer;
						$("#red_tick_"+k).show();
						//$("#suggest_answer"+k).append("<div class='wrong_msg' style='display:block;'><p>"+_this.currentData.pageContent.textToLoad[k].Ans_suggestion+"</p></div>");	
						$("#suggest_answer"+k).append("<div class='wrong_msg' style='display:block;'><p>"+_this.currentData.pageContent.textToLoad[k].Options[selectedNum].Answer+"</p></div>");
					}
				}
				
				$( "select" ).prop("disabled", true).css("pointer-events","none");
				$("#dropdown_smt").addClass('chk_btn2').prop("disabled", true).removeClass("activate-submit").addClass('disable');;
				
				$("#dropdown_reset").removeClass('chk_btn2').prop("disabled", false).addClass("activate-reset").removeClass('disable').find('span').html('');
				
				if(attemptCount > 1){
					$("#dropdown_show").removeClass('chk_btn2').prop("disabled", false).css("pointer-events","auto").removeClass('disable').find('span').html('');
					$("#dropdown_reset").addClass('chk_btn2').prop("disabled", true).removeClass("activate-reset").addClass('disable').find('span').html('');
				}
				if(isIPAD || isAndroid){
					$("#stateUpdate").html(feedbackStr);		
				}else{
					$("#stateUpdate").attr('tabindex','0').html(feedbackStr).focus();
				}
				
				if(t==_this.currentData.pageContent.textToLoad.length){
					
					$("#dropdown_show").addClass('chk_btn2').prop("disabled", true).css("pointer-events","none").addClass('disable');
					var tempObj = {
						score: 1,
						attemptsTaken: _this.attemptedCount,
						completed: "true"
					}
					currentRef.updateMenuNdTrackingStatus("visited", tempObj);
					if(_model.getLinearTOCDataArr()[currentRef.curChapterIndex].pages[currentRef.currentIndex].templateType == "Assessment") {
						setTimeout(function() {
							currentRef.nextClickHandler();
						}, 2000);
					}   

					$("#dropdown_reset").addClass('chk_btn2').prop("disabled", true).removeClass("activate-reset").addClass('disable').find('span').html('button unavailable');
					$("#dropdown_smt").addClass('chk_btn2').prop("disabled", true).removeClass("activate-submit").addClass('disable').find('span').html('button unavailable');
					$( "select" ).prop("disabled", true).css("pointer-events","none");
					$("#dropdown_show").addClass('chk_btn2').prop("disabled", true).css("pointer-events","none").addClass('disable').find('span').html('button unavailable');
				
				}else{
					if(_this.attemptedCount == currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.ac) {
						var tempObj = {
							score: 0,
							attemptsTaken: _this.attemptedCount,
							completed: "true"
						}
						currentRef.updateMenuNdTrackingStatus("visited", tempObj);
						if(_model.getLinearTOCDataArr()[currentRef.curChapterIndex].pages[currentRef.currentIndex].templateType == "Assessment") {
							setTimeout(function() {
								currentRef.nextClickHandler();
							}, 2000);
						}
						console.log('s')
						$("#dropdown_reset").addClass('chk_btn2').prop("disabled", true).removeClass("activate-reset").addClass('disable').find('span').html('button unavailable');
						$("#dropdown_smt").addClass('chk_btn2').prop("disabled", true).removeClass("activate-submit").addClass('disable').find('span').html('button unavailable');
						$( ".drop_down_parent select" ).prop("disabled", true).css("pointer-events","none");
						$("#dropdown_show").addClass('chk_btn2').prop("disabled", true).css("pointer-events","none").addClass('disable').find('span').html('button unavailable');
					}else{
						var tempObj = {
							score: 0,
							attemptsTaken: _this.attemptedCount,
							completed: "false"
						}
						currentRef.updateMenuNdTrackingStatus(null, tempObj);
					}
				}
			}
	
	}
	
	//validate dropdown box
	this.validateClickHandler = function(){
		
		var m = 1; 
		for(var k=0;k<_this.currentData.pageContent.textToLoad.length;k++){
			if($("#select_"+k).val()!=''){
			//button disabled
			m++;
			}
		}
		if(m>1){
			$("#dropdown_smt").removeClass('chk_btn2').prop("disabled", false).addClass("activate-submit").removeClass('disable').find('span').html('');;
			$("#dropdown_reset").removeClass('chk_btn2').prop("disabled", false).addClass("activate-reset").removeClass('disable').find('span').html('');;
		}else{
			$("#dropdown_smt").addClass('chk_btn2').prop("disabled", true).removeClass("activate-submit");
			$("#dropdown_reset").addClass('chk_btn2').prop("disabled", true).removeClass("activate-reset")
		}
		
	}
	
		//reset dropdown box
	this.resetClickHandler = function(){
	
		for(var k=0;k<_this.currentData.pageContent.textToLoad.length;k++){
		
		 $("#select_"+k).prop('selectedIndex',0);
		 
		$("#suggest_answer"+k).empty();
		$("#red_tick_"+k).hide();
		$("#green_tick_"+k).hide();
		
		}
		$("#dropdown_reset").addClass('chk_btn2').prop("disabled", true).removeClass("activate-reset").addClass('disable').find('span').html('button unavailable');
		$("#dropdown_smt").addClass('chk_btn2').removeClass("activate-submit").prop("disabled", true).addClass('disable').find('span').html('button unavailable');
		$("#dropdown_show").addClass('chk_btn2').prop("disabled", true).removeClass("pointer-events","none").addClass('disable').find('span').html('button unavailable');
		$( "select" ).prop("disabled", false).css("pointer-events","auto");
		
		$("#stateUpdate").removeAttr('tabindex').html('');
	
	}
			
	this.showClickHandler = function(){
	
		var tmpStr = '';
		var feedbackStr = '';
		
	for(var k=0;k<_this.currentData.pageContent.textToLoad.length;k++){
			
		$("#suggest_answer"+k).empty();
		$("#red_tick_"+k).hide();
		$("#green_tick_"+k).hide();	
		
		
		for(var l=0;l<_this.currentData.pageContent.textToLoad[k].Options.length;l++){
			
			if(_this.currentData.pageContent.textToLoad[k].Options[l].correct == "true"){
				$("#suggest_answer"+k).append("<div class='right_msg' style='display:block;'><p>"+_this.currentData.pageContent.textToLoad[k].Options[l].Answer+"</p></div>");
				$("#select_"+k).prop('selectedIndex',0);
				feedbackStr = feedbackStr + " Question  "+_this.currentData.pageContent.textToLoad[k].Question+" "+_this.currentData.pageContent.textToLoad[k].Options[l].Answer;
			}
		
		}
	
	}
		
		$("#dropdown_reset").addClass('chk_btn2').prop("disabled", true).removeClass("activate-reset").addClass('disable').find('span').html('button unavailable');
		$("#dropdown_smt").addClass('chk_btn2').prop("disabled", true).removeClass("activate-submit").addClass('disable').find('span').html('button unavailable');
		$( "select" ).prop("disabled", true).css("pointer-events","none");
		$("#dropdown_show").addClass('chk_btn2').prop("disabled", true).css("pointer-events","none").addClass('disable').find('span').html('button unavailable');
		
		
	}

}