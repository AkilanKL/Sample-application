var AccordianTemplateController = function(parentData){

    var _this = this;
	
	var mac = navigator.platform.match(/(Mac|iPhone|iPod|iPad)/i) ? true : false;
	this.currentData;
	this.parentData = parentData;

    this.init = function(data){
		
		/* Initialized from loadExternalPageSuccessHandler with json file(data) of the page */

        _this.currentData = data;
        _this.loadUI(_this.currentData);
			
    }
	
    this.loadUI = function(data){
		
		/* Painting all the html elements dynamically */

		$(".txt-img-template #heading").html('').html(data.pageContent.heading);

		/* Painting all the html elements dynamically */

		if(data.pageContent.txt_img_direction == "right - left") {
			$("#content").addClass("right-left");
		}else if(data.pageContent.txt_img_direction == "top - bottom") {
			$("#content").addClass("top-bottom");
		}else if (data.pageContent.txt_img_direction == "bottom - top") {
			$("#content").addClass("bottom-top");
			$(".img-wrapper").insertBefore($(".txt-wrapper"))
		}
		
		if( data.pageContent.txt_container.content !== undefined ) {
			if( data.pageContent.txt_container.content !== "" ) {
				$(".txt-img-template .txt-wrapper").html("").html(data.pageContent.txt_container.content);
				$(".txt-img-template .txt-wrapper").append("<br>");
			}	
		}
		
		/* Painting Images dynamically */

		if( data.pageContent.txt_container.img.length > 0 ) {
			data.pageContent.txt_container.img.forEach(function(e, i) {
				if(e.path == "")  return;
					if(e.zoomImg == true) {
						$(".txt-img-template .txt-wrapper").append(
							'<a data-img-index="'+ i +'" href="javascript:;" role="button" data-toggle="modal" data-target="#text-img-popup" class="zoom-img"><img class="img-responsive center-block" src="'+_model.getAppDataObj().baseURL + '/assets/images/' + e.path+'" alt="'+e.alt+'"><div class="caption"><span class="cap-span">Click to zoom<span></div></a>'
							)
					}else{
						$(".txt-img-template .txt-wrapper").append(
							'<a data-img-index="'+ i +'" href="javascript:;" class="nozoom-img"><img class="img-responsive center-block" src="'+_model.getAppDataObj().baseURL + '/assets/images/' + e.path+'" alt="'+e.alt+'"></a>'
							)
					}
			})
		}

		/* Painting Images contents dynamically*/

		if( data.pageContent.img_container.length > 0 ) {
			data.pageContent.img_container.forEach(function(e, i) {
				if(e.path == "")  return;
					if(e.zoomImg == true) {
						$(".txt-img-template .img-wrapper").append(
							'<a data-img-index="'+ i +'" href="javascript:;" role="button" data-toggle="modal" data-target="#text-img-popup" class="zoom-img"><img class="img-responsive center-block" src="'+_model.getAppDataObj().baseURL + '/assets/images/' + e.path+'" alt="'+e.alt+'"><div class="caption"><span class="cap-span">Click to zoom<span></div></a>'
							)
					}else{
						$(".txt-img-template .img-wrapper").append(
							'<a data-img-index="'+ i +'" href="javascript:;" class="nozoom-img"><img class="img-responsive center-block" src="'+_model.getAppDataObj().baseURL + '/assets/images/' + e.path+'" alt="'+e.alt+'"></a>'
							)
					}
			})
		}else{
			$(".img-wrapper").hide();
			$(".txt-wrapper").removeClass("col-md-7")
			$(".txt-wrapper").addClass("col-md-12")
		}
		
		/* Painting Accordian contents dynamically*/

		if(data.pageContent.txt_container.accordian.length > 0) {
			var totalAccCount = data.pageContent.txt_container.accordian.length;
			var accordConts = '<div class="panelParent">';
			accordConts += '<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">';
				for(var i = 0; i < totalAccCount; i++) {
					accordConts += '<div class="panel panel-default">';

						accordConts += '<div class="panel-heading panels" role="tab" id="heading_'+i+'">';
							accordConts += '<h4 class="panel-title">';
								accordConts += '<a class="accordian_btn" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse_'+i+'" aria-expanded="false" aria-controls="collapse_'+i+'">';
									accordConts += '<strong>'+data.pageContent.txt_container.accordian[i].heading+'</strong>';
								accordConts += '</a>';
							accordConts += '</h4>';
						accordConts += '</div>';

						accordConts += '<div id="collapse_'+i+'" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading_'+i+'">';
							accordConts += '<div class="panel-body">';
								accordConts += '<div class="horizontal_panelBody">';
								accordConts += '</div>';
							accordConts += '</div>';
						accordConts += '</div>';

					accordConts += '</div>';
				}
			accordConts += '</div>';
			accordConts += '</div>';
			$(".txt-img-template .txt-wrapper").append(accordConts);
			$(".panels").off("click").on("click", _this.accordianClickHandler);
		}

		$('#text-img-popup').on('shown.bs.modal',_this.popupImageHandler);
	
		$(".glossary").each(function(ind){
			$(this).attr('id',"resource_"+ind);			
		})

    }
	
/* Image popup Handler*/

	this.popupImageHandler = function(e){
		$(this).blur();
		var clickedIndex = $(e.relatedTarget).data("img-index");
		var clickedItem = "";
		if($(e.relatedTarget).parent(".img-wrapper").length){
			clickedItem = _this.currentData.pageContent.img_container[clickedIndex];

		}else if($(e.relatedTarget).parent(".txt-wrapper").length) {
			clickedItem = _this.currentData.pageContent.txt_container.img[clickedIndex];
		}

		$("#text-img-popup .modal-body").html('<img src ="'+ _model.getAppDataObj().baseURL + '/assets/images/' +
		 clickedItem.popupImage +'" alt="'+ clickedItem.alt +'" />');

		$(".modal-dialog .close").focus();

		
	}

	this.accordianClickHandler = function(){
		var accordianId = this.id.substr(this.id.indexOf("_") + 1); 
		$(".panels").find('a').removeClass("focus");
		$("#heading_"+accordianId).find('a').addClass("focus");
		$(".horizontal_panelBody").html("");
		$("#collapse_"+accordianId).find(".horizontal_panelBody").html("").html(_this.currentData.pageContent.txt_container.accordian[accordianId].content);
		
		$(".hiddenText").remove();
		$(this).find('.accordian_btn').append('<div class="hiddenText" aria-live="polite">'+_this.currentData.pageContent.txt_container.accordian[accordianId].content+'</div>');
		
		var mac = navigator.platform.match(/(Mac|iPhone|iPod|iPad)/i) ? true : false;
		
		if(isIPAD || isAndroid || mac){
			$("#contentUpdate").html(_this.currentData.pageContent.txt_container.accordian[accordianId].content);
		}
		
	}
	
}