var ResultPageTemplateController = function(currentRef){

    var _this = this;
    this.totalAttemptedKc = 0;
    this.totalCorrectKC = 0;
	

    this.init = function(data){

        /* Initialized from loadExternalPageSuccessHandler with json file(data) of the page */
        
        _this.currentData = data;
        _this.loadUI(_this.currentData);
		
    }
	
    this.loadUI = function(data){

       /* Painting all the html elements dynamically */
       
        $(".result-heading").html(data.pageContent.heading);
        $(".result-feedback-fail .feedback").html(data.pageContent.failFeedback);
        console.log(currentRef.menuStatusArr.length)
        for(var j = 0; j < currentRef.menuStatusArr.length; j++) {
            for(var i = 0; i < currentRef.menuStatusArr[j].pages.length; i++) {

                if(currentRef.menuStatusArr[j].pages[i].kc != undefined){
                    if(currentRef.menuStatusArr[j].pages[i].kc.acTaken > 0) {
                        _this.totalAttemptedKc++;
                    }
                    if(currentRef.menuStatusArr[j].pages[i].kc.score > 0) {
                        _this.totalCorrectKC++;
                    }
                }
                
            }
        }
       

        var totalPercentage = Math.ceil((_this.totalCorrectKC / currentRef.totalKcQuestions)*100);

        if(totalPercentage < data.pageContent.passScore){
            $(".result-feedback-fail").addClass("show-button");
        }else{
            $(".result-feedback-pass").addClass("show-button");
        }

        $(".total-questions").find("td").eq(1).html(currentRef.totalKcQuestions);
        $(".total-score").find("td").eq(1).html(totalPercentage+"%");
        $(".attempted-kc").find("td").eq(1).html(_this.totalAttemptedKc);

        $("#retake-course").click(function() {
            localStorage.setItem(_model.getAppDataObj().courseName+'_v2',"");
            currentRef.homeButtonClickHandler();
        });

    }
	
}