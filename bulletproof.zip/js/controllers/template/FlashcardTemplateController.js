/**
 * Created by Ravindra on 10/04/2017.
 */

var FlashcardTemplateController = function(){

    var _this = this;
	var currentData, col;
	var alt = '';

    this.init = function(data){
        trace(":: Flash card Template Loaded ::");
 
         _this.currentData = data;
         _this.loadUI(_this.currentData);
		
		//$("#contentUpdate").html('CONTENT UPDATED');
		
		$("#nextBtn a").blur();
			
    }
	
    this.loadUI = function(data){
		
        trace(":: Paint the Flash card Template UI ::");
        trace(data);
		$("#heading").html('').html(data.pageContent.heading);
		$("#flashContent").html('').html(data.pageContent.content);
		
		//$("#contentItalic").html('').html(data.pageContent.italicsContent);
		if((data.pageContent.tooltip != undefined) && (data.pageContent.tooltip != "")){
			$("#flashContent").append("<mark><em>"+data.pageContent.tooltip+"</em><mark>");
		} 
		
		$(".resetBtn").addClass('disable').attr('disabled','disabled').find('span').html('button unavailable');
		
		col = 4;
		
		var className = 'col-md-4 col-sm-6';
		
		if(data.pageContent.column == 1){
			col = 12;
			className = 'col-md-offset-3 col-md-6';
		} else if(data.pageContent.column == 2){
			col = 6;
			className = 'col-md-6';
		} else if(data.pageContent.column == 3){
			col = 4;
		}
		
	
	 var flashCnt = '<div class="user_row">';
	 var column  = 0;
	 var cardCount = 0;
			for(var i=0; i< data.pageContent.flashcardContent.length; i++){
				
				console.log(data.pageContent.flashcardContent[i].imgPath);
				
				cardCount++;
				
				if((data.pageContent.flashcardContent[i].name != undefined) && (data.pageContent.flashcardContent[i].name != "")){
						   flashCnt += '<div class="'+className+'"><button type="button" class="revealButton" id="myButton_'+i+'">'+data.pageContent.flashcardContent[i].name+'</button></div>'; 
				} else {
					
					alt = '';
					
					if((data.pageContent.flashcardContent[i].alt != undefined) && (data.pageContent.flashcardContent[i].alt != "")){
						alt = data.pageContent.flashcardContent[i].alt;
					}
					
					//flashCnt += '<div class="'+className+'"><div class="alignClass" id="card_'+i+'"><div class="front"><button aria-label="'+data.pageContent.flashcardContent[i].label+' - Not Flipped" type="button" class="revealButton" id="myButton_'+i+'"><img src="'+_model.getCourseDataObj().baseURL + "assets/images/"+data.pageContent.flashcardContent[i].imgPath+'" alt="'+alt+'"/></button></div><div aria-hidden="true" tabindex="-1" class="back">'+data.pageContent.flashcardContent[i].content+'</div><div style="position:absolute;-9999px;left:-9999px;" class="contentUpdate" id="contentUpdate'+(i)+'"></div></div></div>';
					
				//commented below for adding class for hidden text only
					flashCnt += '<div class="'+className+'"><div class="alignClass" id="card_'+i+'"><div class="front"><button aria-describedby="contentUpdate'+(i)+'" type="button" class="revealButton" id="myButton_'+i+'"><div style="position:absolute;width:1px;height:1px;clip:rect(1px,1px,1px,1px);overflow:hidden;" class="contentUpdate" id="contentUpdate'+(i)+'">'+data.pageContent.flashcardContent[i].alt+' Not Flipped</div><img src="'+_model.getCourseDataObj().baseURL + "assets/images/"+data.pageContent.flashcardContent[i].imgPath+'" alt="'+alt+'"/></button></div><div aria-hidden="true" tabindex="-1" class="back">'+data.pageContent.flashcardContent[i].content+'</div></div></div>';
					
					//flashCnt += '<div class="'+className+'"><div class="alignClass" id="card_'+i+'"><div class="front"><button aria-describedby="contentUpdate'+(i)+'" type="button" class="revealButton" id="myButton_'+i+'"><div class="contentUpdate hiddenText" id="contentUpdate'+(i)+'">"'+data.pageContent.flashcardContent[i].label+' - Not Flipped"</div><img src="'+_model.getCourseDataObj().baseURL + "assets/images/"+data.pageContent.flashcardContent[i].imgPath+'" alt="'+alt+'"/></button></div><div aria-hidden="true" tabindex="-1" class="back">'+data.pageContent.flashcardContent[i].content+'</div></div></div>';
				}
				
				 column =  parseInt(column) + parseInt(col);
				 
				 if(column == 12){
					 flashCnt += "</div><div class='user_row'>";
					 column = 0;
				 }
				

				
			}
		
		
						
		$("#flashCard").html("").html(flashCnt); 
		
		if(isAndroid){
			$(".back").removeAttr('tabindex');
		}
		
		
			if ($('.row:last').html() == 0){ 
				$('.row:last').remove();
			}
			
		//$(".revealButton").off("click").on("click", _this.flashCardHandler);
		
		var flashId;
		
		for(var i=0; i< data.pageContent.flashcardContent.length; i++){
			$("#card_"+i).flip({
				trigger: 'manual'
			});
		}
		
		$(".revealButton").click(function(){
			flashId = this.id.substr(this.id.indexOf("_") + 1);
			console.log("flashId: "+flashId);
			$("#card_"+flashId).flip(true);
			$(".hiddenText").remove();
			$('.resetBtn').find('span').html('');
			//$(this).attr('aria-label',data.pageContent.flashcardContent[flashId-1].label+' - Flipped  '+$(this).parent().next().text() );
			//$(this).append('<div class="hiddenText" style="position:absolute;width:1px;height:1px;clip:rect(1px,1px,1px,1px);" aria-live="assertive">'+data.pageContent.flashcardContent[flashId].content+'</div>')
			//$(".contentUpdate").html("");
			$("#hiddenText").html('<p>Flipped '+$(this).parent().next().text()+'</p>');
			$(".resetBtn").removeClass('disable').removeAttr('disabled');
			$("#contentUpdate"+(flashId) ).html(data.pageContent.flashcardContent[flashId].alt+' Button Flipped'+data.pageContent.flashcardContent[flashId].content);
		});
		
		$(".resetBtn").on('click',function(){
			_this.loadUI(_this.currentData);
	    });
		
		$('.resetBtn').on('focusin',function(){
			$(this).find('span').html('');
		});
		
		$(".revealButton").on('focusin',function(){
			$(this).parent().css('outline','2px solid blue');
			$(this).parent().next().css('outline','2px solid blue');
		});
		
		$(".revealButton").on('focusout',function(){
			$(this).parent().css('outline','none');
			$(this).parent().next().css('outline','none');
		});
		
}
	
	this.flashCardHandler = function(){
		
	
 		var flashId = this.id.substr(this.id.indexOf("_") + 1);
	//	$("#"+this.id+"").parent().html('<div class="card_text">'+ _this.currentData.pageContent.flashcardContent[flashId].content+'</div>')
		console.log($("#"+this.id+"").selector);
		
		console.log("#card_"+flashId);
		
		$("#card_"+flashId).flip({
		  trigger: 'manual'
		});
		
		$("#myButton_"+flashId).click(function(){
			$("#card_"+flashId).flip(true);
		});
			
			
			
			//$("#card_"+flashId).parent().trigger('click').flip(true);
			
		//});
		
	} 
	
	this.clear = function(){
		
	}
	
}