var TextBackgroundImageTemplateController = function(parentData){

    var _this = this;
	
	var mac = navigator.platform.match(/(Mac|iPhone|iPod|iPad)/i) ? true : false;
	this.currentData;
	this.parentData = parentData;

    this.init = function(data){
		
		/* Initialized from loadExternalPageSuccessHandler with json file(data) of the page */

        _this.currentData = data;
        _this.loadUI(_this.currentData);
			
    }
	
    this.loadUI = function(data){
		
		/* Painting all the html elements dynamically */

		if(data.pageContent.heading != undefined &&
			data.pageContent.heading != "") {
				$("#txt-heading").html(data.pageContent.heading);
		}

		if(data.pageContent.txt_container.content != undefined &&
		data.pageContent.txt_container.content != "") {
			$("#txt-content").html(data.pageContent.txt_container.content);
		}

		if(data.pageContent.img_container.image != undefined &&
			data.pageContent.img_container.image != "") {
				var bgUrl = _model.getAppDataObj().baseURL + "/assets/images/" + data.pageContent.img_container.image;
				console.log(bgUrl)
				$("#bg-img-wrapper").css("background-image", "url('"+ bgUrl +"')")
			}

		if(data.pageContent.img_container.alt_text != undefined &&
			data.pageContent.img_container.alt_text != "") {
				$("#bg-img-wrapper").attr("role","img");
				$("#bg-img-wrapper").attr("aria-label",data.pageContent.img_container.alt_text);
	
		}
    }
	
}