var TextSingleImageTemplateController = function(parentData){

    var _this = this;
	
	var mac = navigator.platform.match(/(Mac|iPhone|iPod|iPad)/i) ? true : false;
	this.currentData;
	this.parentData = parentData;

    this.init = function(data){
		
		/* Initialized from loadExternalPageSuccessHandler with json file(data) of the page */

        _this.currentData = data;
        _this.loadUI(_this.currentData);
			
    }
	
    this.loadUI = function(data){
		
		/* Painting all the html elements dynamically */

		$(".txt-img-template #heading").html('').html(data.pageContent.heading);

		/* Painting all the html elements dynamically */

		if(data.pageContent.txt_img_direction == "right - left") {
			$("#content").addClass("right-left");
		}else if(data.pageContent.txt_img_direction == "top - bottom") {
			$("#content").addClass("top-bottom");
		}else if (data.pageContent.txt_img_direction == "bottom - top") {
			$("#content").addClass("bottom-top");
			$(".img-wrapper").insertBefore($(".txt-wrapper"))
		}
		
		if( data.pageContent.txt_container.content !== undefined ) {
			if( data.pageContent.txt_container.content !== "" ) {
				$(".txt-img-template .txt-wrapper").html("").html(data.pageContent.txt_container.content);
				$(".txt-img-template .txt-wrapper").append("<br>");
			}	
		}
		
		/* Painting Images dynamically */

		if( data.pageContent.txt_container.img.length > 0 ) {
			data.pageContent.txt_container.img.forEach(function(e, i) {
				if(e.path == "")  return;
					if(e.zoomImg == true) {
						$(".txt-img-template .txt-wrapper").append(
							'<a data-img-index="'+ i +'" href="javascript:;" role="button" data-toggle="modal" data-target="#text-img-popup" class="zoom-img"><img class="img-responsive center-block" src="'+_model.getAppDataObj().baseURL + '/assets/images/' + e.path+'" alt="'+e.alt+'"><div class="caption"><span class="cap-span">Click to zoom<span></div></a>'
							)
					}else{
						$(".txt-img-template .txt-wrapper").append(
							'<a data-img-index="'+ i +'" href="javascript:;" class="nozoom-img"><img class="img-responsive center-block" src="'+_model.getAppDataObj().baseURL + '/assets/images/' + e.path+'" alt="'+e.alt+'"></a>'
							)
					}
			})
		}

		/* Painting Images contents dynamically*/

		console.log(data.pageContent.img_container.length)
		if( data.pageContent.img_container.length > 0 ) {
			data.pageContent.img_container.forEach(function(e, i) {
				if(e.path == "")  return;
					if(e.zoomImg == true) {
						$(".txt-img-template .img-wrapper").append(
							'<a data-img-index="'+ i +'" href="javascript:;" role="button" data-toggle="modal" data-target="#text-img-popup" class="zoom-img"><img class="img-responsive center-block" src="'+_model.getAppDataObj().baseURL + '/assets/images/' + e.path+'" alt="'+e.alt+'"><div class="caption"><span class="cap-span">Click to zoom<span></div></a>'
							)
					}else{
						$(".txt-img-template .img-wrapper").append(
							'<a data-img-index="'+ i +'" href="javascript:;" class="nozoom-img"><img class="img-responsive center-block" src="'+_model.getAppDataObj().baseURL + '/assets/images/' + e.path+'" alt="'+e.alt+'"></a>'
							)
					}
			})
		}else{
			$(".img-wrapper").hide();
			$(".txt-wrapper").removeClass("col-md-7")
			$(".txt-wrapper").addClass("col-md-12")
		}

		$('#text-img-popup').on('shown.bs.modal',_this.popupImageHandler);
	
		$(".glossary").each(function(ind){
			$(this).attr('id',"resource_"+ind);			
		})

    }
	
/* Image popup Handler*/

	this.popupImageHandler = function(e){
		$(this).blur();
		var clickedIndex = $(e.relatedTarget).data("img-index");
		var clickedItem = "";
		if($(e.relatedTarget).parent(".img-wrapper").length){
			clickedItem = _this.currentData.pageContent.img_container[clickedIndex];

		}else if($(e.relatedTarget).parent(".txt-wrapper").length) {
			clickedItem = _this.currentData.pageContent.txt_container.img[clickedIndex];
		}

		$("#text-img-popup .modal-body").html('<img src ="'+ _model.getAppDataObj().baseURL + '/assets/images/' +
		 clickedItem.popupImage +'" alt="'+ clickedItem.alt +'" />');

		$(".modal-dialog .close").focus();

		
	}
	
}