/**
 * Created by Ravi Sharma on 6/20/2016.
 */

var ApplicationController = function () {

    var currentRef = this; //hack to get the reference of the current class
    var menu_tick, active_state;
	var currentTemplate;
    var currentTemplateObj;
    this._model = DataManager.getInstance();
    this.currentIndex = 0;
    //this.audioManager;
    this.currentPageTranscript = "";
    this.currentPageJSONData;
    this.currentPageToLoadObj;
	
	var apiServiceLoadAppData;
	
    this.audioMuteFlag = true;
    this.playPauseFlag = true;
	this.VideoplaypauseFlag;
    this.menuStatusArr = new Array();
	this.notesArray = new Array();
	var notesText = "";
	
	this.curChapterIndex = 0;
	this.curPageIndex = 0;
	this.imageLoadIndex = 0;
	this.totalImageCount = 0;
	
    this.init = function () {

        trace(":: Application Controller Initialized and Ready for task ::");

       // currentRef.audioManager = new AudioManager();

       // EventManager.getInstance().addControlEventListener(window, StaticLibrary.AUDIO_ENDED_EVENT, currentRef.audioEndEventHandler);

        $("#menuBoxContainer").hide();
        //$("#parentContainerParent").hide();
		
        currentRef.controlVisibility("landingPage");

        var tocURL = _model.getCourseDataObj().baseURL + _model.getCourseDataObj().contentURL + "?version=" + StaticLibrary.generateRandom();
        trace("Course TOC : " + tocURL);
		
		
        trace(":: Course Table of Content, loading started ::");
        var apiServiceLoadAppData = new APIService();
        apiServiceLoadAppData.loadTOCData(tocURL, "true", StaticLibrary.DATA_TYPE, null, this.loadTOCSuccessHandler);
    }

    this.loadTOCSuccessHandler = function (data) {

        trace(":: Course Table of Content, loading Completed ::");
        DataParser.parseTOCData(data);
		
		
			$(".projectTitle").html('').html(_model.getCourseDataObj().projectTitle);
			$(".module_title").html('').html(_model.getCourseDataObj().title);
			
		var pagination = '';
		var recommended;
		 for (var b = 0; b < _model.getLinearTOCDataArr().length; b++) {
			if (_model.getLinearTOCDataArr()[b].pages != undefined) { 
				for (var c = 0; c < _model.getLinearTOCDataArr()[b].pages.length; c++) {
					if(_model.getLinearTOCDataArr()[b].pages[c].recommended == "true"){
						recommended = ' class="focus_purple"';
					} else {
						recommended = "";
					}
					pagination += '<li><button type="button" '+recommended+'>'+(c+1)+'</button></li>';
				}
			}
         }
		$("#paginationArea").html('').html(pagination);
			
		for (var i = 0; i < _model.getLinearTOCDataArr().length; i++) {
            currentRef.menuStatusArr.push({"status":"NOT_STARTED"});
			if (_model.getLinearTOCDataArr()[i].pages != undefined) {
				currentRef.menuStatusArr[i].pages = new Array();
				for (var j = 0; j < _model.getLinearTOCDataArr()[i].pages.length; j++) {
					currentRef.menuStatusArr[i].pages.push({isVisited:"false",score:0});
				}
			}
		}	
		
		 for (var b = 0; b < _model.getLinearTOCDataArr().length; b++) {
			if (_model.getLinearTOCDataArr()[b].pages != undefined) { 
				for (var c = 0; c < _model.getLinearTOCDataArr()[b].pages.length; c++) {
					currentRef.notesArray.push({page:(c+1),noteData:notesText});
				}
			}
         }
		 
		 if(localStorage.getItem('notes_data') != null){
			localStorage.setItem('notes_data',localStorage.getItem('notes_data'));
			currentRef.notesArray = JSON.parse(localStorage.getItem('notes_data'));
		 } else {
			localStorage.setItem('notes_data',JSON.stringify(currentRef.notesArray) );
		 }
		

		console.log(currentRef.menuStatusArr)
		if( _model.getAppDataObj().scorm == "local" ){
			var storedCourseObj = localStorage.getItem(_model.getAppDataObj().courseName+'_v2');
			if( storedCourseObj != null ){
				var storedData = JSON.parse( storedCourseObj );
				currentRef.menuStatusArr = storedData;
				//_model.setLinearTOCDataArr(storedData);
			}
		}else if( _model.getAppDataObj().scorm == "scorm" ){
			var courseTrackingData = _model.getScormReference().retrieveTrackingData();
			if (courseTrackingData != "") {
				var curData = JSON.parse( courseTrackingData );
				currentRef.menuStatusArr = curData;
				//_model.setLinearTOCDataArr(curData);
			}
		}

        trace(":: Course Table of Content, data parsing Completed ::");
        trace( _model.getLinearTOCDataArr() );

        //Logic for loading and painting the TOC in the shell.
        var menuStr = "";
		var courseMenustr = '';
        $("#menuContainerList").html('');

        /* // Menu status from LMS. Needs to be updated once menu status array is finalized.

        for (var i = 0; i < _model.getTOCDataArr().length; i++) {
            currentRef.menuStatusArr.push({"isVisited": "false"});
        }

        if (_model.getAppDataObj().scorm == "scorm") {
            var trackingData = _model.getScormReference().retrieveTrackingData();
            if (trackingData != "") {
                currentRef.menuStatusArr = JSON.parse(trackingData);
            }
        } */


        //painting TOC Menu Titles when TOC Data loading is completed
        for (var i = 0; i < _model.getLinearTOCDataArr().length; i++) {
            if (_model.getLinearTOCDataArr()[i].pages != undefined) {
                menuStr += '<li data-toggle="collapse" data-target="#inner_' + i + '" aria-expanded="false" class="slidemenu collapsed enableArrow"><p class="nopad">' + _model.getLinearTOCDataArr()[i].pageTitle + '</p><ul class=" collapse" aria-expanded="false" id="inner_' + i + '"></ul></li> ';
            } else {
                menuStr += '<li class="eventcls"><p>' + _model.getLinearTOCDataArr()[i].pageTitle + '</p></li> ';
            }
			
			if(_model.getLinearTOCDataArr()[i].duration != undefined){
				courseMenustr+= '<li data-status='+currentRef.menuStatusArr[i].status+'><div class="menu_icons"><img class="icon_menu unlock_icon" src="assets/images/un_lock.png" alt=""/> <img class="icon_menu completed_icon" src="assets/images/tick_icon.png" alt=""/> <img class="icon_menu progress_icon" src="assets/images/progress_icon.png" alt=""/> <img class="icon_menu lock_icon" src="assets/images/lock.png" alt=""/></div><h3>'+_model.getLinearTOCDataArr()[i].pageTitle+'</h3><p class="duration">'+_model.getLinearTOCDataArr()[i].duration+'</p></li>'
			}
			
			trace(_model.getLinearTOCDataArr()[i].pageTitle);
			trace(_model.getLinearTOCDataArr()[i].duration);
        }
		
		$("#chapterMenu").html(courseMenustr);
		$(".icon_menu").hide();
		
		currentRef.updateModuleMenuStatus();
		currentRef.startTheCourse();
			
		$("#chapterMenu li").on('click',currentRef.chapterClickHandler);
		
        $("#menuContainerList").html(menuStr).promise().done(function () {

            trace(":: Menu Painted in the Container and event attached ::");

            for (var b = 0; b < _model.getLinearTOCDataArr().length; b++) {
                if (_model.getLinearTOCDataArr()[b].pages != undefined) {
                    for (var c = 0; c < _model.getLinearTOCDataArr()[b].pages.length; c++) {
						if(currentRef.menuStatusArr[b].pages[c].isVisited == "true"){
							if(!$(".menu_active i").hasClass("pull-right")){
								 $("#inner_" + b).append('<li class="eventcls completed" ><i class="fa fa-check-circle text-default pull-right"></i>' + _model.getLinearTOCDataArr()[b].pages[c].pageTitle + '</li>');
							}
						}else{
							 $("#inner_" + b).append('<li class="eventcls" >' + _model.getLinearTOCDataArr()[b].pages[c].pageTitle + '</li>');
						}
                    }
                }
            }

            $(".slidemenu").unbind("click").bind("click", currentRef.menuHeadColorClickHandler);

            $(".eventcls").each(function (a) {
                $(this).attr("id", "menuItem_" + a);
            })

            for (var e = 0; e < _model.getTOCDataArr().length; e++) {
                $("#menuItem_" + e).unbind("click").bind("click", currentRef.menuItemClickHandler);
            }

            /***************** Making menu Linear ******************/
            if (_model.getAppDataObj().linear == "true") {
                $(".eventcls").css({'pointer-events': 'none', 'opacity': 0.5}); // making all li to pointer event none first
				$(".completed").css({'pointer-events': 'auto', 'opacity': 1});
				
            }

            /* if (_model.getAppDataObj().scorm == "scorm") {
                for (var e = 0; e < _model.getTOCDataArr().length; e++) {
                    if (currentRef.menuStatusArr[e].isVisited == "true") {
                        $("#menuItem_" + e).css({'pointer-events': 'auto', 'opacity': 1}); // Enable Menu items for the completed screens.
                    }
                }
            } */
        });

       /* var glossaryURL = _model.getCourseDataObj().baseURL + "assets/data/content/glossary.json?version=" + StaticLibrary.generateRandom();
        trace("Glossary URL : " + glossaryURL);

        trace(":: Glossary data loading started ::");
        var apiServiceLoadAppData = new APIService();
        apiServiceLoadAppData.loadTOCData(glossaryURL, "true", StaticLibrary.DATA_TYPE, null, currentRef.loadGlossarySuccessHandler);  */
		
		
		// var instructionURL = _model.getCourseDataObj().baseURL + "assets/data/content/instruction.json?version=" + StaticLibrary.generateRandom();
        // trace("instructionURL URL : " + instructionURL);

        // trace(":: instructionURL data loading started ::");
        // var apiServiceLoadAppData = new APIService();
        // apiServiceLoadAppData.loadTOCData(instructionURL, "true", StaticLibrary.DATA_TYPE, null, currentRef.loadInstructionSuccessHandler);




    }

    this.menuHeadColorClickHandler = function () {
        if($(this).find('.nopad').hasClass('clrtag')){
            $(this).find('.nopad').removeClass('clrtag');
        }else{
            $(this).find('.nopad').addClass('clrtag');
        }
    }
	this.loadInstructionSuccessHandler = function (data) {
		trace(":: Instruction data loading Completed ::");
        trace(data);
		//to-do task for loading and painting the Glossary in Glossary Popup.
        var InstructionController = new InstructionController();
        InstructionController.init(data);
	}

  
	
	//Below code links is tempraray
	this.gotoIndex = function(e){
		if(e.target.className == "single_button"){
			window.location.href="index.html";
		}
	}
	 

    //function to crate Resource Link for the Resource Popup
    this.createResourcesPopup = function (resourceData) {
        trace(":: Creating Resource Popup ::");

        var resourceStr = "";
        $("#resourcePopupLinkContainer").html('');
		if(resourceData.length > 0){
			for (var i = 0; i < resourceData.length; i++) {
				resourceStr += "<p><a target='_blank' href='" + _model.getCourseDataObj().baseURL + "assets/data/resources/" + resourceData[i].url + "'>" + resourceData[i].title + "</a></p>";
			}
		} else {
				resourceStr = "There are no resources for this module.";
		}
        $("#resourcePopupLinkContainer").html(resourceStr);
    }

    

    this.startClickHandler = function () {
        trace(":: Start Course Button is clicked ::");
		
		
		
		
        currentRef.controlVisibility("parentContainerParent");
		$("#menuPart").css({'pointer-events': 'none', 'opacity': 0.5}); // Added to hide menu parts
		$("#footerSection_1").css({'pointer-events': 'none', 'opacity': 0.5});
        $("#menuBoxContainer").show();
        $("#headerSection_1").show();$("#headerSection_2").hide();
        $("#footerSection_2").hide();
		//$("#parentContainerParent").hide();
        //$("#playPauseBtn img").attr('src', 'assets/images/play_button.png');
    }

	this.homeButtonClickHandler = function(){
		
		window.open("start_screen.html","_self"); 
	 
	}
	
    this.startTheCourse = function(){
		
		$("#pageJump").show();
		$("#menuPart").css({'pointer-events': 'auto', 'opacity': 1});
		$("#footerSection_1").css({'pointer-events': 'auto', 'opacity': 1});
        $("#menuBoxContainer").hide();
        $("#headerSection_2").show();
        $("#footerSection_2").show();
		$("#parentContainerParent").show();
		$("#nextNotification").show();
 
		if( /Android|iPhone|iPod/i.test(navigator.userAgent) ) {
			$("#headerSection_1").show();
			$("#headerSection_2").hide();
		}
        

       // currentRef.audioManager.stopAudio();
       // currentRef.audioManager.loadAudio("assets/media/audio/blank");


        setTimeout(function(){
            $("#previousBtn").unbind("click").bind("click", currentRef.previousClickHandler); 
            $("#nextBtn").unbind("click").bind("click", currentRef.nextClickHandler); 
         

            $("#courseMenuBtn").unbind("click").bind("click", currentRef.courseMenuClickHandler);
            $("#resourceBtn").unbind("click").bind("click", currentRef.resourceClickHandler);
            $("#referenceBtn").unbind("click").bind("click", currentRef.referenceClickHandler);
            $(".glossaryBtn").unbind("click").bind("click", currentRef.glossaryClickHandler);
			$(".instructionBtn").unbind("click").bind("click", currentRef.instructionClickHandler);
            $(".helpBtn").unbind("click").bind("click", currentRef.helpClickHandler);
            $("#handoutBtn").unbind("click").bind("click", currentRef.handoutClickHandler);
            $("#transcriptBtn").unbind("click").bind("click", currentRef.transcriptClickHandler);
            $("#audioClose").unbind("click").bind("click", currentRef.audioTranscriptCloseHandler);
            $(".homeBtn").unbind("click").bind("click", currentRef.homeButtonClickHandler);
            $("#jumpToTxt").bind('keyup',  currentRef.jumpToSubmitHandler);
            $(".notesBtn").unbind("click").bind("click", currentRef.notesBtnHandler);
            $("#jumpToBtn").unbind("click").bind("click", currentRef.jumpToBtnHandler);
            $("#paginationArea li").unbind("click").bind("click", currentRef.paginationHandler);
			  
 			  $("#menu_close").unbind("click").bind("click", currentRef.headerPopupCloseHandler);
			 $("#resourcePopup, #helpPopup, #glossaryPopup, #referencePopup, #resourcePopup").on("hidden.bs.modal", currentRef.headerPopupCloseHandler);	 	  	
			 $("#instructionClose").on("click", currentRef.popupCloseHandler);	 	
			 $(".instruction_modal").on("hidden.bs.modal", currentRef.popupCloseHandler);	 	  	
            /* if (_model.getAppDataObj().scorm == "scorm") {
                var isContinue = false;

                if (_model.getScormReference().retrieveVisitedScreenNo() != "") {
                    isContinue = confirm("Do you want to continue the course from where you left ?");
                }

                if (isContinue) {
                    currentRef.currentIndex = Number(_model.getScormReference().retrieveVisitedScreenNo());
                    //trace(_model.getScormReference().retrieveVisitedScreenNo());
                }
            } */

            $("#mobileMenuIcon").unbind("click").bind("click", currentRef.mobileMenuHandler);

            currentRef.controlVisibility("parentContainerParent");
            currentRef.loadCurrentPage(currentRef.currentIndex);
        }, 200);
    }
	this.jumpToSubmitHandler = function(event){
		if(event.keyCode == 13){ 
			event.preventDefault();
			$("#jumpToBtn").click(); 
			return false;
		}
	}
	
	this.paginationHandler = function(){
		currentRef.currentIndex = $(this).index();
		currentRef.loadCurrentPage(currentRef.currentIndex);
		$("#paginationArea li button").removeClass("focus");
		$(this).find("button").addClass("focus");
	}
	
	
	this.jumpToBtnHandler = function(){
		trace("Jump To Page : " + $("#jumpToTxt").val());
		var totalPages = _model.getTOCDataArr().length;
		var jumpToPage = (parseInt($("#jumpToTxt").val()) - 1);
		if((jumpToPage < totalPages) && (jumpToPage >= 0)){
			currentRef.currentIndex = jumpToPage;
			currentRef.loadCurrentPage(currentRef.currentIndex);
		} else {
			alert("Incorrect page number.");
		}
	}
	
    this.mobileMenuHandler = function () { 
        if ($("#system_menu").css("display") == "block") {
			$("#mobileMenuOverlay").hide();
			/* if(currentRef.playPauseFlag == true){
				currentRef.audioManager.playAudio();
			} */
            $("#system_menu").animate({'position': 'absolute', 'right': '-148px'}, 500, function () {
                $("#system_menu").hide();
				$(".disableMenuBG").hide();
				$("#mobileMenuIcon").parent().css("background","none");
            });
        } else {
			$("#mobileMenuOverlay").show();
			
				/* currentRef.audioManager.pauseAudio(); */
            $("#system_menu").show(1, function () {
				$(".disableMenuBG").show();
                $("#system_menu").animate({'position': 'absolute', 'right': '0px'}, 500);
				$("#mobileMenuIcon").parent().css("background","#ea7600");
            });

        }

    };
    this.menuItemClickHandler = function (event) {
		$("#mobileMenuOverlay").hide();
		event.stopPropagation();
		
        var str = event.currentTarget.id;
        var tempIndexArr = str.split("_");

        currentRef.currentIndex = parseInt(tempIndexArr[1]);
        currentRef.loadCurrentPage(currentRef.currentIndex);

        $("#menuContainer").modal('hide');
    }
	
	this.chapterClickHandler = function(){
		
		if (_model.getAppDataObj().linear == "true") {
			if( ( $(this).prev().attr('data-status') != 'COMPLETED' ) && $(this).prev().length ){
				return;
			}
		}
		
		var curChapterIndex = $(this).index();
		var linearPageIndex = 0;
		var chapterStartIndex = 0;
		var tempIndex = 0;
		var tempIndex1 = 0;
		
		for(var i=0;i<currentRef.menuStatusArr.length;i++){
			if(curChapterIndex > i){
				if(currentRef.menuStatusArr[i].pages != undefined){
					for(var j=0;j<currentRef.menuStatusArr[i].pages.length;j++){
						chapterStartIndex++;
					}
				}
			}
		}
		
		if(currentRef.menuStatusArr[curChapterIndex].pages != undefined){
			for(var i=0;i<currentRef.menuStatusArr[curChapterIndex].pages.length;i++){
				if( currentRef.menuStatusArr[curChapterIndex].pages[i].isVisited == "true" ){
					tempIndex++;
				}
			}
		}
		
		 

		if( $(this).attr('data-status') == "IN_PROGRESS"){
			currentRef.curChapterIndex = curChapterIndex;
			currentRef.curPageIndex = tempIndex;
			currentRef.currentIndex = chapterStartIndex + tempIndex;
		}else{
			currentRef.curChapterIndex = curChapterIndex;
			currentRef.curPageIndex = 0;
			currentRef.currentIndex = chapterStartIndex;		
		}
		
		if(currentRef.menuStatusArr[currentRef.curChapterIndex].status == "NOT_STARTED"){
			currentRef.menuStatusArr[currentRef.curChapterIndex].status = "IN_PROGRESS";
		}
		
		if (_model.getAppDataObj().scorm == "scorm") {
			_model.getScormReference().storeTrackingData( JSON.stringify(currentRef.menuStatusArr) ); //Menu Status to LMS.
        }else if(_model.getAppDataObj().scorm != "scorm"){
			localStorage.setItem(_model.getAppDataObj().courseName+'_v2',JSON.stringify(currentRef.menuStatusArr) );		
		}
		
		//console.log(currentRef.menuStatusArr[currentRef.curChapterIndex].status+" "+linearPageIndex+" "+tempIndex);
		
		trace( linearPageIndex );
	}
	
	
    //function to handle the previous button click to load previous pages in the shell
    this.previousClickHandler = function () {

        trace(":: Previous Button Clicked ::");

        if (currentRef.currentIndex <= 0) {
            trace(":: Your on First Page ::");
        } else {
		
			if(currentRef.curPageIndex > 0){
				currentRef.curPageIndex--;
			}else{
				var  totalChapterLength = _model.getLinearTOCDataArr().length-1;
				if(currentRef.curChapterIndex > 0){
					currentRef.curChapterIndex--;
					var curChapterPagesLength = _model.getLinearTOCDataArr()[currentRef.curChapterIndex].pages.length-1;
					currentRef.curPageIndex	= curChapterPagesLength;
				}
			}
			
			trace("curChapterPagesLength: "+curChapterPagesLength+"  currentRef.curChapterIndex: "+currentRef.curChapterIndex+" currentRef.curPageIndex: "+currentRef.curPageIndex);
			
			
			currentRef.currentIndex--;
            currentRef.loadCurrentPage(currentRef.currentIndex);
        }
    }

    //function to handle the next button click to load next pages in the shell
    this.nextClickHandler = function () {
		
        trace(":: Next Button Clicked ::");
		
        var totalLength = _model.getTOCDataArr().length;
        if (currentRef.currentIndex >= (totalLength - 1)) {
           trace(":: Your on Last Page ::"); 
            if (_model.getAppDataObj().scorm == "scorm") {
                _model.getScormReference().storeCompletionStatus("completed");
            }
        } else {
            
			// Traversal Start
			
			if( _model.getLinearTOCDataArr()[currentRef.curChapterIndex].pages != undefined ){
				
				var curChapterPagesLength = _model.getLinearTOCDataArr()[currentRef.curChapterIndex].pages.length-1;
				var  totalChapterLength = _model.getLinearTOCDataArr().length-1;
				
				if(curChapterPagesLength  >  currentRef.curPageIndex){
					currentRef.curPageIndex++;
				}else{
					if(totalChapterLength > currentRef.curChapterIndex){
						trace( _model.getLinearTOCDataArr() );
						currentRef.menuStatusArr[currentRef.curChapterIndex].status = "COMPLETED";
						currentRef.curChapterIndex++;
						if(currentRef.menuStatusArr[currentRef.curChapterIndex].status == "NOT_STARTED"){
							currentRef.menuStatusArr[currentRef.curChapterIndex].status = "IN_PROGRESS";
						}
						currentRef.curPageIndex	= 0;				
					}
				}
				
				if( (curChapterPagesLength == currentRef.curPageIndex) && (totalChapterLength == currentRef.curChapterIndex) ){
					currentRef.menuStatusArr[currentRef.curChapterIndex].status = "COMPLETED";
				}
				
				trace("totalChapterLength: "+totalChapterLength+" curChapterPagesLength: "+curChapterPagesLength+"  currentRef.curChapterIndex: "+currentRef.curChapterIndex+" currentRef.curPageIndex: "+currentRef.curPageIndex);
				
		    }
			
			
			// Traversal End
			
			currentRef.currentIndex++;
            currentRef.loadCurrentPage(currentRef.currentIndex);
        }
		
		if(!$(".menu_active i").hasClass("pull-right")){
			$(".menu_active").append('<i class="fa fa-check-circle text-default pull-right"></i>');
		}
			
    }

     

    //function to handle the click event for menu button from the shell
    this.courseMenuClickHandler = function () {
        trace(":: Menu Button Clicked ::");
        $("#menuContainer").modal('show');
		// currentRef.audioManager.pauseAudio();
		currentRef.courseMenuHideHandler();
		$("#videoTemplateContainer").trigger('pause');
		 $(".disableMenuBG").hide();
    }
 
	this.popupCloseHandler = function(){
		trace(":: popup Close Handler ::");
		
		$("#instructionBtn img").attr("src","assets/images/instruction_icon.png");
	}
	
	this.headerPopupCloseHandler = function(){
		trace(":: Menu Button Close Handler ::");
		$("#mobileMenuOverlay").hide();
 		 $("#videoTemplateContainer").trigger('play');
		 
		if(currentRef.playPauseFlag == false){
			// currentRef.audioManager.unMuteAudio();
 			 
		}
		else{
			
			// currentRef.audioManager.playAudio();
			
 		}
			 
		 
	}
	
    //function to handle the click event for Resource button from the shell
    this.resourceClickHandler = function () {
        trace(":: Resource Button Clicked ::");
		currentRef.courseMenuHideHandler();
		// currentRef.audioManager.pauseAudio();
 		 $("#videoTemplateContainer").trigger('pause');
		 $(".disableMenuBG").hide();
    }
	
	//function to handle the click event for Resource button from the shell
    this.referenceClickHandler = function () {
        trace(":: Reference Button Clicked ::");
		currentRef.courseMenuHideHandler();
		$("#videoTemplateContainer").trigger('pause');
		// currentRef.audioManager.pauseAudio();
		 $(".disableMenuBG").hide();
    }

    //function to handle the click event for Glossary button from the shell
    this.glossaryClickHandler = function () {
      /*   trace(":: Glossary Button Clicked ::");
		currentRef.courseMenuHideHandler();
		$("#videoTemplateContainer").trigger('pause');
		// currentRef.audioManager.pauseAudio();
		 $(".disableMenuBG").hide(); */
		 
		 if($(".glossaryBtn").attr("data-label") == "not_selected"){
			$(".glossaryBtn").attr("data-label","selected");
			trace(":: glossaryBtn Button Clicked ::");
			$("#mobileMenuOverlay").hide();
			$(".glossaryBtn img").attr("src","assets/images/glossary-icon-active.png");
			$(".helpBtn img").attr("src","assets/images/help_icon.png");
			var landingPageURL = "views/template/Glossary.html";
			var apiServiceLoadAppData = new APIService();
			apiServiceLoadAppData.loadFromExternalSource(landingPageURL, "true", StaticLibrary.TEMPLATE_TYPE, null, currentRef.glossaryPageSuccessHandler);
			$("#parentContainer").html('').html();
			
		 } else {
			 $(".glossaryBtn").attr("data-label","not_selected");
			 $(".glossaryBtn img").attr("src","assets/images/glossary_icon.png");
			 currentRef.loadCurrentPage(currentRef.currentIndex);
		 }
			$("#system_menu").animate({'position': 'absolute', 'right': '-148px'}, 500, function () {
					$(".menu_click_bg").css("background","none");
				$("#system_menu").hide();
				$(".disableMenuBG").hide();
			}); 
			
    }
	
	
	this.notesBtnHandler = function(){
		trace(":: Glossary data loading started ::");
		
		$("#notes").show();
		
		$("#notes").attr('tabindex','0').focus();
		
		$(".notesBtn > a > img").attr("src","assets/images/notes-icon-active.png");
		
		$("#system_menu").animate({'position': 'absolute', 'right': '-148px'}, 500, function () {
					$("#mobileMenuOverlay").hide();
					$(".menu_click_bg").css("background","none");
					$("#system_menu").hide();
					$(".disableMenuBG").hide();
				});
				
				
		var notesController = new NotesController();
			notesController.init(currentRef);
	}
	
	
	this.instructionClickHandler = function(data){
	
		//$("#myModal").attr('tabindex','0').focus();
		$("#instructionDialogBox").attr('tabindex','0').focus();
		
		$("#instructionBtn img").attr("src","assets/images/instruction-icon-active.png");
		$("#instructionContent").html("").html(_model.getCourseDataObj().instructionData);
		
		$("#system_menu").animate({'position': 'absolute', 'right': '-148px'}, 500, function () {
					$("#mobileMenuOverlay").hide();
					$(".menu_click_bg").css("background","none");
					$("#system_menu").hide();
					$(".disableMenuBG").hide();
				});
	}
	
	this.glossaryPageSuccessHandler = function(data){
		$("#parentContainer").html('').html(data).promise().done(function(){
			trace(":: Glossary screen loading and appending Completed ::");
			var glossaryURL = _model.getCourseDataObj().baseURL + "assets/data/content/glossary.json?version=" + StaticLibrary.generateRandom();
			trace("Glossary URL : " + glossaryURL);

			trace(":: Glossary data loading started ::");
			var apiServiceLoadAppData = new APIService();
			apiServiceLoadAppData.loadTOCData(glossaryURL, "true", StaticLibrary.DATA_TYPE, null, currentRef.loadGlossarySuccessHandler);
		});
	}
	
	this.loadGlossarySuccessHandler = function (data) {

        trace(":: Glossary data loading Completed ::");
        trace(data);

        //to-do task for loading and painting the Glossary in Glossary Popup.
        var glossaryController = new GlossaryController();
        glossaryController.init(data);
        currentRef.createResourcesPopup(_model.getCourseDataObj().resources);
	
	}
	
	
    //function to handle the click event for Help button from the shell
    this.helpClickHandler = function () {
		 
		 if($(".helpBtn").attr("data-label") == "not_selected"){
			$(".helpBtn").attr("data-label","selected");
			trace(":: Help Button Clicked ::");
			$("#mobileMenuOverlay").hide();
			$(".helpBtn img").attr("src","assets/images/help-icon-active.png");
			$(".glossaryBtn img").attr("src","assets/images/glossary_icon.png");
			var landingPageURL = "views/template/help.html";
			var apiServiceLoadAppData = new APIService();
			apiServiceLoadAppData.loadFromExternalSource(landingPageURL, "true", StaticLibrary.TEMPLATE_TYPE, null, currentRef.helpPageSuccessHandler);
			$("#parentContainer").html('').html();
		 } else {
			 $(".helpBtn").attr("data-label","not_selected");
			$(".helpBtn img").attr("src","assets/images/help_icon.png");
			 currentRef.loadCurrentPage(currentRef.currentIndex);
		 }
		 
		 $("#system_menu").animate({'position': 'absolute', 'right': '-148px'}, 500, function () {
					$("#system_menu").hide();
					$(".menu_click_bg").css("background","none");
					$(".disableMenuBG").hide();
				});
		  
    }
	
	this.helpPageSuccessHandler = function(data){
		$("#parentContainer").html('').html(data).promise().done(function(){
			trace(":: Help screen loading and appending Completed ::");
		});
	}	
	
	this.courseMenuHideHandler = function () {
		if($( window ).width() <= 480){
			$("#system_menu").css({'right':'-148px','display':'none'});
		}
	}

    //function to handle the click event for Handout button from the shell
    this.handoutClickHandler = function () {
        trace(":: Handout Button Clicked ::");

        currentRef.createHandoutPopup(_model.getCourseDataObj().handouts);

         
    }

    

    //function gets triggered whenever the audio is completed play in the shell.
    this.audioEndEventHandler = function (data) {
        trace("::  Audio Ended & Click  from the Templates for Notification ::");
		
		trace(data.obj)

       // currentRef.playPauseFlag = false;
        //currentRef.menuStatusArr[currentRef.currentIndex].isVisited = "true";
		
		if(data.obj != null){
			trace(data.obj.type);	
			if(data.obj.type == "assessment"){
				currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.curPageIndex].score = data.obj.score;
			}
		}
		
		if($("#parentContainer").hasClass("anchorTag")){
				var local = parseInt(currentRef.currentIndex) + parseInt(1);
				localStorage.setItem("anchor_slide_"+local+"","true");
						$("#parentContainer").removeClass("anchorTag");
		}
		
		var totalScore = 0;
		var totalQuestions = 0;
		
		for(var i=0;i<currentRef.menuStatusArr.length;i++){
			if( currentRef.menuStatusArr[i].pages != undefined ){
				for(var j=0;j<currentRef.menuStatusArr[i].pages.length;j++){
					 var curScreenScore = currentRef.menuStatusArr[i].pages[j].score;
					
					if(curScreenScore){
						totalScore += curScreenScore;
					} 
				}
			}
		}

		scoreInPercentage = (totalScore/totalQuestions)*100;
		
		trace("totalScore: "+totalScore+" totalQuestions: "+totalQuestions+" scoreInPercentage: "+scoreInPercentage)
		
        /************** Making menu Linear starts*******************/

        trace((_model.getAppDataObj().linear == "true") + " - " + (_model.getTemplateStatus()) + " - " + (_model.getAudioStatus()))

        var lastPage = _model.getTOCDataArr().length - parseInt(1);
        if(currentRef.currentIndex == lastPage){
            $(" #menuItem_"+lastPage+" ").css({'pointer-events': 'auto', 'opacity': 1});
            /************** Making menu Linear ends*******************/
        }

		
		
		
       /*  if(_model.getAudioStatus()){
            $("#playPauseBtn img").attr('src', 'assets/images/play_button.png'); // added to change play icon when audio ends
        } */

		if ((_model.getAppDataObj().linear == "false") && (_model.getAudioStatus())) {
			//added to control the next notification after audio ends
			 if(currentRef.currentIndex < lastPage){
				$("#nextNotification").fadeIn(800);
			 }
			//added to control tick mark in menus
		}
		
        if ((_model.getAppDataObj().linear == "true") && (_model.getTemplateStatus()) && (_model.getAudioStatus())) {
            _model.setTemplateStatus(false);
            _model.setAudioStatus(false); 
            var nextPage = currentRef.currentIndex + parseInt(1);

			// making next li to active after audio ends
            $(" #menuItem_"+currentRef.currentIndex+" , #menuItem_"+nextPage+"").css({'pointer-events': 'auto', 'opacity': 1}); 
            //$('#nextBtn').css({'pointer-events': 'auto', 'opacity': 1}); // enabled the next button when navigation is set to non-linear.
			$("#nextBtn").css("pointer-events","auto").find("img").attr("src","assets/images/next_slide_button.png");
			
			if(currentRef.currentIndex < lastPage){
				//added to control the next notification after audio ends
				$("#nextNotification").fadeIn(800);
			}
			//added to control tick mark in menus
			if(!$(".menu_active i").hasClass("pull-right")){
				$(".menu_active").append('<i class="fa fa-check-circle text-default pull-right"></i>');
			}
		
        } else {
            trace("triggered");
        }
		
		if (_model.getAppDataObj().scorm == "scorm") {
			_model.getScormReference().storeTrackingData( JSON.stringify(currentRef.menuStatusArr) ); //Menu Status to LMS.
			_model.getScormReference().storeAssessmentScore(scoreInPercentage);
        }else if(_model.getAppDataObj().scorm != "scorm"){
			localStorage.setItem(_model.getAppDataObj().courseName+'_v2',JSON.stringify(currentRef.menuStatusArr) );		
		}
    }

    this.loadCurrentPage = function (currentIndex) {
		
        trace(":: Loading Current Request Page from Page Collection :: ");
		
		$(".glossaryBtn, .helpBtn").attr("data-label","not_selected");
		
		$("#playPauseBtn, #audioMuteBtn").css({'pointer-events': 'auto', 'opacity': 1}); 
        currentRef.playPauseFlag = true;

        StaticLibrary.SHOW_PRE_LOADER();
        //currentRef.audioManager.stopAudio();
		/* if(currentTemplateObj){
			currentTemplateObj.clear();
		} */
		
		var slide = JSON.parse(localStorage.getItem("notes_data"));
		
			$("#notesText").val('');
			
		 if(slide[currentRef.currentIndex].noteData != ""){
			$("#notesText").val(slide[currentRef.currentIndex].noteData);
		} 
		
		var notesLocal = '';
		for(var i = 0; i < slide.length; i++){
			if((slide[i].noteData != undefined) && (slide[i].noteData != "")){
				notesLocal += slide[i].noteData;
			}
		}
		
		if(notesLocal != ""){
			$("#allNotes").removeClass("disabled").prop('disabled', false);
		} else {
			$("#allNotes").addClass("disabled").prop('disabled', true);
		}
		
		
		$("#notesPage").html("").html((parseInt(currentIndex) + parseInt(1)));
		
		$("#nextBtn,#previousBtn,#paginationArea a").removeAttr('tabindex');
		
		$("#mobileMenuOverlay").hide();
		$("#paginationArea li").each(function(){
			if($(this).find("button").hasClass("focus")){
				$(this).find("button").removeClass("focus").addClass("focus_green");
			}
		});
		$("#paginationArea li:eq("+currentIndex+")").find("button").addClass("focus");
		$("#paginationArea li:eq("+currentIndex+")").find("button").removeClass("focus_purple");
		$(".helpBtn img").attr("src","assets/images/help_icon.png");
		$(".glossaryBtn img").attr("src","assets/images/glossary_icon.png");
		
		if( currentRef.menuStatusArr[currentRef.curChapterIndex].pages != undefined ){
			currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.curPageIndex].isVisited = "true";
			currentRef.checkChapterCompletionStatus();
		}
		
		if (_model.getAppDataObj().scorm == "scorm") {
			_model.getScormReference().storeTrackingData( JSON.stringify(currentRef.menuStatusArr) ); //Menu Status to LMS.
			//_model.getScormReference().storeAssessmentScore(scoreInPercentage);
        }else if(_model.getAppDataObj().scorm != "scorm"){
			localStorage.setItem(_model.getAppDataObj().courseName+'_v2',JSON.stringify(currentRef.menuStatusArr) );	
		}
		
		if( /iPhone|iPad|iPod/i.test(navigator.userAgent) ) {
			//$("#audioMuteBtn").css({'pointer-events': 'none', 'opacity': 0.5});
		}
		
		//$("#previousBtn").css({'pointer-events': 'auto', 'opacity': 1});
		
			$("#previousBtn").css("pointer-events","auto").find("img").attr("src","assets/images/prev_slide_button.png");
			
        _model.setTemplateStatus(false);
        /* _model.setAudioStatus(false); */

		//added to control the next notification after audio ends
		$("#nextNotification").hide();
		
        //$("#playPauseBtn img").attr('src', 'assets/images/pause_button.png'); // Added to act like pause button on page starts

		
		if($("#notes").css('display') == 'block'){
			$(".notesBtn > a > img").attr("src","assets/images/notes-icon-active.png");
		} else {
			$(".notesBtn > a > img").attr("src","assets/images/notes_icon.png");
		}
		
        if (_model.getAppDataObj().linear == "true") {
           //$('#nextBtn').css({'pointer-events': 'none', 'opacity': 0.5}); // disable the next button when navigation is set to linear.
			$("#nextBtn").css("pointer-events","none").find("img").attr("src","assets/images/next-slide-deactivated-button.png");
        } else {
            //$('#nextBtn').css({'pointer-events': 'auto', 'opacity': 1}); // enabled the next button when navigation is set to non-linear.
			$("#nextBtn").css("pointer-events","auto").find("img").attr("src","assets/images/next_slide_button.png");
        }
		
		if ( currentRef.menuStatusArr[currentRef.curChapterIndex].pages != undefined ){
			if (currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.curPageIndex].isVisited == "true") {
				//$('#nextBtn').css({'pointer-events': 'auto', 'opacity': 1});
				$("#nextBtn").css("pointer-events","auto").find("img").attr("src","assets/images/next_slide_button.png");
			}
		}
		
        $("#parentContainer").html('');

        currentRef.currentPageToLoadObj = _model.getTOCDataArr()[currentIndex];
        currentRef.currentPageTranscript = currentRef.currentPageToLoadObj.transcript;

        trace(currentRef.currentPageToLoadObj);

        if (currentRef.currentPageToLoadObj.isLocal == "true") {
            trace(":: Only loading HTML page from base folder location ::");
            var htmlURL = _model.getCourseDataObj().baseURL + "pages/" + currentRef.currentPageToLoadObj.templateName + ".html?version=" + StaticLibrary.generateRandom();
            trace("HTML Page URL : " + htmlURL);
            var apiServiceLoadAppData = new APIService();
            apiServiceLoadAppData.loadFromExternalSource(htmlURL, "true", "html", null, currentRef.loadExternalPageSuccessHandler);

        } else {
            trace(":: Going to load JSON and on competition loading of HTML Pages started ::");
            var jsonURL = _model.getCourseDataObj().baseURL + "assets/data/content/" + currentRef.currentPageToLoadObj.templateJSON + "." + StaticLibrary.DATA_TYPE + "?version=" + StaticLibrary.generateRandom();
            trace("JSON Data URL : " + jsonURL);
            var apiServiceLoadAppData = new APIService();
            apiServiceLoadAppData.loadFromExternalSource(jsonURL, "true", StaticLibrary.DATA_TYPE, null, currentRef.preloadDataHandler);
        }

        /************** Making menu Linear starts*******************/

        $("#menuContainerList li").removeClass("menu_active");
        $("#menuItem_" + currentRef.currentIndex).addClass("menu_active");

        if (_model.getAppDataObj().linear == "true") {
            $(".menu_active").css({'pointer-events': 'none', 'opacity': 1}); //making current page in menu not clickable
        }
        /************** Making menu Linear ends*******************/
	
		//making next button in last and first page to inactive state
		if (currentRef.currentIndex >= (_model.getTOCDataArr().length - 1)) {
			//$("#nextBtn").css({'pointer-events': 'none', 'opacity': 0.5});
			$("#nextBtn").css("pointer-events","none").find("img").attr("src","assets/images/next-slide-deactivated-button.png");
		}
		if (currentRef.currentIndex < 1){
			//$("#previousBtn").css({'pointer-events': 'none', 'opacity': 0.5});
			$("#previousBtn").css("pointer-events","none").find("img").attr("src","assets/images/prev-slide-deactivated-button.png");
		}
		
		
    }

    this.externalDataLoadHandler = function (data) {
		trace("Template Location : " + _model.getAppDataObj().templateLocation);
        trace("Template Name : " + currentRef.currentPageToLoadObj.templateName);
			
		StaticLibrary.HIDE_PRE_LOADER();
			
        var htmlURL = _model.getAppDataObj().templateLocation + currentRef.currentPageToLoadObj.templateName + ".html?version=" + StaticLibrary.generateRandom();
        trace("Template Page Location : " + htmlURL);

        trace(":: Loading HTML Template Started ::");
        var apiServiceLoadAppData = new APIService();
        apiServiceLoadAppData.loadFromExternalSource(htmlURL, "true", "html", null, currentRef.loadExternalPageSuccessHandler);

    }
	
	this.preloadDataHandler = function(data){
		
		trace(":: External JSON Loading Completed ::");
        trace(data);
		
		 _model.setCurrentPageDataObj(data);
		
		var baseURL = _model.getCourseDataObj().baseURL;
		console.log("baseURL baseURL baseURL baseURL: "+baseURL);
		
		var imgArr = data.pageContent.imagePreloadArry;
		
		currentRef.imageLoadIndex = 0;
		currentRef.totalImageCount = imgArr.length;
		
		if(currentRef.totalImageCount > 0){
			for(var i=0;i<imgArr.length;i++){
				var image = new Image();
				image.src = baseURL + 'assets/images/' +imgArr[i];
				image.addEventListener('load',currentRef.imageLoadListener,false);
				image.addEventListener('error',currentRef.imageLoadListener,false);
			}
		}else{
			currentRef.externalDataLoadHandler();
		}
	}
	
	this.imageLoadListener = function(){
		currentRef.imageLoadIndex++;
		
		console.log(currentRef.imageLoadIndex+" "+currentRef.totalImageCount);
		
		if(currentRef.totalImageCount == currentRef.imageLoadIndex){
			console.log('IMAGE PRELOADING COMPLETED');	
			currentRef.externalDataLoadHandler();
		}
	}

    //Add all the template that needs to be involved in the Framework in the below Switch case.
    this.loadExternalPageSuccessHandler = function (pageHTMLStr) {

        trace(":: Loading HTML Template Completed ::");

		if ((_model.getAppDataObj().linear == "false")) {
			if(!$(".menu_active i").hasClass("pull-right")){
				$(".menu_active").append('<i class="fa fa-check-circle text-default pull-right"></i>');
			}
		}

        $("#parentContainer").html('');
        $("#parentContainer").html(pageHTMLStr).promise().done(function () {

            trace(':: Page HTML content painted in the container ::');
		
            currentTemplate = currentRef.currentPageToLoadObj.templateName;
            currentTemplateObj;

            trace(currentTemplate);

            switch (currentTemplate) {
                case "ClickToRevealTemplate":
                    currentTemplateObj = new ClickToRevealTemplateController();
                break;
				
				case "Click_and_BuildTemplate":
                    currentTemplateObj = new Click_and_BuildTemplateController();
                break;
				
				case "DragandDropCombinedTemplate":
                    currentTemplateObj = new DragandDropCombinedTemplateController();
                break;
				
				case "DragandDropTemplate":
                    currentTemplateObj = new DragandDropTemplateController();
                break;
				
				case "DragandDropImageTemplate":
                    currentTemplateObj = new DragandDropImageTemplateController();
                break;
				
				case "DragandDropImageToImageTemplate":
                    currentTemplateObj = new DragandDropImageToImageTemplateController();
                break;
				
				case "DragandDropSingleImageDropTemplate":
                    currentTemplateObj = new DragandDropSingleImageDropTemplateController();
                break;

				case "Fill_In_the_Blanks_Template":
                    currentTemplateObj = new Fill_In_the_Blanks_TemplateController();
                break;

				case "FormativeAssessmentTemplate":
                    currentTemplateObj = new FormativeAssessmentTemplateController();
                break;

				case "HotspotsTemplate":
                    currentTemplateObj = new HotspotsTemplateController();
                break;

				case "ImageClickToRevealTemplate":
                    currentTemplateObj = new ImageClickToRevealTemplateController();
                break;

				case "DropDownListTemplate":
                    currentTemplateObj = new DropDownListTemplateController();
                break;

				case "AccordianTemplate":
                    currentTemplateObj = new AccordianTemplateController();
                break;

				case "TabTemplate":
                    currentTemplateObj = new TabTemplateController();
                break;

				case "DragandDropSequencing":
                    currentTemplateObj = new DragandDropSequencingController();
                break;

				case "TimelineSliderTemplate":
                    currentTemplateObj = new TimelineSliderController();
                break;
				
				case "TimelineMilstoneTemplate":
                currentTemplateObj = new TimelineMilstoneController();
                break;
				
				case "SlideShowTemplate":
                currentTemplateObj = new SlideShowTemplateController();
                break;
				
				case "Glossary":
                currentTemplateObj = new GlossaryController();
                break;
				
				case "TextSingleImageTemplate":
                currentTemplateObj = new TextSingleImageTemplateController();
                break;

				case "FlashcardTemplate":
                currentTemplateObj = new FlashcardTemplateController();
                break;
				
				case "SlideShowTemplateWithText":
                currentTemplateObj = new SlideShowWithTextTemplateController();
                break;
				
				case "CarousalClickTemplate":
					currentTemplateObj = new CarousalClickTemplateController();
                break;
					
				
                default:
                    trace(":: Template not found, please check with administrator ::");
                break;
            }

            currentTemplateObj.init(_model.getCurrentPageDataObj());

            $("#paginationTxt").html('');
            $("#paginationTxt").html("Page " + (currentRef.currentIndex + 1) + " of " + _model.getTOCDataArr().length);


            $("#audioTranscriptPopupContainer").html('');
            $("#audioTranscriptPopupContainer").html(_model.getTOCDataArr()[currentRef.currentIndex].transcript);
			//$("#playPauseBtn img").attr('src', 'assets/images/pause_button.png'); // Added to act like pause button on page starts
		   //trace("Audio Path : " + _model.getCourseDataObj().baseURL + "assets/media/audio/" + _model.getTOCDataArr()[currentRef.currentIndex].pageAudio);

           // currentRef.audioManager.loadAudio(_model.getCourseDataObj().baseURL + "assets/media/audio/" + _model.getTOCDataArr()[currentRef.currentIndex].pageAudio);
        });
    }

    //function to control the visibility of the framework level page loading.
    this.controlVisibility = function (currentView) {

        trace("Current Visible Container : " + currentView);
        $("#landingPage").hide();
       // $("#innerContainer").hide();
		$("#parentContainerParent").hide(); 
        $("#" + currentView).show();
    }
	
	//Check Chapter Completion Status
	this.checkChapterCompletionStatus = function(){
		var pageCompletionCount = 0;
		var chapterCompletionCount  = 0;
		if( currentRef.menuStatusArr[currentRef.curChapterIndex].pages.length != undefined ){
			for(var j=0;j<currentRef.menuStatusArr[currentRef.curChapterIndex].pages.length;j++){
				if(currentRef.menuStatusArr[currentRef.curChapterIndex].pages[j].isVisited == "true"){
						pageCompletionCount++;
				}
			}
			
			if(pageCompletionCount == currentRef.menuStatusArr[currentRef.curChapterIndex].pages.length){
				currentRef.menuStatusArr[currentRef.curChapterIndex].status = "COMPLETED";
			}
		}

		if (_model.getAppDataObj().scorm == "scorm") {
            for(var i=0;i<currentRef.menuStatusArr.length;i++){
				if(currentRef.menuStatusArr[i].status == "COMPLETED"){
					chapterCompletionCount++;	
				}
			}
				
			if(chapterCompletionCount == currentRef.menuStatusArr.length){
				//console.log('ALL CHAPTERS COMPLETED');
				_model.getScormReference().storeCompletionStatus("completed");
			}
        }
	}
	
	//update module status
	this.updateModuleMenuStatus = function(){
		for (var i = 0; i < _model.getLinearTOCDataArr().length; i++) {
			if(_model.getLinearTOCDataArr()[i].duration != undefined){
				if( currentRef.menuStatusArr[i].status == 'NOT_STARTED' ){
					if( _model.getAppDataObj().linear == "true" ){
						if(i == 0){
							$("#chapterMenu").children().eq(i).find('.unlock_icon').show();	
						}else{
							$("#chapterMenu").children().eq(i).find('.lock_icon').show();
						}
					}else{
						$("#chapterMenu").children().eq(i).find('.unlock_icon').show();
					}
				}else if( currentRef.menuStatusArr[i].status == 'IN_PROGRESS' ){
					$("#chapterMenu").children().eq(i).find('.unlock_icon').hide();
					$("#chapterMenu").children().eq(i).find('.progress_icon').show();
				}else if( currentRef.menuStatusArr[i].status == 'COMPLETED' ){
					$("#chapterMenu").children().eq(i).find('.unlock_icon').hide();
					$("#chapterMenu").children().eq(i).find('.progress_icon').hide();
					$("#chapterMenu").children().eq(i).find('.completed_icon').show();
				}
			}
		}
		
		$("#chapterMenu li").each(function(ind){
			$(this).attr('data-status',currentRef.menuStatusArr[ind].status);
		});
		
		$("#chapterMenu li").each(function(ind){
			var curEleStatus = $(this).attr('data-status');
			var nextEleStatus = $(this).next().attr('data-status');
			if( ( curEleStatus == 'COMPLETED' ) && (nextEleStatus == 'NOT_STARTED') ){
				$(this).next().find('.icon_menu').hide();	
				$(this).next().find('.unlock_icon').show();	
			}
		});
	}

}