
var ApplicationController = function () {

    var currentRef = this; //hack to get the reference of the current class
	var currentTemplate;
    var currentTemplateObj;
    this.currentIndex = 0;
    this.currentPageJSONData;
    this.currentPageToLoadObj;	
	this.totalPageCount = 0;
	this.totalKcQuestions = 0;
	this.paginationArray = new Array(); 
	this.istablet = (/ipad|android|android 3.0|xoom|sch-i800|playbook|tablet|kindle/i.test(navigator.userAgent.toLowerCase()));
	
    this.menuStatusArr = new Array();
	this.curChapterIndex = 0;
	this.curPageIndex = 0;
	this.imageLoadIndex = 0;
	this.totalImageCount = 0;
	this.menuItems = "";
	this.isTranscriptOpened = false;
	this.activeMenuIndex = 0;

	this.audioManager;
	
    this.init = function () {

		/* this function is executed after loading course data json file */

		currentRef.audioManager = new AudioManager();

		EventManager.getInstance().addControlEventListener(window, StaticLibrary.AUDIO_ENDED_EVENT, currentRef.audioEndEventHandler);

        $("#menuBoxContainer").hide();
        $("#parentContainerParent").hide();
		
		if(isAndroid){
			$(".projectTitle,.module_title").attr('tabindex','0');
		}

		 /* Making http request to TOC data json file and next blocks are executed in loadTOCSuccessHandler call back function */
		
		var tocURL = _model.getAppDataObj().baseURL + "/" + _model.getCourseDataObj().contentURL + "?version=" + StaticLibrary.generateRandom();

        var apiServiceLoadAppData = new APIService();
		apiServiceLoadAppData.loadTOCData(tocURL, "true", StaticLibrary.DATA_TYPE, null, this.loadTOCSuccessHandler);
		
		currentRef.createResourcesPopup(_model.getCourseDataObj().resources);

		$(document).on("visibilitychange", function() {
			if (document.hidden) {
				if(_model.getAudioStatus().status == "playing"){
					currentRef.audioManager.pauseAudio()
				}
			  } else  {
				if(_model.getAudioStatus().status == "playing"){
					currentRef.audioManager.playAudio()
				}
			  }
		});
		
    }
	
	/* Course Menu creation and status phase */

	this.createMenuList = function(){

		var menuListItems = "";
		var tempKc = false;
		var tempKcCount = 0;
		var tempPageIndex = "";
		var tempTitle = "";
		
		
		for(var i = 0; i < currentRef.menuStatusArr.length; i++){
			
			var liItems = "";

			for(var j = 0; j < currentRef.menuStatusArr[i].pages.length; j++) {

				if(currentRef.menuStatusArr[i].pages[j].kc != undefined) {

					if(!tempKc) {

						tempKc = true;
						tempTitle = _model.getLinearTOCDataArr()[i].pages[j].pageTitle;
						tempPageIndex = j;
						tempKcCount++;
						if(currentRef.menuStatusArr[i].pages[j].isVisited == "true") {
							tempKcVisitedCount++;
						}
			
					}else{

						tempKcCount++;
						if(currentRef.menuStatusArr[i].pages[j].isVisited == "true") {
							tempKcVisitedCount++;
						}

					}

					if(j+1 < currentRef.menuStatusArr[i].pages.length) {
						if(currentRef.menuStatusArr[i].pages[j+1].kc == undefined){
							if(tempKcCount == tempKcVisitedCount) {
								liItems += '<li><a class="completed-page" href="javascript:;" data-page-index="page_'+ tempPageIndex +'" tabindex="0" role="button">'+ tempTitle +'</a></li>';
							}else if(tempKcVisitedCount > 0) {
								liItems += '<li><a class="onprogress-page" href="javascript:;" data-page-index="page_'+ tempPageIndex +'" tabindex="0" role="button">'+ tempTitle +'</a></li>';
							}else{
								liItems += '<li><a href="javascript:;" data-page-index="page_'+ tempPageIndex +'" tabindex="-1" role="button">'+ tempTitle +'</a></li>';
							}
						}
					}else{
						if(tempKcCount == tempKcVisitedCount) {
							liItems += '<li><a class="completed-page" href="javascript:;" data-page-index="page_'+ tempPageIndex +'" tabindex="0" role="button">'+ tempTitle +'</a></li>';
						}else if(tempKcVisitedCount > 0) {
							liItems += '<li><a class="onprogress-page" href="javascript:;" data-page-index="page_'+ tempPageIndex +'" tabindex="0" role="button">'+ tempTitle +'</a></li>';
						}else{
							liItems += '<li><a href="javascript:;" data-page-index="page_'+ tempPageIndex +'" tabindex="-1" role="button">'+ tempTitle +'</a></li>';
						}
					}

				}else{

					if(currentRef.menuStatusArr[i].pages[j].isVisited == "true"){
						liItems += '<li><a class="completed-page" href="javascript:;" data-page-index="page_'+ j +'" tabindex="0" role="button">'+ _model.getLinearTOCDataArr()[i].pages[j].pageTitle +'</a></li>';
					}else{
						liItems += '<li><a href="javascript:;" data-page-index="page_'+ j +'" tabindex="-1" role="button">'+ _model.getLinearTOCDataArr()[i].pages[j].pageTitle +'</a></li>';
					}

					tempKc = false;
					tempKcCount = 0;
					tempKcVisitedCount = 0;

				}

				
			}

			menuListItems += '<li class="chapter-list"><a href="javascript:;" role="button">'+ _model.getLinearTOCDataArr()[i].pageTitle +'</a><ul data-chapter-index="chapter_'+ i +'">'+ liItems +'</ul></li>';
		}

		$("#menu_lst_container ul").html(menuListItems);

		currentRef.menuItems = $("#menu_lst_container ul");

		$("#menu_lst_container").off("click").on("click", currentRef.menuItemClickHandler)
	} 
	
    this.loadTOCSuccessHandler = function (data) {

		/* Setting TOC json datas to _model.setLinearTOCDataArr() */

        DataParser.parseTOCData(data);
		
		$(".projectTitle").html('').html(_model.getCourseDataObj().projectTitle);
		$(".module_title").html('').html(_model.getCourseDataObj().title);

		for (var b = 0; b < _model.getLinearTOCDataArr().length; b++) {
			currentRef.totalPageCount += _model.getLinearTOCDataArr()[b].pages.length; // Getting total number of pages count
		}

		for (var i = 0; i < _model.getLinearTOCDataArr().length; i++) {

            currentRef.menuStatusArr.push({"status":"NOT_STARTED"});
			if (_model.getLinearTOCDataArr()[i].pages != undefined) {
				currentRef.menuStatusArr[i].pages = new Array();

				/* Creating tracking data of learner */

				for (var j = 0; j < _model.getLinearTOCDataArr()[i].pages.length; j++) {
					var tempObj = {isVisited:"false"};
					if(_model.getLinearTOCDataArr()[i].pages[j].templateType == "KC" ||
					   _model.getLinearTOCDataArr()[i].pages[j].templateType == "Assessment") {
						tempObj.kc = {
							"score" : 0,
							"ac": 0,
							"acTaken": 0,
							"completed": "false"
						}
						currentRef.totalKcQuestions++;
					}
					currentRef.menuStatusArr[i].pages.push(tempObj);
				}
			}
		}	

		/* Storing tracking data in local storage or LMS depending on the run environment of this application */
	
		if( _model.getAppDataObj().scorm == "local" ){
			var storedCourseObj = localStorage.getItem(_model.getAppDataObj().courseName+'_v2');
			if( storedCourseObj != null && storedCourseObj != ""){
				var storedData = JSON.parse( storedCourseObj );
				currentRef.menuStatusArr = storedData;
			}
		}else if( _model.getAppDataObj().scorm == "scorm" ){
			var courseTrackingData = _model.getScormReference().retrieveTrackingData();
			if (courseTrackingData != "") {
				var curData = JSON.parse( courseTrackingData );
				currentRef.menuStatusArr = curData;
			}
		}

		currentRef.createMenuList();

		$(".icon_menu").hide();
		
		currentRef.startTheCourse();

		/* Making http request to glossary data json file and glossary functions are executed in glossaryPageSuccessHandler call back function */

		var glossaryHtml = "views/template/Glossary.html";
			var apiServiceLoadAppData = new APIService();
			apiServiceLoadAppData.loadFromExternalSource(glossaryHtml, "true", StaticLibrary.TEMPLATE_TYPE, null, currentRef.glossaryPageSuccessHandler);

    }

	this.loadInstructionSuccessHandler = function (data) {
		
		//to-do task for loading and painting the Glossary in Glossary Popup.
        var InstructionController = new InstructionController();
        InstructionController.init(data);
	}

	//Below code links is tempraray
	this.gotoIndex = function(e){
		if(e.target.className == "start_btn"){
			window.location.href="index.html";
		}
	}
	 
    //function to crate Resource Link for the Resource Popup
    this.createResourcesPopup = function (resourceData) {

        var resourceStr = "";
        $("#resource .modal-body").html('');
		if(resourceData.length > 0){
			for (var i = 0; i < resourceData.length; i++) {
				resourceStr += "<p><a target='_blank' href='" + _model.getAppDataObj().baseURL + "/assets/data/resources/" + resourceData[i].fileName + "'>" + resourceData[i].title + "</a></p>";
			}
		} else {
				resourceStr = "There are no resources for this module.";
		}
        $("#resource .modal-body").html(resourceStr);
    }


	this.homeButtonClickHandler = function(){
		
		window.open("index.html","_self"); 
	 
	}
	
    this.startTheCourse = function(){
		
		$("#pageJump").show();
		$("#menuPart").css({'pointer-events': 'auto', 'opacity': 1});
		$("#footerSection_1").css({'pointer-events': 'auto', 'opacity': 1});
		$("footer").show();
        $("#menuBoxContainer").hide();
        $("#headerSection_2").show();
        $("#footerSection_2").show();
		$("#parentContainerParent").show();

		if( /Android|iPhone|iPod/i.test(navigator.userAgent) ) {
			$("#headerSection_1").show();
			$("#headerSection_2").hide();
		}

		/* Attaching events to the global elements */

        setTimeout(function(){
            $("#previousBtn").unbind("click").bind("click", currentRef.previousClickHandler); 
			$("#nextBtn").unbind("click").bind("click", currentRef.nextClickHandler);
			$(".pause-play-flag").unbind("click").bind("click", currentRef.pausePlayHandler);
			$(".volume-control-flag").unbind("click").bind("click", currentRef.volumeControlHandler);
			$(".transcript-container").unbind("click").bind("click", currentRef.transcriptClickHandler);
			$(".replay-flag").unbind("click").bind("click", function() {
				$(this).blur()
				var currentPageNo = 0;
				
				for(var i = 0; i < currentRef.curChapterIndex; i++) {
					currentPageNo += _model.getLinearTOCDataArr()[i].pages.length;
				}

				currentPageNo += currentRef.currentIndex + 1;
				currentRef.loadCurrentPage(currentRef.curChapterIndex, currentRef.currentIndex, currentPageNo, "replayClick");

			});
			
			
			$(".instructionBtn").unbind("click").bind("click", currentRef.instructionClickHandler);
             
            $(".homeBtn").unbind("click").bind("click", currentRef.homeButtonClickHandler);
            $("#jumpToTxt").bind('keyup',  currentRef.jumpToSubmitHandler);
            $("#jumpToBtn").unbind("click").bind("click", currentRef.jumpToBtnHandler);
            //$("#paginationArea li").unbind("click").bind("click", currentRef.paginationHandler);
			  
			$("#menu_close").unbind("click").bind("click", currentRef.headerPopupCloseHandler);
			$('#MenuSection, #glossarySection, #myModal, #resource').on('shown.bs.modal', currentRef.menuPopupHandler);
			 $("#resourcePopup, #MenuSection, #glossarySection, #myModal, #resource").on("hidden.bs.modal", currentRef.headerPopupCloseHandler);	 	  	
			 $("#instructionClose").on("click", currentRef.popupCloseHandler);	 	
			 $(".instruction_modal, .menu_Popupon").on("hidden.bs.modal", currentRef.popupCloseHandler);	 	  	

			 $("#mobileMenuIcon").unbind("click").bind("click", currentRef.mobileMenuHandler);
			 $("#mobileMenuOverlay").unbind("click").bind("click", currentRef.mobileMenuHandler);

			 $(".instructionBtn").off("blur").on("blur", function() {

				if($("body").hasClass("overlay-opened")){
					$(".homeBtn").focus();
				}
	
			});
					
            currentRef.controlVisibility("parentContainerParent");
            currentRef.loadCurrentPage(currentRef.curChapterIndex, currentRef.currentIndex, 1, "initialLoad");
        }, 200);
	}
	
	this.jumpToSubmitHandler = function(event){
		if(event.keyCode == 13){ 
			event.preventDefault();
			$("#jumpToBtn").click(); 
			return false;
		}
	}
	
	this.jumpToBtnHandler = function(){
		trace("Jump To Page : " + $("#jumpToTxt").val());
		var totalPages = _model.getTOCDataArr().length;
		var jumpToPage = (parseInt($("#jumpToTxt").val()) - 1);
		if((jumpToPage < totalPages) && (jumpToPage >= 0)){
			currentRef.currentIndex = jumpToPage;
			currentRef.loadCurrentPage(currentRef.currentIndex);
		} else {
			alert("Incorrect page number.");
		}
	}
	
    this.mobileMenuHandler = function () { 


        if ($("#system_menu").css("display") == "block") {

			$("#mobileMenuOverlay").hide();
			$("body").removeClass("overlay-opened");

			if(_model.getAudioStatus().status == "playing") {
				currentRef.audioManager.playAudio();
			}

            $("#system_menu").animate({'position': 'absolute', 'right': '-148px'}, 500, function () {
                $("#system_menu").hide();
				$(".disableMenuBG").hide();
				$("#mobileMenuIcon").parent().css("background","none");
			});
			
        } else {

			$("#mobileMenuOverlay").show();
			$("body").addClass("overlay-opened");

			if(_model.getAudioStatus().status == "playing") {
				currentRef.audioManager.pauseAudio();
			}

            $("#system_menu").show(1, function () {
				$(".disableMenuBG").show();
                $("#system_menu").animate({'position': 'absolute', 'right': '0px'}, 500);
				$("#mobileMenuIcon").parent().css("background","#ea7600");
            });

        }

    };
    this.menuItemClickHandler = function (event) {

		var clickedClass = event.target.className;
		if(clickedClass == "completed-page") {

			var pageIndex = event.target.dataset.pageIndex;
			pageIndex = pageIndex.split("_");
			pageIndex = Number(pageIndex[1]);

			var chapterIndex = $(event.target).parents("ul")[0];
			chapterIndex = chapterIndex.dataset.chapterIndex;
			chapterIndex = chapterIndex.split("_");
			chapterIndex = Number(chapterIndex[1]);
			
			currentRef.curChapterIndex = chapterIndex;
			currentRef.currentIndex = pageIndex;

			var currentPageNo = 0;

			for(var i = 0; i < currentRef.curChapterIndex; i++) {
				currentPageNo += _model.getLinearTOCDataArr()[i].pages.length;
			}

			currentPageNo += currentRef.currentIndex + 1;
		
			$("#mobileMenuOverlay").hide();
			
			 currentRef.loadCurrentPage(currentRef.curChapterIndex, currentRef.currentIndex, currentPageNo, "menuClick");
			$("#MenuSection").modal('hide');
		}

    }
	
	
    //function to handle the previous button click to load previous pages in the shell
    this.previousClickHandler = function () {

		var currentPageNo = 0;
		var tempIndex = currentRef.currentIndex + 1;
		
		for(var i = 0; i < currentRef.curChapterIndex; i++) {
			currentPageNo += _model.getLinearTOCDataArr()[i].pages.length;
		}

		currentPageNo += tempIndex - 1;
		
		if(currentRef.curChapterIndex > 0 || currentRef.currentIndex >= 1){
			if((currentRef.currentIndex-1) % _model.getLinearTOCDataArr()[currentRef.curChapterIndex].pages.length > 0){
				currentRef.currentIndex--;
				console.log('s')
			}else{
				if(currentRef.curChapterIndex > 0) {
					currentRef.curChapterIndex--;
					currentRef.currentIndex = _model.getLinearTOCDataArr()[currentRef.curChapterIndex].pages.length - 1;
				}else{
					currentRef.currentIndex = 0;
				}
				console.log('a')
				
			}
			currentRef.loadCurrentPage(currentRef.curChapterIndex, currentRef.currentIndex, currentPageNo, "previousClick");
		}	
        
    }

    //function to handle the next button click to load next pages in the shell
    this.nextClickHandler = function () {

		var currentPageNo = 0;
		var tempIndex = currentRef.currentIndex + 1;
		
		for(var i = 0; i < currentRef.curChapterIndex; i++) {
			currentPageNo += _model.getLinearTOCDataArr()[i].pages.length;
		}
		currentPageNo += tempIndex + 1;

		if(currentPageNo <= currentRef.totalPageCount){
			if((currentRef.currentIndex+1) % _model.getLinearTOCDataArr()[currentRef.curChapterIndex].pages.length != 0){
				currentRef.currentIndex++
				// if(_model.getLinearTOCDataArr()[currentRef.curChapterIndex].pages[currentRef.currentIndex].templateType == "Assessment" && 
				// 	currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].isVisited == "true" && 
				// 	_model.getLinearTOCDataArr()[currentRef.curChapterIndex].pages[currentRef.currentIndex+1].templateType == "Assessment" ) {
				// 		currentRef.nextClickHandler();
				// 		return;
				// 	}
			}else{
				currentRef.curChapterIndex++;
				currentRef.currentIndex = 0;
			}
			currentRef.loadCurrentPage(currentRef.curChapterIndex, currentRef.currentIndex, currentPageNo, "nextClick");
		}	

	}    
	
	this.pausePlayHandler = function() {
		$(this).blur()
		if(_model.getAudioStatus().status == "playing") {
			currentRef.audioManager.pauseAudio();
			$(this).removeClass("pause-flag");
			_model.setAudioStatus({
                status : "paused",
                volume : null
            });
		}else if(_model.getAudioStatus().status == "paused") {
			currentRef.audioManager.playAudio();
			$(this).addClass("pause-flag");
			_model.setAudioStatus({
                status : "playing",
                volume : null
            });
		}
	}

	this.volumeControlHandler = function() {
		$(this).blur()
		if(_model.getAudioStatus().volume != "muted") {
			$(this).addClass("mute-flag");
			currentRef.audioManager.muteAudio();
			_model.setAudioStatus({
				status : null,
				volume: "muted"
			})
		}else{
			$(this).removeClass("mute-flag");
			currentRef.audioManager.unMuteAudio();
			_model.setAudioStatus({
				status : null,
				volume: "un-muted"
			})
		}
	}

	this.transcriptClickHandler = function(e) {
		$(this).blur()
		if(e.target.className.indexOf("transcript-container") > -1  || 
		   e.target.className.indexOf("fa-sticky-note") > -1 ||
		   e.target.className.indexOf("transcript-close") > -1 ) {
				if(!currentRef.isTranscriptOpened) {
					$(".transcript-wrapper").addClass("show-transcript");
					currentRef.isTranscriptOpened = true;
					$(".transcript-header span").attr("tabindex", "0")
					$(".transcript-body > a").attr("tabindex", "0")
				}else{
					$(".transcript-wrapper").removeClass("show-transcript");
					currentRef.isTranscriptOpened = false;
					$(".transcript-header span").attr("tabindex", "-1")
					$(".transcript-body > a").attr("tabindex", "-1")
				}
		   }
		
	}

	this.audioEndEventHandler = function() {
		$(".pause-play-flag").removeClass("pause-flag")
	}
 
	this.popupCloseHandler = function(){
		$("#instructionBtn img").attr("src","assets/images/instruction_icon.png");
	}

	this.menuPopupHandler = function() {
		$(".modal-dialog .close").focus();

		if(!$("body").hasClass("overlay-opened")) {
			if(_model.getAudioStatus().status == "playing") {
				currentRef.audioManager.pauseAudio();
			}
		}
		
	}
	
	this.headerPopupCloseHandler = function(){

		if(!$("body").hasClass("overlay-opened")) {
			if(_model.getAudioStatus().status == "playing") {
				currentRef.audioManager.playAudio();
			}
		}
			
	}

	this.makeGblBtnsUt = function() {
		$("#nextBtn a, #previousBtn a, .homeBtn, .glossaryBtn, .instructionBtn, .helpBtn").attr('tabindex','-1');
	}

    //function to handle the click event for Glossary button from the shell
    this.glossaryClickHandler = function () {
		 
		 if($(".glossaryBtn").attr("data-label") == "not_selected"){
			$(".glossaryBtn").attr("data-label","selected");
			$("#mobileMenuOverlay").hide();
			$(".glossaryBtn img").attr("src","assets/images/glossary-icon-active.png");
			$(".helpBtn img").attr("src","assets/images/help_icon.png");
			
			
		 } else {
			 $(".glossaryBtn").attr("data-label","not_selected");
			 $(".glossaryBtn img").attr("src","assets/images/glossary_icon.png");
			 currentRef.loadCurrentPage(currentRef.currentIndex);
		 }
			$("#system_menu").animate({'position': 'absolute', 'right': '-148px'}, 500, function () {
					$(".menu_click_bg").css("background","none");
				$("#system_menu").hide();
				$(".disableMenuBG").hide();
			}); 
			
    }
	
	this.instructionClickHandler = function(data){
	
		$("#instructionContent").html("").html(_model.getCourseDataObj().instructionData);
		

	}
	
	this.glossaryPageSuccessHandler = function(data){
		$("#glossarySection .modal-body").html(data).promise().done(function(){

			 $("#preloader").hide();
			var glossaryURL = _model.getAppDataObj().baseURL + "/assets/data/content/glossary.json?version=" + StaticLibrary.generateRandom();

			var apiServiceLoadAppData = new APIService();
			apiServiceLoadAppData.loadTOCData(glossaryURL, "true", StaticLibrary.DATA_TYPE, null, currentRef.loadGlossarySuccessHandler);

		});
	}
	
	this.loadGlossarySuccessHandler = function (data) {

        //to-do task for loading and painting the Glossary in Glossary Popup.
        var glossaryController = new GlossaryController();
        glossaryController.init(data);
        // currentRef.createResourcesPopup(_model.getCourseDataObj().resources);
	
	}
	
	
	this.courseMenuHideHandler = function () {
		if($( window ).width() <= 480){
			$("#system_menu").css({'right':'-148px','display':'none'});
		}
	}

	
	this.updateMenuNdTrackingStatus = function(status, scoreObj) {
	
		if(status == "visited") {
			
			if( currentRef.menuStatusArr[currentRef.curChapterIndex].pages != undefined ){
				console.log(currentRef.activeMenuIndex)
				currentRef.menuItems.find(".chapter-list").eq(currentRef.curChapterIndex).find("ul").
				find("a").eq(currentRef.activeMenuIndex).addClass("completed-page");
				

				currentRef.menuItems.find(".chapter-list").eq(currentRef.curChapterIndex).find("ul").
				find("a").eq(currentRef.activeMenuIndex).attr("tabindex", 0);

				currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].isVisited = "true";
				currentRef.checkChapterCompletionStatus();
			}
		}

		if(scoreObj != null) {
			if( currentRef.menuStatusArr[currentRef.curChapterIndex].pages != undefined ){
				currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.score = scoreObj.score;
				currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.completed = scoreObj.completed;
				currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.acTaken = scoreObj.attemptsTaken;
				currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].isVisited = "true";

				currentRef.updateKCTrackingStatus();
				currentRef.checkChapterCompletionStatus();
			}
		}
		
		if (_model.getAppDataObj().scorm == "scorm") {
			_model.getScormReference().storeTrackingData( JSON.stringify(currentRef.menuStatusArr) ); //Menu Status to LMS.
			//_model.getScormReference().storeAssessmentScore(scoreInPercentage);
        }else if(_model.getAppDataObj().scorm != "scorm"){
			localStorage.setItem(_model.getAppDataObj().courseName+'_v2',JSON.stringify(currentRef.menuStatusArr) );	
		}

	}

	this.updateKCTrackingStatus = function() {

		var tempFirstIndex = currentRef.currentIndex;
		var tempLastIndex;
		var tempCount = 0;
		var tempVisitedCount = 0;

		while((tempFirstIndex - 1) >= 0) {
			if(currentRef.menuStatusArr[currentRef.curChapterIndex].pages[tempFirstIndex - 1].kc){
				tempFirstIndex--;
			}else{
				break;
			}
		}

		tempLastIndex = tempFirstIndex;

		while((tempLastIndex+1) < currentRef.menuStatusArr[currentRef.curChapterIndex].pages.length) {
			if(currentRef.menuStatusArr[currentRef.curChapterIndex].pages[tempLastIndex+1].kc){
				tempLastIndex++;
			}else{
				break;
			}
		}

		for(var i = tempFirstIndex; i <= tempLastIndex; i++) {
			tempCount++;
			if(currentRef.menuStatusArr[currentRef.curChapterIndex].pages[i].isVisited == "true") {
				tempVisitedCount++;
			}
		}

		if(tempVisitedCount == tempCount) {

			currentRef.menuItems.find(".chapter-list").eq(currentRef.curChapterIndex).find("ul").
			find("a").eq(tempFirstIndex).addClass("completed-page");

			currentRef.menuItems.find(".chapter-list").eq(currentRef.curChapterIndex).find("ul").
			find("a").eq(tempFirstIndex).removeClass("onprogress-page");

			currentRef.menuItems.find(".chapter-list").eq(currentRef.curChapterIndex).find("ul").
			find("a").eq(tempFirstIndex).attr("tabindex", 0);

		}else if(tempVisitedCount > 0) {

			currentRef.menuItems.find(".chapter-list").eq(currentRef.curChapterIndex).find("ul").
			find("a").eq(tempFirstIndex).addClass("onprogress-page");

			currentRef.menuItems.find(".chapter-list").eq(currentRef.curChapterIndex).find("ul").
			find("a").eq(tempFirstIndex).attr("tabindex", 0);
		}
	}

	/* loadCurrentPage initiates the loading of topic pages*/

    this.loadCurrentPage = function (currentChapter, currentIndex, currentPageNo, flag) {

		if(currentPageNo <= currentRef.totalPageCount) {

		StaticLibrary.SHOW_PRE_LOADER();
		currentRef.audioManager.stopAudio();
		$(".replay-flag").css({"opacity": "1", "pointer-events": "auto"});

		$(".pageNum").html((currentPageNo) + " of "+ currentRef.totalPageCount);
		
		if(currentPageNo == 1){
			$("#previousBtn").css({"opacity": "0.3", "pointer-events": "none"});
			$("#previousBtn a").attr("tabindex", "-1");
			$("#previousBtn a").blur();
			$("#nextBtn").css({"opacity": "1", "pointer-events": "auto"});
			$("#nextBtn a").attr("tabindex", "0");
		}else if(currentPageNo == currentRef.totalPageCount){
			$("#nextBtn").css({"opacity": "0.3", "pointer-events": "none"});
			$("#nextBtn a").attr("tabindex", "-1");
			$("#nextBtn a").blur();
			$("#previousBtn").css({"opacity": "1", "pointer-events": "auto"});
			$("#previousBtn a").attr("tabindex", "0");
		}else{
			
			if(_model.getLinearTOCDataArr()[currentChapter].pages[currentIndex].templateType == "Assessment" && 
			   currentRef.menuStatusArr[currentChapter].pages[currentIndex].isVisited == "false") {
				$("#previousBtn").css({"opacity": "0.3", "pointer-events": "none"});
				$("#previousBtn a").attr("tabindex", "-1");
				$("#previousBtn a").blur();
				$("#nextBtn").css({"opacity": "0.3", "pointer-events": "none"});
				$("#nextBtn a").attr("tabindex", "-1");
				$("#nextBtn a").blur();
				$(".replay-flag").css({"opacity": "0.3", "pointer-events": "none"});
			}else{
				$("#nextBtn").css({"opacity": "1", "pointer-events": "auto"});
				$("#nextBtn a").attr("tabindex", "0");
				$("#previousBtn").css({"opacity": "1", "pointer-events": "auto"});
				$("#previousBtn a").attr("tabindex", "0");
			}
			
		}

		$("#mobileMenuOverlay").hide();
		currentRef.setActiveMenuIndex(currentIndex)

		if(currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc == undefined) {
			if(currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].isVisited != "true"){
				currentRef.updateMenuNdTrackingStatus("visited", null);
			}
		}	
		
        $("#parentContainer").html('');

		currentRef.currentPageToLoadObj = _model.getLinearTOCDataArr()[currentChapter].pages[currentIndex];

		if(currentRef.currentPageToLoadObj.pageAudio != undefined) {

			if(currentRef.currentPageToLoadObj.pageAudio != "") {
				currentRef.audioManager.loadAudio(_model.getAppDataObj().baseURL + "/assets/media/audio/" +currentRef.currentPageToLoadObj.pageAudio);
				_model.setAudioStatus({
					status : "loaded",
					volume : null
				});

			}else{
				_model.setAudioStatus({
					status : "no-audio",
					volume : null
				});
				$(".pause-play-flag").removeClass("pause-flag");
			}

		}else{
			_model.setAudioStatus({
				status : "no-audio",
				volume : null
			});
			$(".pause-play-flag").removeClass("pause-flag")
		}
		
		/* Making http request to content data json file of pages and pre loading images are executed in preloadDataHandler call back function */

        var jsonURL = _model.getAppDataObj().baseURL + "/assets/data/content/" + currentRef.currentPageToLoadObj.templateJSON + "." + StaticLibrary.DATA_TYPE + "?version=" + StaticLibrary.generateRandom();

        var apiServiceLoadAppData = new APIService();
        apiServiceLoadAppData.loadFromExternalSource(jsonURL, "true", StaticLibrary.DATA_TYPE, null, currentRef.preloadDataHandler);	

		}
		
    }

    this.externalDataLoadHandler = function (data) {
			
		/* Making http request to page templates and next set of blocks executed in loadExternalPageSuccessHandler call back function */

        var htmlURL = _model.getAppDataObj().templateLocation + currentRef.currentPageToLoadObj.templateName + ".html?version=" + StaticLibrary.generateRandom();

        var apiServiceLoadAppData = new APIService();
        apiServiceLoadAppData.loadFromExternalSource(htmlURL, "true", "html", null, currentRef.loadExternalPageSuccessHandler);

    }
	
	this.preloadDataHandler = function(data){
		
		 _model.setCurrentPageDataObj(data);
		
		var baseURL = _model.getAppDataObj().baseURL;
		
		var imgArr = data.pageContent.imagePreloadArry;
		
		currentRef.imageLoadIndex = 0;
		currentRef.totalImageCount = imgArr.length;
		
		if(currentRef.totalImageCount > 0){
			for(var i=0;i<imgArr.length;i++){
				var image = new Image();
				image.src = baseURL + '/assets/images/' +imgArr[i];
				image.addEventListener('load',currentRef.imageLoadListener,false);
				image.addEventListener('error',currentRef.imageLoadListener,false);
			}
		}else{
			currentRef.externalDataLoadHandler();
		}
	}
	
	this.imageLoadListener = function(){

		currentRef.imageLoadIndex++;
		
		if(currentRef.totalImageCount == currentRef.imageLoadIndex){	
			currentRef.externalDataLoadHandler();
		}
	}

    //Add all the template that needs to be involved in the Framework in the below Switch case.
    this.loadExternalPageSuccessHandler = function (pageHTMLStr) {

		if ((_model.getAppDataObj().linear == "false")) {
			if(!$(".menu_active i").hasClass("pull-right")){
				$(".menu_active").append('<i class="fa fa-check-circle text-default pull-right"></i>');
			}
		}

        $("#parentContainer").html('');
        $("#parentContainer").html(pageHTMLStr).promise().done(function () {
			
            currentTemplate = currentRef.currentPageToLoadObj.templateName;
            currentTemplateObj;

			/* Initialize the appropriate template scripts */

            switch (currentTemplate) {

				case "AccordianTemplate":
                    currentTemplateObj = new AccordianTemplateController(currentRef);
                break;

				case "AssessmentTemplate":
                    currentTemplateObj = new FormativeAssessmentTemplateController(currentRef);
				break;
				
				case "CongratulationTemplate":
					currentTemplateObj = new CongratulationTemplateController(currentRef);
				break;
				
				case "Glossary":
                	currentTemplateObj = new GlossaryController();
                break;

				case "ResultPageTemplate":
					currentTemplateObj = new ResultPageTemplateController(currentRef);
				break;

				case "TabTemplate":
                	currentTemplateObj = new TabTemplateController(currentRef);
				break;
				
				case "TextSingleImageTemplate":
                	currentTemplateObj = new TextSingleImageTemplateController(currentRef);
				break;	

				case "Fill_In_the_Blanks_Template":
                	currentTemplateObj = new Fill_In_the_Blanks_TemplateController(currentRef);
				break;	

				case "FlashcardTemplate":
                	currentTemplateObj = new FlashcardTemplateController(currentRef);
				break;
				
				
                default:
                    trace(":: Template not found, please check with administrator ::");
                break;
            }

            currentTemplateObj.init(_model.getCurrentPageDataObj());

            $("#paginationTxt").html('');
            $("#paginationTxt").html("Page " + (currentRef.currentIndex + 1) + " of " + _model.getTOCDataArr().length);


            $("#audioTranscriptPopupContainer").html('');
            $("#audioTranscriptPopupContainer").html(_model.getTOCDataArr()[currentRef.currentIndex].transcript);
		   	   
		  
		   $(".glossary").off("click").on("click", currentRef.innerGlossaryClickHandler);
			$("body:not(.screenGlossaryCallout)").off("click").on("click", currentRef.innerGlossaryCloseHandler);
		   
		   for(var i = 0; i < $(".glossary").length; i++){ 
			$(".glossary").eq(i).addClass("glossary_"+$(".glossary").eq(i).data("glossary"));
		}
		
		});
		
		if(_model.getAudioStatus().status == "no-audio") {
			StaticLibrary.HIDE_PRE_LOADER();
			
		}else{
			currentRef.audioManager.playAudio();
			$(".pause-play-flag").addClass("pause-flag")
			_model.setAudioStatus({
                status : "playing",
                volume : null
            });
		}

		if(currentRef.currentPageToLoadObj.transcript != undefined) {
			$(".transcript-body > a").html(currentRef.currentPageToLoadObj.transcript);
		}else{
			$(".transcript-body > a").html("");
		}
		
		
	}
	
	this.setActiveMenuIndex = function(currentIndex) {
		var activeMenuIndex = 0;
		var kcDetected = false;
		for(var i = 0; i < (currentIndex+1); i++ ) {
			if(currentRef.menuStatusArr[currentRef.curChapterIndex].pages[i].kc != undefined) {
				if(kcDetected == false) {
					activeMenuIndex++;
					kcDetected = true;
				}
			}else{
				kcDetected = false;
				activeMenuIndex++;
			}
		}
		currentRef.activeMenuIndex = --activeMenuIndex;
	}

	this.innerGlossaryClickHandler = function(){
		
	var glossaryData = $(this).data("glossary");
	var glossaryURL = _model.getAppDataObj().baseURL + "/assets/data/content/glossary.json?version=" + StaticLibrary.generateRandom();
			
		var apiServiceLoadAppData = new APIService();
        apiServiceLoadAppData.loadTOCData(glossaryURL, "true", StaticLibrary.DATA_TYPE, null, function(data){
			var glossaryController = new GlossaryController();
			glossaryController.innerGlossary(data, glossaryData);
		})
		
	}
	
	this.innerGlossaryCloseHandler = function(){ 
		$(".screenGlossaryCallout").remove();
	}
	
    //function to control the visibility of the framework level page loading.
    this.controlVisibility = function (currentView) {

		$("#" + currentView).show();
		
    }
	
	//Check Chapter Completion Status
	this.checkChapterCompletionStatus = function(){
		var pageCompletionCount = 0;
		var chapterCompletionCount  = 0;
		if( currentRef.menuStatusArr[currentRef.curChapterIndex].pages.length != undefined ){
			for(var j=0;j<currentRef.menuStatusArr[currentRef.curChapterIndex].pages.length;j++){
				if(currentRef.menuStatusArr[currentRef.curChapterIndex].pages[j].isVisited == "true"){
						pageCompletionCount++;
				}
			}
			
			if(pageCompletionCount == currentRef.menuStatusArr[currentRef.curChapterIndex].pages.length){
				currentRef.menuStatusArr[currentRef.curChapterIndex].status = "COMPLETED";
			}
		}

		if (_model.getAppDataObj().scorm == "scorm") {
            for(var i=0;i<currentRef.menuStatusArr.length;i++){
				if(currentRef.menuStatusArr[i].status == "COMPLETED"){
					chapterCompletionCount++;	
				}
			}
				
			if(chapterCompletionCount == currentRef.menuStatusArr.length){
				
				_model.getScormReference().storeCompletionStatus("completed");
			}
		}

	}

}