var scormAPI = function(){
	var scorm;
	var startTime;
	this.isScormStarted =false;
	var _this = this;
	
	// Init Scorm 
	function initScorm(){
		scorm = pipwerks.SCORM;
		scorm.version = "1.2";
		scorm.init();
		_this.isScormStarted = scorm.connection.isActive;
		var date = new Date();
		startTime = date.getTime();

		window.onbeforeunload = function () { exitScorm(); return null; };
	}
	
	function setSessionTime(){
		var date = new Date();
		var diffTime = date.getTime() - startTime;
		
		var totalseconds = Math.round(diffTime / 1000);
		var hours = Math.round(totalseconds / 3600);
		var minutes = Math.round((totalseconds / 60) % 60);
		var seconds = totalseconds % 60;
		
		var fs = seconds < 10 ? "0" + seconds : "" + seconds;
		var fm = minutes < 10 ? "0" + minutes : "" + minutes;
		var fh = hours < 10 ? "0" + hours : "" + hours;
		var formatted = fh + ":" + fm + ":" + fs;
		
		scorm.set('cmi.core.session_time', formatted);
		scorm.save();
	}
	
	// Getter Methods
	this.retrieveTrackingData = function(){
		var trackData = scorm.get('cmi.suspend_data');
		return trackData;
	}
	
	this.retrieveVisitedScreenNo = function(){
		var screenNo = scorm.get('cmi.core.lesson_location');
		return screenNo;
	}
	
	this.retrieveCompletionStatus = function(){
		var curStatus = scorm.get('cmi.core.lesson_status');
		return curStatus;	
	}

	this.getAssessmentScore = function() {
		var curScore = scorm.get('cmi.core.score.raw');
		return curScore;
	}
	
	// Setter Methods
	this.storeAssessmentScore = function(score){
		if(_this.isScormStarted){
			scorm.set('cmi.core.score.raw', score);		
			scorm.save();
		}
	}
	
	this.storeVisitedScreenNo = function(screenNum){
		if(_this.isScormStarted){
			scorm.set('cmi.core.lesson_location', screenNum);	
			scorm.save();
		}
	}
	
	this.storeTrackingData = function(trackData){
		console.log("2. " + "scorm")
		if(_this.isScormStarted){
			console.log("3 " + "scorm")
			scorm.set('cmi.suspend_data', trackData);	
			scorm.save();
		}
	}
	
	this.storeCompletionStatus = function(status){
		if(_this.isScormStarted){
			scorm.set('cmi.core.lesson_status', status);	
			scorm.save();
		}
	}
	
	function exitScorm(){
		if(scorm.connection.isActive){
			setSessionTime();
			scorm.save();
			scorm.quit();
		}
	}
	
	initScorm();

}