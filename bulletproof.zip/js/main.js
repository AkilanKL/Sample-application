
var _model = DataManager.getInstance();

var appControllerObj, lessonId;

$(document).ready(function(){

    $('[data-toggle="tooltip"]').tooltip();


    StaticLibrary.SHOW_PRE_LOADER();

     /* Making http request to App data json file and next blocks are executed in loadAppDataSuccessHandler call back function */
     
	var apiServiceLoadAppData = new APIService();
        apiServiceLoadAppData.loadAppConfigData(StaticLibrary.APP_DATA_URL, "true", StaticLibrary.DATA_TYPE, null, loadAppDataSuccessHandler);

    //setup the jPlayer plugin and only on the ready of the plugin the Framework will start the calls.
    $("#jquery_jplayer_1").jPlayer({
        ready: function () {

            _model.setAudioReference($(this));
           
        },
        ended:function(){
           
            _model.setAudioStatus({
                status : "ended",
                volume : null
            });

            EventManager.getInstance().dispatchCustomEvent(window, StaticLibrary.AUDIO_ENDED_EVENT, true, null);

        },
        loadeddata: function(event){
            _model.setAudioDuration(event.jPlayer.status.duration);
        },
        timeupdate:function(event){

            if((event.jPlayer.status.currentTime >= 0.10) && (_model.getPreloaderFlag())){
                StaticLibrary.HIDE_PRE_LOADER();
            }
           
            appControllerObj.progressHandler(event.jPlayer.status.currentTime)

        }
    });

    _model.setAudioStatus({
        status : null,
		volume: "un-muted"
    });
     
        
});

function loadAppDataSuccessHandler(data){

    DataParser.parseAppData(data);
    
    /* Making http request to landing page and next blocks are executed in landingPageSuccessHandler call back function*/

    var landingPageUrl = _model.getAppDataObj().baseURL + "/pages/landingPage.html";
    var apiServiceLoadLP = new APIService();
    apiServiceLoadLP.loadFromExternalSource(landingPageUrl, "true", StaticLibrary.TEMPLATE_TYPE, null, landingPageSuccessHandler);

   
}

function landingPageSuccessHandler(data) {
    $("#landingPage").html(data).promise().done(function(){
        StaticLibrary.HIDE_PRE_LOADER();

        /*  Start button triggers */

        $("#btnStart").off("click").on("click", function(){

            $(".landingscreen_bg").hide();
            $(".grandparent").show();	 
                
            /* Making http request to Course data json fileand next blocks are executed in loadCourseDataSuccessHandler call back function */

            var courseDataURL = _model.getAppDataObj().baseURL + "/assets/data/courseData.json?version=" + StaticLibrary.generateRandom();
            var apiServiceLoadCourseData = new APIService();
            apiServiceLoadCourseData.loadCourseData(courseDataURL, "true", StaticLibrary.DATA_TYPE, null, loadCourseDataSuccessHandler);	
                
        })
   });
}

function loadCourseDataSuccessHandler(data){

    DataParser.parseCourseData(data);	
	
	if(_model.getAppDataObj().scorm == "scorm"){
		var scormAPIObj = new scormAPI();
		_model.setScormReference(scormAPIObj);	
	}
	
    $(".projectTitle").html(_model.getCourseDataObj().projectTitle);
    $(".module_title").html(_model.getCourseDataObj().title);

    $("#desktopHelpImage").attr("src", _model.getCourseDataObj().baseURL + "assets/images/" + _model.getCourseDataObj().desktopHelp);

    /* Initialize course controller */

   appControllerObj = new ApplicationController();
   appControllerObj.init(); 
	
} 

function trace(datastr){
	console.log(datastr);
}
