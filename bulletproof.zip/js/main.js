
var _model = DataManager.getInstance();

var appControllerObj, lessonId;

$(document).ready(function(){

    $('[data-toggle="tooltip"]').tooltip();
    
    /* Skip to main content focus */

    $("#skip-nav").focusin(function() {
        $(this).addClass("skip-navigation-show");
    });
    $("#skip-nav").focusout(function() {
        $(this).removeClass("skip-navigation-show");
    });
    $("#skip-nav").click(function() {
        $("#main-content").focus();
    })


    StaticLibrary.SHOW_PRE_LOADER();

     /* Making http request to App data json file and next blocks are executed in loadAppDataSuccessHandler call back function */
     
	var apiServiceLoadAppData = new APIService();
        apiServiceLoadAppData.loadAppConfigData(StaticLibrary.APP_DATA_URL, "true", StaticLibrary.DATA_TYPE, null, loadAppDataSuccessHandler);

    //setup the jPlayer plugin and only on the ready of the plugin the Framework will start the calls.
    $("#jquery_jplayer_1").jPlayer({
        ready: function () {
            $(this).jPlayer("setMedia", {
                mp3: "assets/media/audio/blank.mp3",
                ogg: "assets/media/audio/blank.ogg"
            });

            _model.setAudioReference($(this));

           
        },
        ended:function(){
           
            _model.setAudioStatus({
                status : "ended",
                volume : null
            });

            EventManager.getInstance().dispatchCustomEvent(window, StaticLibrary.AUDIO_ENDED_EVENT, true, null);

        },
        timeupdate:function(event){

            if((event.jPlayer.status.currentTime >= 0.10) && (_model.getPreloaderFlag())){
                StaticLibrary.HIDE_PRE_LOADER();
            }

        }
    });
     
        
});

function loadAppDataSuccessHandler(data){

    DataParser.parseAppData(data);

    if(_model.getAppDataObj().enableCourseMenu == false){
        $(".menuBtn").parent("li").css("display","none")
    }
    if(_model.getAppDataObj().enableGlossary == false){
        $(".glossaryBtn").parent("li").css("display","none")
    }
    if(_model.getAppDataObj().enableInstruction == false){
        $(".instructionBtn").parent("li").css("display","none")
    }
    if(_model.getAppDataObj().enableResource == false){
        $(".resourceBtn").parent("li").css("display","none")
    }
    
    /* Making http request to landing page and next blocks are executed in landingPageSuccessHandler call back function*/

    var landingPageUrl = _model.getAppDataObj().baseURL + "/pages/landingPage.html";
    var apiServiceLoadLP = new APIService();
    apiServiceLoadLP.loadFromExternalSource(landingPageUrl, "true", StaticLibrary.TEMPLATE_TYPE, null, landingPageSuccessHandler);

   
}

function landingPageSuccessHandler(data) {
    $("#landingPage").html(data).promise().done(function(){
        StaticLibrary.HIDE_PRE_LOADER();

        /*  Start button triggers */

        $("#btnStart").off("click").on("click", function(){

            $(".landingscreen_bg").hide();
            $(".grandparent").show();	 
                
            /* Making http request to Course data json fileand next blocks are executed in loadCourseDataSuccessHandler call back function */

            var courseDataURL = _model.getAppDataObj().baseURL + "/assets/data/courseData.json?version=" + StaticLibrary.generateRandom();
            var apiServiceLoadCourseData = new APIService();
            apiServiceLoadCourseData.loadCourseData(courseDataURL, "true", StaticLibrary.DATA_TYPE, null, loadCourseDataSuccessHandler);	
                
        })
   });
}

function loadCourseDataSuccessHandler(data){

    DataParser.parseCourseData(data);	
	
	if(_model.getAppDataObj().scorm == "scorm"){
		var scormAPIObj = new scormAPI();
		_model.setScormReference(scormAPIObj);	
	}
	
    $(".projectTitle").html(_model.getCourseDataObj().projectTitle);
    $(".module_title").html(_model.getCourseDataObj().title);

    $("#desktopHelpImage").attr("src", _model.getCourseDataObj().baseURL + "assets/images/" + _model.getCourseDataObj().desktopHelp);

    /* Initialize course controller */

   var appControllerObj = new ApplicationController();
   appControllerObj.init(); 
	
} 

function trace(datastr){
	console.log(datastr);
}
