var DragAndDropController = function () {
    _this = this;
    var zIndex = 1;
    var dragOverOutPosition;

    this.loadUI = function () {

        $(".drag-drop-option").draggable({
            containment: "#drag-drop-container",
            zIndex: zIndex,
            scrollSpeed: 10,
            revert: true,
            start: function() {
               
                zIndex++;
                $(".ui-draggable,.drag_options").css("z-index","9");
				$(this).css("z-index","10");
				
			}
        })

        $(".drop-area").droppable({
            hoverClass: "drop-hover",
            drop: function (e, ui) {
                let droppedItem = $(ui.draggable).clone();

                $(ui.draggable).css({"visibility":"hidden"});
                droppedItem.css({"position":"relative","left": 0, "top": 0});
                droppedItem.addClass("drag-drop-option-new");
                $(this).html(droppedItem);
                $(this).droppable({
                    disabled: true
                  });
                addDragEvent();
            },
            over: function () {
                dragOverOutPosition = "over";
            },
            out: function () {
                dragOverOutPosition = "out";
            }

            
        });

        function addDragEvent() {
                $(".drag-drop-option-new").draggable({
                    containment: "#drag-drop-container",
                    zIndex: zIndex,
                    revert: function () {
                        return dragOverOutPosition != "out";
                    },
                    drag : function(e, ui) {
                        
                    },
                    start: function () {
                        $(this).parent().droppable({
                            disabled: false
                          });
                          zIndex++;
                          $(".ui-draggable").css("z-index","9");
					$(this).css("z-index","10");

                    },
                    stop: function(e, ui) {
                        $(this).parent().html("<span>Drop area</span>");
                        console.log(dragOverOutPosition)
                        if(dragOverOutPosition == "out"){
                            var draggedElePos = $(this).data("dragposition");
                            $("[data-dragPosition= "+draggedElePos+"]").css({"visibility":"visible"});
                        }
                    }
                })
        }
    }

    this.init = function () {
        _this.loadUI();
    }
}

var controller = new DragAndDropController();
controller.init();