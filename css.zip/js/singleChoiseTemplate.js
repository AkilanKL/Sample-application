var SingleChoiseController = function() {

    _this = this;
    var submitButton, resetButton, formContainer;
    var attemptCount = 0;
    var jsonData;
    var globalController, trackingObj, topicName, templateIndex;
    var attemptCount = 0;
    var questionContainer, modal, displayAns;
    this.loadUI = function(data, controller) {
        jsonData = data;
        globalController = controller
        trackingObj = controller.courseTrackingObj;
        topicName = controller.moduleTopicName;
        templateIndex = controller.templateIndex;
        formContainer = document.getElementsByClassName("form-group");
        questionContainer = document.getElementById("question");
        modal = document.querySelector(".template-modal");
        displayAns = document.querySelector(".display-answer-body");
        submitButton = document.getElementById("submit-button");
        

        questionContainer.innerHTML = jsonData.question;
        var optionsTexts = "";
        for(var i = 0; i < jsonData.options.length; i++) {
            optionsTexts += '<div class="label"><input type="radio" id="option-'+ i+'" value="'+jsonData.options[i]+'" name="multiple-choise"><label for="option-'+ i+'">'+jsonData.options[i]+'</label></div>';
        }
        formContainer[0].innerHTML = optionsTexts; 

        if((trackingObj[topicName].knowledgeCheck[templateIndex - 1].score == 1) ||
        trackingObj[topicName].knowledgeCheck[templateIndex - 1].attemptCount > 1) {
            _this.showAnswer("ansOnly");
        }else{
            submitButton.addEventListener("click", _this.submitButtonHandler);
        }
        
        trackingObj[topicName].templateIndex = templateIndex;
        globalController.storeTrackingData(trackingObj);

        // if(!trackingObj[topicName].isCompleted){
        //     _this.getProgressAndCompleteStatus();
        // }

    }

    this.submitButtonHandler = function() {
        var selectedObject = document.querySelector('input[name="multiple-choise"]:checked');
        if(selectedObject != null || selectedObject != undefined) {
            attemptCount++;
            var selectedValue = document.querySelector('input[name="multiple-choise"]:checked').value;
            if(selectedValue == jsonData.correctAnswer) {
    
                trackingObj[topicName].knowledgeCheck[templateIndex - 1].score = 1;
                trackingObj[topicName].knowledgeCheck[templateIndex - 1].attemptCount = attemptCount;
                trackingObj[topicName].knowledgeCheck[templateIndex - 1].completed = true;

                if(!trackingObj[topicName].isCompleted){
                    _this.getProgressAndCompleteStatus();
                    globalController.storeTrackingData(trackingObj);
                }
                 globalController.updateNextPreviousButtonControls();
                _this.showAnswer("Well Done");     
            }else{

                trackingObj[topicName].knowledgeCheck[templateIndex - 1].score = 0;
                trackingObj[topicName].knowledgeCheck[templateIndex - 1].attemptCount = attemptCount;

                if(!trackingObj[topicName].isCompleted){
                    _this.getProgressAndCompleteStatus();
                    globalController.storeTrackingData(trackingObj);
                }

                if(attemptCount > 1) {
                    trackingObj[topicName].knowledgeCheck[templateIndex - 1].completed = true;
                    _this.showAnswer("Incorrect 2"); 
                }else{
                    _this.showAnswer("Incorrect 1",);
                }       
                globalController.updateNextPreviousButtonControls();         
            }
        }
   
    }

    this.showAnswer = function (type) {
        modal.style.display = "block";
        if(type == "ansOnly") {
            displayAns.innerHTML = jsonData.displayAnswer;
            var templateAnsHeading = document.querySelector(".display-answer-heading");
            var modalFeedback = document.querySelector(".modal-feedback");
            var closeModalButton = document.querySelector(".template-modal-close");
            modalFeedback.innerHTML = "Answer";
            closeModalButton.style.display = "none";
        }else if(type == "Well Done") {
            displayAns.innerHTML = jsonData.displayAnswer;
            var modalFeedback = document.querySelector(".modal-feedback");
            var closeModalButton = document.querySelector(".template-modal-close");
            modalFeedback.innerHTML = "Well Done";
            closeModalButton.style.display = "none";
           
        }else if(type == "Incorrect 2") {
            displayAns.innerHTML = jsonData.displayAnswer;
            var modalFeedback = document.querySelector(".modal-feedback");
            var closeModalButton = document.querySelector(".template-modal-close");
            modalFeedback.innerHTML = "That's Incorrect";
            closeModalButton.style.display = "none";
            modal.removeEventListener("click", _this.closeModal);
           
        }else{
            var modalFeedback = document.querySelector(".modal-feedback");
            modalFeedback.innerHTML = "That's Incorrect";
            displayAns.innerHTML = "Please try again."
            modal.addEventListener("click", _this.closeModal);
        }
    }

    this.closeModal = function (e) {

        if(e.target.className == "template-modal" || e.target.className == "template-modal-close") {
            var selectedObj = document.querySelector('input[name="multiple-choise"]:checked');
            selectedObj.checked = false;
            modal.style.display = "none";
        }

    }

    this.getProgressAndCompleteStatus = function () {

        var templatesArray = trackingObj[topicName].knowledgeCheck;
        var templatesArrayLength = templatesArray.length;
        var totalQuestions = 0;
        var attemptedQuestions = 0;

        for(var i = 0; i < templatesArrayLength; i++){
            totalQuestions += 1;
            if(templatesArray[i].completed){
                attemptedQuestions += 1;
            }
        }

        if(attemptedQuestions == totalQuestions) {
            globalController.updateStatus("knowledgecheckcompleted");
        }
        
    }

    this.init = function(data, controller) {
        _this.loadUI(data, controller);
    }

}


