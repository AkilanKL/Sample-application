/**
 * Created by Venkatesh on 24/03/2017.
 */

var Fill_In_the_Blanks_TemplateController = function(currentRef){

    var _this = this;
	var currentData;
	this.attemptedCount = 0;
	this.submitBtn;
	this.clearState = false;
	this.ansArray = [];

    this.init = function(data){
        trace(":: Fill In the Blanks Template Loaded ::");
 
        _this.currentData = data;
        _this.loadUI(_this.currentData);

    }
		
    this.loadUI = function(data){

		_this.submitBtn = $(".submit-btn");
       
		$("#heading-fib").html(data.pageContent.heading);

		var totalQusLength = data.pageContent.questions.length;

		var questionTxt = [];

		for(var i = 0; i < totalQusLength; i++) {

			questionTxt.push(data.pageContent.questions[i].question.split("[textbox]"));
			_this.ansArray.push(data.pageContent.questions[i].answer.split(","));
		}

		for(var i = 0; i < questionTxt.length; i++) {
			
			var tempCont = '<div class="question-fib">';
				for(var j = 0; j < questionTxt[i].length; j++) {
					tempCont += questionTxt[i][j];
					if(j == questionTxt[i].length - 1) break;
					tempCont += '<input type="text" class="option-fib" data-qusfib-id="'+i+'" data-optfib-id="'+j+'">';
				}
				
			tempCont += '</div>';

			$(".fillinBlanks").append(tempCont);

			$(".option-fib").off("keyup").on("keyup", _this.watchSubmitBtnState);
			_this.submitBtn.click(_this.answerSubmitHandler);

		}
			
		if( currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.completed == "false" ){
			currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.ac = 
			data.pageContent.maxAttempt;
			_this.attemptedCount = currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.acTaken
		}else{
			_this.showAnswerHandler("loadUi");
		}

		$("input").focus(_this.clearHandler);
		
    }
	
	this.watchSubmitBtnState = function(){
		var inputCount = 0;
		var valCount = 0;

		$(".option-fib").each(function(){
			inputCount++;
			if($(this).val() != "") {
				valCount++;
			}
		});

		if(inputCount == valCount){
			_this.submitBtn.addClass("activate-btn");
			_this.submitBtn.attr("tabindex", "0");
		}else{
			_this.submitBtn.removeClass("activate-btn");
			_this.submitBtn.attr("tabindex", "-1");
		}
	}

	this.answerSubmitHandler = function() {

		_this.submitBtn.removeClass("activate-btn");
		_this.submitBtn.attr("tabindex", "-1");
		
		if( currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.completed == "false" ) {
			_this.attemptedCount++;
			_this.clearState = true;
			var inputCount = 0;
			var correctAnsCount = 0;

			$(".option-fib").each(function(i){
				inputCount++;
				var qusId = Number($(this).data("qusfib-id"));
				var optId = Number($(this).data("optfib-id"));
				
				if($(this).val() == _this.ansArray[qusId][optId]) {
					correctAnsCount++;
					$(this).addClass("fib-rt-ans")
				}else{
					$(this).addClass("fib-wr-ans")
				}
			});
			
			if(correctAnsCount == inputCount) {
				var tempObj = {
					score: 1,
					attemptsTaken: _this.attemptedCount,
					completed: "true"
				}
				currentRef.updateMenuNdTrackingStatus("visited", tempObj);
				_this.showAnswerHandler("submit");
				if(_model.getLinearTOCDataArr()[currentRef.curChapterIndex].pages[currentRef.currentIndex].templateType == "Assessment") {
					setTimeout(function() {
						currentRef.nextClickHandler();
					}, 2000);
				}
				
			}else{
				if(_this.attemptedCount == currentRef.menuStatusArr[currentRef.curChapterIndex].pages[currentRef.currentIndex].kc.ac) {
					var tempObj = {
						score: 0,
						attemptsTaken: _this.attemptedCount,
						completed: "true"
					}
					currentRef.updateMenuNdTrackingStatus("visited", tempObj);
					_this.showAnswerHandler("submit");
					if(_model.getLinearTOCDataArr()[currentRef.curChapterIndex].pages[currentRef.currentIndex].templateType == "Assessment") {
						setTimeout(function() {
							currentRef.nextClickHandler();
						}, 2000);
					}
				}else{
					var tempObj = {
						score: 0,
						attemptsTaken: _this.attemptedCount,
						completed: "false"
					}
					console.log('s')
					$("#main-content").focus();
					currentRef.updateMenuNdTrackingStatus(null, tempObj);
				}
			}

		}
	}
	
	this.clearHandler = function(){
		if(_this.clearState){
			_this.clearState = false;
			$(".option-fib").removeClass("fib-wr-ans");
			$(".option-fib").removeClass("fib-rt-ans");

			$(".option-fib").each(function() {
				$(this).val("");
			})
		}
	}
	
	this.showAnswerHandler = function(type){
		if(type == "submit") {
			$("input").attr("disabled","disbled");
		}else{
			$("input").attr("disabled","disbled");
			$(".option-fib").each(function(i){
	
				var qusId = Number($(this).data("qusfib-id"));
				var optId = Number($(this).data("optfib-id"));
				
				$(this).val(_this.ansArray[qusId][optId]);
			});
		}	
	}
	
}