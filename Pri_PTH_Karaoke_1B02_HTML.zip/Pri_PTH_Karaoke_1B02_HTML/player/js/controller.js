         var vid = document.getElementById("playVideo");
         var voice = document.getElementById("voice");
         var music = document.getElementById("music");
         var Mic = document.getElementById("song");
         var play = document.getElementById("play");
         var pause = document.getElementById("pause");
         var karaoke = document.getElementById("karaoke");
         var replay = document.getElementById("replay");
         var thumb = document.getElementById("thum");

         var videoTime = 0;
         var musicTime = 0;
         var voiceTime = 0;
		 
         if(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)){
         
            thumb.style.display = "block";
		}else{

            thumb.style.display = "none";				
		}
         $("#pause").hide();
         $("#karaoke").hide();         
         replay.disabled = true;
         Mic.disabled = true; 
         music.muted = true;

		//   <!-- Play functionality -->
         $("#play").click(function(){
            if(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)){
				
        
               thumb.style.display = "none";       
        
         }else{
               
               thumb.style.display = "none";
            
         }
         vid.play();
         voice.play();	
         music.play();	
         $("#pause").show();
         $("#play").hide();
         replay.disabled = false;
         Mic.disabled = false; 
         });
		 
      //     <!-- pause functionality -->
         $("#pause").click(function(){
         vid.pause();
         voice.pause();	
         music.pause();	
         $("#pause").hide();
         $("#play").show();
         });
		 
		//   <!-- song functionality  -->
         $("#song").click(function(){
			 if(!vid.paused){
				 
				voice.muted = true;
				music.muted = false;
				
			 }else{
				 voice.muted = true;
				music.muted = false;
			 }
			 
			
         		$("#karaoke").show();
				$("#song").hide();
       

         });
		 
		//   <!-- karaoke functionality -->
         $("#karaoke").click(function(){
			if(!vid.paused){
			
				voice.muted = false;
				music.muted = true;

			 }else{
				 voice.muted = false;
				 music.muted = true;
			 }
			
         	
       		 $("#song").show();
         $("#karaoke").hide();

         });
		 
      //     <!-- replay functionality  -->
         $("#replay").click(function(){
            musicTime = 0;
            voiceTime = 0;
            videoTime = 0;
           
         vid.autoplay = true;
         vid.load();
         voice.autoplay = true;
         voice.load();
         music.autoplay = true;
         music.load();
         $("#pause").show();
         $("#play").hide();
         });
		 
      //    <!-- Video end functionality  -->
         function myFunction() {
         vid.pause();
         voice.pause();	
         music.pause();	
         $("#play").show();
         $("#pause").hide();
         }

         vid.addEventListener("timeupdate", videoUpdateHanfler);

         function videoUpdateHanfler(e) {

            videoTime = vid.currentTime;
            musicTime = music.currentTime;
            voiceTime = voice.currentTime;

            var vidMusicDiffer = videoTime - musicTime;
            var vidVoiceDiffer = videoTime - voiceTime;


            if(vidMusicDiffer >= 0.3 || vidMusicDiffer <= -0.3) {
                  music.currentTime =  vid.currentTime;
              
            }
            if(vidVoiceDiffer >= 0.3 || vidVoiceDiffer <= -0.3) {
                  voice.currentTime =  vid.currentTime;
                
            }

         }