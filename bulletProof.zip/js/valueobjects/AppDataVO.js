var AppDataVO = function(props){
	this.serverURL = props.serverURL;
	this.isEncrypted = props.isEncrypted;
	this.courseName = props.courseName;
	this.dataType = props.dataType;
	this.scorm = _model.getScormReference().isScormStarted;
	this.language = props.language;
	this.baseURL = props.baseURL;
	this.linear = props.linear;
	this.templateLocation = props.templateLocation;
	this.landingPageAudio =props.landingPageAudio;
	this.landingImage =props.landingImage;
}